/* tidy.f -- translated by f2c (version 20090411).
   You must link the resulting object file with libf2c:
	on Microsoft Windows system, link with libf2c.lib;
	on Linux or Unix systems, link with .../path/to/libf2c.a -lm
	or, if you install libf2c.a in a standard place, with -lf2c -lm
	-- in that order, at the end of the command line, as in
		cc *.o -lf2c -lm
	Source for libf2c is in /netlib/f2c/libf2c.zip, e.g.,

		http://www.netlib.org/f2c/libf2c.zip
*/

#include "f2c.h"

/* Common Block Declarations */

struct {
    integer ldef[1500], locdef[1500], lref[1500], newnum[1500], nnmkls[1500], 
	    ioutn[256];
} _BLNK__;

#define _BLNK__1 _BLNK__

struct miscal_1_ {
    char kend[6], kbuff[160], jint[6560], job[160], iout[5424], serial[16], 
	    lcpy[2], kol73[6], ntemp[10];
};

#define miscal_1 (*(struct miscal_1_ *) &miscal_)

struct misc_1_ {
    doublereal l772;
    integer icol, ifir, indent, ipass, iquit, istar, jcol, jmax, just, k72, 
	    kbkcok, kfspl, kb15, kctctl, kd15, kd79, kdtran, khlog, khtran, 
	    kili[8], kount, kprin, kpun, l25, last, ldos[20], lerr, lfir, 
	    line, lqual, mansi, mcol, mcom, mcont, mdeb, meof, mildo, mlbl, 
	    mlgc, mlist, mp2, mpage, mprin, mpun, mref, mrit, mser, mskp, 
	    mstop, mxref, mxrght, mcase, mndoo, mfmtb, maxcnt, nblc, ncd, 
	    ndef, ndos, nfend, nins, nlhtrn, nmsg, npage, npar, npun, nrec, 
	    nref, nrout, nrt1, nrt2, ntran, nxeq, kcmctl;
};

#define misc_1 (*(struct misc_1_ *) &misc_)

struct alpha_1_ {
    char kbl[2], kdig[20], kabc[52], kspk[30], kbl2[2], klr2[2], klp2[2], 
	    krp2[2], kerm[2], ktab[2], kampr[2], kat[2], kctchr[2], kdel1[2], 
	    kdel2[2], kapstr[2], kalmrk[2], kaltrn[2], kblcmt[2], kcmchr[2];
};

#define alpha_1 (*(struct alpha_1_ *) &alpha_)

struct lunits_1_ {
    integer infile__, outfil, punfil, scfil1, scfil2, stderr, stdin, usrfil;
};

#define lunits_1 (*(struct lunits_1_ *) &lunits_)

struct tdyver_1_ {
    char vernum[30];
};

#define tdyver_1 (*(struct tdyver_1_ *) &tdyver_)

struct contdy_1_ {
    char ktrl[352]	/* was [4][44] */;
};
struct contdy_2_ {
    char ktrl1[8], ktrl2[8], ktrl3[8], ktrl4[8], ktrl5[8], ktrl6[8], ktrl7[8],
	     ktrl8[8], ktrl9[8], ktrl10[8], ktrl11[8], ktrl12[8], ktrl13[8], 
	    ktrl14[8], ktrl15[8], ktrl16[8], ktrl17[8], ktrl18[8], ktrl19[8], 
	    ktrl20[8], ktrl21[8], ktrl22[8], ktrl23[8], ktrl24[8], ktrl25[8], 
	    ktrl26[8], ktrl27[8], ktrl28[8], ktrl29[8], ktrl30[8], ktrl31[8], 
	    ktrl32[8], ktrl33[8], ktrl34[8], ktrl35[8], ktrl36[8], ktrl37[8], 
	    ktrl38[8], ktrl39[8], ktrl40[8], ktrl41[8], ktrl42[8], ktrl43[8], 
	    ktrl44[8];
};

#define contdy_1 (*(struct contdy_1_ *) &contdy_)
#define contdy_2 (*(struct contdy_2_ *) &contdy_)

struct kstcom_1_ {
    char kst[1720]	/* was [10][86] */;
};
struct kstcom_2_ {
    char kst01[20], kst02[20], kst03[20], kst04[20], kst05[20], kst06[20], 
	    kst07[20], kst08[20], kst09[20], kst10[20], kst11[20], kst12[20], 
	    kst13[20], kst14[20], kst15[20], kst16[20], kst17[20], kst18[20], 
	    kst19[20], kst20[20], kst21[20], kst22[20], kst23[20], kst24[20], 
	    kst25[20], kst26[20], kst27[20], kst28[20], kst29[20], kst30[20], 
	    kst31[20], kst32[20], kst33[20], kst34[20], kst35[20], kst36[20], 
	    kst37[20], kst38[20], kst39[20], kst40[20], kst41[20], kst42[20], 
	    kst43[20], kst44[20], kst45[20], kst46[20], kst47[20], kst48[20], 
	    kst49[20], kst50[20], kst51[20], kst52[20], kst53[20], kst54[20], 
	    kst55[20], kst56[20], kst57[20], kst58[20], kst59[20], kst60[20], 
	    kst61[20], kst62[20], kst63[20], kst64[20], kst65[20], kst66[20], 
	    kst67[20], kst68[20], kst69[20], kst70[20], kst71[20], kst72[20], 
	    kst73[20], kst74[20], kst75[20], kst76[20], kst77[20], kst78[20], 
	    kst79[20], kst80[20], kst81[20], kst82[20], kst83[20], kst84[20], 
	    kst85[20], kst86[20];
};

#define kstcom_1 (*(struct kstcom_1_ *) &kstcom_)
#define kstcom_2 (*(struct kstcom_2_ *) &kstcom_)

struct kstnum_1_ {
    integer kstc[516]	/* was [6][86] */;
};
struct kstnum_2_ {
    integer kstc01[6], kstc02[6], kstc03[6], kstc04[6], kstc05[6], kstc06[6], 
	    kstc07[6], kstc08[6], kstc09[6], kstc10[6], kstc11[6], kstc12[6], 
	    kstc13[6], kstc14[6], kstc15[6], kstc16[6], kstc17[6], kstc18[6], 
	    kstc19[6], kstc20[6], kstc21[6], kstc22[6], kstc23[6], kstc24[6], 
	    kstc25[6], kstc26[6], kstc27[6], kstc28[6], kstc29[6], kstc30[6], 
	    kstc31[6], kstc32[6], kstc33[6], kstc34[6], kstc35[6], kstc36[6], 
	    kstc37[6], kstc38[6], kstc39[6], kstc40[6], kstc41[6], kstc42[6], 
	    kstc43[6], kstc44[6], kstc45[6], kstc46[6], kstc47[6], kstc48[6], 
	    kstc49[6], kstc50[6], kstc51[6], kstc52[6], kstc53[6], kstc54[6], 
	    kstc55[6], kstc56[6], kstc57[6], kstc58[6], kstc59[6], kstc60[6], 
	    kstc61[6], kstc62[6], kstc63[6], kstc64[6], kstc65[6], kstc66[6], 
	    kstc67[6], kstc68[6], kstc69[6], kstc70[6], kstc71[6], kstc72[6], 
	    kstc73[6], kstc74[6], kstc75[6], kstc76[6], kstc77[6], kstc78[6], 
	    kstc79[6], kstc80[6], kstc81[6], kstc82[6], kstc83[6], kstc84[6], 
	    kstc85[6], kstc86[6];
};

#define kstnum_1 (*(struct kstnum_1_ *) &kstnum_)
#define kstnum_2 (*(struct kstnum_2_ *) &kstnum_)

struct {
    integer kstc[5], nifblk;
} ps1sub_;

#define ps1sub_1 ps1sub_

struct {
    char linin[26], linout[26];
} ctran_;

#define ctran_1 ctran_

/* Initialized data */

struct {
    char e_1[6];
    char fill_2[12338];
    } miscal_ = { "D N E " };

struct {
    char e_1[352];
    } contdy_ = { "B A S E I D I N I D S T R O U T S T A T C A R D C O L L C"
	    " O M M E X E M L A B E L A S T L I S T N E W R R E F E S K I P S"
	    " T O P S E R I R I G H L E F T C O L U I N D E D E B U C O N T E"
	    " N D   A N S I F E N D C C H R H T R A D T R A D E L 1 D E L 2 A"
	    " R E T A R T R B L A N F S P L H L O G C A S E U C A S L C A S E"
	    " N D O F M T B M A X C O L D S M C H R " };

struct {
    doublereal fill_1[3];
    integer e_2;
    integer fill_3[22];
    integer e_4;
    integer fill_5[24];
    integer e_6;
    integer fill_7[1];
    integer e_8;
    integer fill_9[5];
    integer e_10;
    integer fill_11[13];
    integer e_12[3];
    integer fill_13[11];
    integer e_14[2];
    integer fill_15[1];
    integer e_16;
    integer fill_17[8];
    } misc_ = { {0}, 0, {0}, 0, {0}, 0, {0}, 1, {0}, 0, {0}, 0, 256, 65, {0}, 
	    0, 0, {0}, 0 };

struct {
    char e_1[1720];
    } kstcom_ = { "A C C E P T         A S C E N T         A S S I G N      "
	    "   B A C K S P A C E ( B L O C K D A T A   B U F F E R I N (   B"
	    " U F F E R O U T ( C A L L             C H A R A C T E R   C O M"
	    " M O N         C O M P L E X       C O N T I N U E     D A T A  "
	    "           D E C O D E (       D I M E N S I O N   D O U B L E P"
	    " R E C D O U B L E         E N C O D E (       E N D F I L E (  "
	    "   E N D I F           E N D F I L E       E N T R Y           E"
	    " Q U I V A L E N C E X T E R N A L     F I N I S           F O R"
	    " M A T (       F O R T R A N       I F ( U N I T ,     F U N C T"
	    " I O N     G O T O (           G O T O             I F A C C U M"
	    " U L A I F Q U O T I E N T I F ( D I V I D E C I F ( E N D F I L"
	    " E I F ( S E N S E L I I F ( S E N S E S W I F (               I"
	    " N T E G E R       L O G I C A L       M A C H I N E       N A M"
	    " E L I S T     P A U S E           P R I N T           P R O G R"
	    " A M       P U N C H           R E A D I N P U T T R E A D T A P"
	    " E     R E A D (           R E A D             R E A L          "
	    "   R E T U R N         R E W I N D (       S E G M E N T       S"
	    " E N S E L I G H T S T O P             S U B R O U T I N E T Y P"
	    " E             W R I T E O U T P U W R I T E T A P E   W R I T E"
	    " (         O V E R L A Y       I D E N T           F R E Q U E N"
	    " C Y   I M P L I C I T     L E V E L           E L S E I F      "
	    "   E L S E             T H E N             C L O S E (         I"
	    " N C L U D E       I N Q U I R E (     I N T R I N S I C   O P E"
	    " N (           P A R A M E T E R   S A V E             B A C K S"
	    " P A C E   E N D D O           R E W I N D         C L O S E    "
	    "       E N D               D O W H I L E (     R E P E A T      "
	    "   C Y C L E           E X I T             N O N E             " }
	    ;

struct {
    integer e_1[516];
    } kstnum_ = { 6, 7, 33, 1, 0, 1, 6, 2, 1, 1, 0, 2, 6, 7, 2, 0, 0, 3, 10, 
	    7, 47, 0, 0, 4, 9, 2, 4, 0, 0, 5, 9, 6, 5, 1, 0, 6, 10, 6, 5, 1, 
	    0, 7, 4, 7, 6, 0, 1, 8, 9, 3, 46, 0, 0, 9, 6, 3, 7, 0, 0, 10, 7, 
	    3, 46, 0, 0, 11, 8, 4, 8, 0, 0, 12, 4, 3, 9, 0, 1, 13, 7, 7, 10, 
	    1, 0, 14, 9, 3, 11, 0, 0, 15, 10, 3, 12, 0, 0, 16, 6, 3, 13, 0, 0,
	     17, 7, 7, 10, 1, 0, 18, 8, 7, 47, 0, 0, 19, 5, 11, 48, 0, 0, 20, 
	    7, 6, 15, 0, 0, 21, 5, 11, 3, 0, 0, 22, 10, 3, 17, 0, 0, 23, 8, 3,
	     3, 0, 0, 24, 5, 3, 18, 1, 0, 25, 7, 5, 19, 0, 1, 26, 7, 2, 20, 1,
	     0, 27, 8, 7, 42, 1, 1, 28, 8, 2, 35, 0, 0, 29, 5, 7, 23, 0, 0, 
	    30, 4, 7, 24, 0, 0, 31, 10, 7, 25, 1, 1, 32, 10, 7, 26, 1, 1, 33, 
	    10, 7, 27, 1, 1, 34, 10, 7, 28, 1, 1, 35, 10, 7, 29, 1, 1, 36, 10,
	     7, 30, 1, 1, 37, 3, 7, 31, 0, 1, 38, 7, 3, 46, 0, 0, 39, 7, 3, 
	    46, 0, 0, 40, 7, 2, 1, 1, 0, 41, 8, 3, 32, 1, 0, 42, 5, 6, 3, 0, 
	    1, 43, 5, 7, 33, 0, 1, 44, 7, 2, 35, 0, 0, 45, 5, 7, 33, 1, 1, 46,
	     10, 7, 36, 0, 0, 47, 8, 6, 37, 0, 0, 48, 5, 7, 38, 0, 1, 49, 4, 
	    7, 33, 0, 1, 50, 4, 3, 46, 0, 0, 51, 6, 6, 39, 0, 0, 52, 7, 7, 47,
	     0, 0, 53, 7, 9, 34, 1, 0, 54, 10, 6, 40, 1, 0, 55, 4, 6, 41, 0, 
	    1, 56, 10, 2, 35, 0, 0, 57, 4, 7, 33, 1, 0, 58, 10, 7, 44, 0, 1, 
	    59, 9, 6, 45, 0, 1, 60, 6, 7, 38, 0, 1, 61, 7, 9, 34, 1, 0, 62, 5,
	     9, 22, 1, 0, 63, 9, 3, 21, 1, 0, 64, 8, 3, 3, 0, 0, 65, 5, 3, 3, 
	    1, 0, 66, 6, 11, 43, 0, 1, 67, 4, 11, 49, 0, 0, 68, 4, 11, 3, 0, 
	    0, 69, 6, 7, 47, 0, 0, 70, 7, 3, 3, 1, 1, 71, 8, 7, 47, 0, 1, 72, 
	    9, 3, 3, 0, 0, 73, 5, 7, 47, 0, 1, 74, 9, 3, 3, 0, 1, 75, 4, 3, 3,
	     0, 0, 76, 9, 6, 3, 0, 0, 77, 5, 7, 50, 1, 1, 81, 6, 6, 3, 0, 0, 
	    79, 5, 6, 3, 0, 0, 80, 3, 8, 16, 0, 0, 78, 8, 11, 51, 1, 0, 82, 6,
	     7, 50, 1, 1, 83, 5, 6, 3, 1, 0, 88, 4, 6, 3, 1, 0, 89, 4, 3, 46, 
	    1, 0, 90 };

struct {
    char e_1[114];
    char fill_2[2];
    char e_3[4];
    char fill_4[6];
    char e_5[2];
    char fill_6[8];
    } alpha_ = { "  0 1 2 3 4 5 6 7 8 9 A B C D E F G H I J K L M N O P Q R "
	    "S T U V W X Y Z = , ( / ) + - * . X$- ' & $ !  *$$(()) $", {0}, 
	    "&  @", {0}, "'@" };

struct {
    integer e_1[8];
    } lunits_ = { 4, 7, 8, 1, 2, 6, 5, 3 };

struct {
    char e_1[30];
    } tdyver_ = { "Tidy 7.2.1 -  2014-04-04      " };


/* Table of constant values */

static integer c__1 = 1;
static integer c__47 = 47;
static integer c__2 = 2;
static integer c__48 = 48;
static integer c__0 = 0;
static integer c_n1 = -1;
static integer c_n2 = -2;
static integer c__50 = 50;
static integer c__38 = 38;
static integer c__54 = 54;
static integer c__10 = 10;
static integer c__5 = 5;
static integer c__35 = 35;
static integer c__3 = 3;
static integer c__80 = 80;
static integer c__4 = 4;
static integer c__6 = 6;
static integer c__49 = 49;
static integer c__46 = 46;
static integer c_n20 = -20;
static integer c__36 = 36;
static integer c__52 = 52;
static integer c__25 = 25;
static integer c__39 = 39;
static integer c__26 = 26;
static integer c__18 = 18;
static integer c__37 = 37;
static integer c__28 = 28;
static integer c__8 = 8;
static integer c__30 = 30;
static integer c__41 = 41;
static integer c__34 = 34;
static integer c__45 = 45;
static integer c__14 = 14;
static integer c__85 = 85;
static integer c__11 = 11;
static integer c__86 = 86;
static integer c__44 = 44;
static integer c__27 = 27;
static integer c__87 = 87;
static integer c__33 = 33;
static integer c__16 = 16;
static integer c__56 = 56;
static integer c__78 = 78;
static integer c__32 = 32;
static integer c__40 = 40;
static integer c__42 = 42;
static integer c__43 = 43;
static integer c__72 = 72;
static integer c__53 = 53;
static integer c__7 = 7;
static integer c__51 = 51;

/* Main program */ int MAIN__(void)
{
    /* Format strings */
    static char fmt_30[] = "(\002 Running\002)";
    static char fmt_23[] = "(\002 Begin Pass2\002)";
    static char fmt_25[] = "(\002 Rewinding scratch files - main program\002)"
	    ;
    static char fmt_40[] = "(\002 Warning .\002,i5,\002 Diagnostic messages "
	    "have been generated\rin this tidy run.\002)";
    static char fmt_50[] = "(\002 No diagnostic messages were generated duri"
	    "ng this tidy run.\002)";
    static char fmt_60[] = "(\002 \002,i5,\002 cards were punched.\002/\002"
	    " \002,a)";

    /* System generated locals */
    cllist cl__1;
    alist al__1;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_wsfe(cilist *), e_wsfe(void), f_rew(alist *), do_fio(integer *, 
	    char *, ftnlen), f_clos(cllist *);
    /* Subroutine */ int s_stop(char *, ftnlen);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int edit_(void);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    extern /* Subroutine */ int rdir_(void), pass1_(void), pass2_(void);
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int diagno_(integer *), reader_(void);
    static char cfilnm[64];
    extern /* Subroutine */ int pctidy_(logical *, char *, ftnlen);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int initdy_(void);
    static logical douser;
    extern /* Subroutine */ int usrcon_(char *, ftnlen);

    /* Fortran I/O blocks */
    static cilist io___12 = { 0, 0, 0, fmt_30, 0 };
    static cilist io___13 = { 0, 0, 0, fmt_23, 0 };
    static cilist io___14 = { 0, 0, 0, fmt_25, 0 };
    static cilist io___15 = { 0, 0, 0, fmt_40, 0 };
    static cilist io___16 = { 0, 0, 0, fmt_40, 0 };
    static cilist io___17 = { 0, 0, 0, fmt_50, 0 };
    static cilist io___18 = { 0, 0, 0, fmt_50, 0 };
    static cilist io___19 = { 0, 0, 0, fmt_60, 0 };



/* =================================================================== */
/*                                                                  * */
/*                    * * *   T I D Y   * * *                       * */
/*                    Version 7.2.1, 2014-04-04                     * */
/*      A FORTRAN PROGRAM TO RENUMBER AND OTHERWISE CLEAN UP        * */
/*             OLD AND TIRED FORTRAN SOURCE PROGRAMS.               * */
/*                                                                  * */
/*                   IN ADDITION TO RENUMBERING,                    * */
/*             TIDY PROVIDES A LIMITED SET OF FORTRAN               * */
/*                          DIAGNOSTICS.                            * */
/*                                                                  * */
/*                 ANSI FORTRAN  (ANSI X3.9-1978)                   * */
/*                                                                  * */
/* =================================================================== */
/*                                                                  * */
/*  Copyright (C) 1989, The Regents of the University of California * */
/*                      All Rights Reserved                         * */
/*                                                                  * */
/*  THE REGENTS OF THE UNIVERSITY OF CALIFORNIA MAKE NO REPRESENTA- * */
/*  TION OR WARRANTIES WITH RESPECT TO THE CONTENTS HEREOF AND      * */
/*  SPECIFICALLY DISCLAIM ANY IMPLIED WARRANTIES OF MERCHANTABILITY * */
/*  OR FITNESS FOR ANY PARTICULAR PURPOSE.                          * */
/*                                                                  * */
/*  Further, the Regents of the University of California reserve the* */
/*  right to revise this software and/or documentation and to make  * */
/*  changes from time to time in the content hereof without obliga- * */
/*  tion of the Regents of the University of California to notify   * */
/*  any person of such revision or change.                          * */
/*                                                                  * */
/*  PERMISSION TO COPY AND DISTRIBUTE THIS PROGRAM, AND TO MAKE     * */
/*  DERIVATIVE WORKS HEREFROM, IS GRANTED PROVIDED THAT THIS COPY-  * */
/*  RIGHT NOTICE IS RETAINED IN ALL SOURCE CODE AND USER MANUALS.   * */
/*                                                                  * */
/* ==================================================================* */
/*                                                                  * */
/*                 **************************                       * */
/*                *         PROGRAM          *                      * */
/*               *     AND SUBROUTINES BY     *                     * */
/*              *        HARRY M MURPHY        *                    * */
/*             *  AIR FORCE WEAPONS LABORATORY  *                   * */
/*              *   KIRTLAND AIR FORCE BASE    *                    * */
/*               *         NEW MEXICO         *                     * */
/*                *         1 9 6 6          *                      * */
/*                 **************************                       * */
/*                                                                  * */
/*     TIDY ACCEPTS ASA FORTRAN WITH 19 CONTINUATION CARDS          * */
/*     AS WELL AS SOME IBM AND CDC DIALECT FORTRAN STATEMENTS       * */
/*                                                                  * */
/*     THIS VERSION MODIFIED FOR USE AT LRL BERKELEY BY             * */
/*     GERRY TOOL (1967). (STILL CDC/6600)                          * */
/*                                                                  * */
/*     THIS PROGRAM HAS BEEN REVISED FOR IBM 360/67 BY ALICE        * */
/*     V BARLOW, NASA AMES, SUMMER 1972                             * */
/*                                                                  * */
/*     ADDITIONS AND REWORKING BY ROGER CHAFFEE, LRL BERKELEY       * */
/*     AND SLAC COMPUTATIONS RESEARCH GROUP, 1968-1982              * */
/*                                                                  * */
/*     CONVERTED TO IBM (RYAN-McFARLAND) PROFESSIONAL FORTRAN       * */
/*     BY AL STANGENBERGER, DEPT. OF FORESTRY, U.C. BERKELEY        * */
/*                                                                  * */
/*     Additions and conversion to command line version             * */
/*     by Ajit J. Thakkar, Dept. of Chemistry, U. New Brunswick     * */
/*     E-mail: ajit@unb.ca  WWW  http://www.unb.ca/chem/ajit/       * */
/*                                                                  * */
/* ==================================================================* */


/*  INPUT/OUTPUT */
/*     FUNCTION          FORTRAN UNIT   CURRENT VALUE */
/*      CONSOLE OUTPUT     STDERR            6 */
/*      CONSOLE INPUT      STDIN             5  (unused) */
/*      CONTROL CARD       USRFIL            3 */
/*      INPUT              INFILE            4 */
/*      LIST OUTPUT        OUTFIL            7 */
/*      CARD OUTPUT        PUNFIL            8 */
/*      SCRATCH(NORMAL)    SCFIL1            1 */
/*      SCRATCH(FORMATS)   SCFIL2            2 */

/* ================================================================ */
/*     I N S T A L L A T I O N   N O T E S */

/*     1.  INCLUDE statements are used to incorporate common block */
/*         definitions into most subroutines.  Check syntax as these */
/*         statements are system-dependent. */

/*     2.  CHARACTER SET SPECIFICITY - */
/*         The code for horizontal tab differs in EBCDIC and ASCII. */
/*         This value is set (KTAB) in this routine. Fix as needed. */

/*     3.  Non-standard intrinsics. */
/*         Intrinsic subroutine EXIT(n) is used to abort the program */
/*         with a non-zero error code passed to the operating system. */
/*         Many compilers including Lahey F77L, LF90, LF95 and GNU g77 */
/*         provide an EXIT intrinsic. */

/*         The first and only command line argument is obtained by a */
/*         call to GetArg. A GetArg subroutine for Lahey F77L, LF90 */
/*         and LF95 is included in this distribution, and GNU g77 has */
/*         an intrinsic GetArg. */

/*         Aside from these factors, the rest of the program is */
/*         standard Fortran-77. */

/* ================================================================ */
/*     Programming notes: */

/*     In subroutine holscn, Hollerith characters are changed */
/*     so they won't be recognized by any other test by */
/*     changing second character to '@' */

/*     Subroutines holscn and contrl invoke function kupper to convert */
/*     lower-case alphabetic characters to upper case (except for */
/*     Hollerith strings). */

/*     The character $ is treated as an alpha in IBM Fortran. */
/*     the data statement for the special characters, kspk, has */
/*     been changed so that $ is not recognized as a special */
/*     character.  this data statement should be changed back */
/*     on non-IBM systems. */

/*     Subroutine redstr is set up to accommodate an apparent bug */
/*     in the Ryan-McFarland professional Fortran compiler, that */
/*     unformatted sequential records seem to be limited to 1024 bytes. */
/*     Since each record has a 4-byte header and trailer, writes 508 */
/*     character*2 elements, or 254 integer*4 per record.  this may */
/*     vary for other compilers. */


/*  INTERNAL FLAGS (JUST A LIST.  WHERE ELSE TO PUT IT...) */
/*     MANSI =  0 FLAG ALL NON-ANSI (FORTRAN-77) STATEMENTS */
/*           =  1 DO NOT FLAG NON-ANSI STATEMENTS */
/*     MP2   =  1 DO PASS2 */
/*           =  0 NO PASS 2 */
/*     MCOL  = -1 COLLECT FORMAT STATEMENTS AT END */
/*           =  0 LEAVE THEM IN PLACE */
/*     MILDO = -1 IF DO-TERMINATOR ALLOWED BUT NON-STANDARD */
/*           =  0 IF DO-TERMINATOR ALLOWED */
/*           = +1 IF DO-TERMINATOR FORBIDDEN */
/*     MCONT =  0 REMOVE CONTINUE CARDS AND DOUBLE BRANCHES */
/*           =  1 LEAVE THEM */
/*     MTRAN = -1 CURRENT CARD IS AN UNCONDITIONAL BRANCH */
/*           =  0 CURRENT CARD NOT NECESSARILY A BRANCH */
/*     NTRAN =    SAME AS MTRAN, BUT REFERS TO PREVIOUS CARD */
/*     MLGC  = -1 NORMAL STATEMENT */
/*           =  0 STATEMENT IS CONTROLLED BY A LOGICAL IF */
/*     MRIT  =  N LEFT ADJUST TO COLUMN N */
/*           = -N RIGHT ADJUST TO COLUMN N */
/*     MDEB  =  0 *NODEBUG */
/*           =  1 *DEBUG */
/*     KD15  =    STATEMENT INCREMENT (*STAT=...) */
/*     KB15  =    STATEMENT BASE (*BASE=...) */
/*     MPUN  =  0 NO PUNCH OUTPUT */
/*           =  1 MAKE PUNCH OUTPUT */
/*     KPUN       SAVES *CARD/+NOCARD (1/0) FOR MPUN VALUE */
/*     MLIST = -1 (*LIST) LIST PASS 1 */
/*           =  0 (*NOLIST) DONT */
/*     KPRIN =  1 (*LIST=2) LIST PASS 2 */
/*           =  0 (*NOLIST=2) DONT */
/*     MPRIN =    KPRIN AT START OF ROUTINE. MAY CHANGE IF ERROR */
/*                  AT START OF PASS1. */
/*     KOUNT      COUNTS CARDS IN FOR CURRENT ROUTINE. */
/*     IQUIT =  0 UNTIL INPUT ENDFILE IS FOUND IN READER. */
/*           =  1 THEREAFTER */
/*     MSTOP =  0 NORMALLY */
/*           = -1 FOR *STOP CARD FOUND--TIME TO FINISH UP */
/*           =  1 FOR STOP NOW. */

/* ================================================================ */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*     LOGICAL DOUSER,SCDISK */
/*  FORTRAN LOGICAL UNITS */

    douser = TRUE_;

/*     SCDISK .TRUE. ALLOWS USER TO SPECIFY DISK TO HOLD SCRATCH FILES. */
/*          FOR UNIX SYSTEMS, SHOULD SET TO .FALSE. */
/*     This variable has no meaning in version 7.2 */
/*     SCDISK=.TRUE. */

/*     VALUE FOR TAB AS ASCII */
    s_copy(alpha_1.ktab, alpha_1.kbl, (ftnlen)2, (ftnlen)2);
    *(unsigned char *)alpha_1.ktab = '\t';
/*     VALUE FOR TAB AS EBCDIC */
/*     KTAB(1:1)=CHAR(5) */

/*  Following call is for version 7.2 (two arguments only) */
    pctidy_(&douser, cfilnm, (ftnlen)64);
/*     CALL PCTIDY (DOUSER,SCDISK,CFILNM) */

/*     INITIALIZE PROGRAM */
    initdy_();
/*     ADJUST ROUTINE NUMBER - PASS1 WILL INCREMENT IT. */
    --misc_1.nrout;

/*     PROCESS USER CONTROL CARD FILE. */
    if (douser) {
	usrcon_(cfilnm, (ftnlen)64);
    }

    io___12.ciunit = lunits_1.stderr;
    s_wsfe(&io___12);
    e_wsfe();
    reader_();

L10:
    pass1_();
    if (misc_1.mstop != 0) {
	if (misc_1.mstop > 0) {
	    goto L20;
	}
	if (misc_1.kount <= 0) {
	    goto L20;
	}
    }
    edit_();
    if (misc_1.mp2 == 0) {
	goto L10;
    }
    if (misc_1.mref != 0) {
	rdir_();
    }
    if (misc_1.mdeb != 0) {
	io___13.ciunit = lunits_1.stderr;
	s_wsfe(&io___13);
	e_wsfe();
    }
    pass2_();
    if (misc_1.iquit != 0) {
	goto L20;
    }
    if (misc_1.mstop == 0) {
	goto L10;
    }
/*                            ALL DONE */
L20:
    if (misc_1.mdeb != 0) {
	io___14.ciunit = lunits_1.stderr;
	s_wsfe(&io___14);
	e_wsfe();
    }
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil1;
    f_rew(&al__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil2;
    f_rew(&al__1);
    if (misc_1.nmsg > 0) {
	io___15.ciunit = lunits_1.outfil;
	s_wsfe(&io___15);
	do_fio(&c__1, (char *)&misc_1.nmsg, (ftnlen)sizeof(integer));
	e_wsfe();
	io___16.ciunit = lunits_1.stderr;
	s_wsfe(&io___16);
	do_fio(&c__1, (char *)&misc_1.nmsg, (ftnlen)sizeof(integer));
	e_wsfe();
    } else {
	io___17.ciunit = lunits_1.outfil;
	s_wsfe(&io___17);
	e_wsfe();
	io___18.ciunit = lunits_1.stderr;
	s_wsfe(&io___18);
	e_wsfe();
    }
    io___19.ciunit = lunits_1.outfil;
    s_wsfe(&io___19);
    do_fio(&c__1, (char *)&misc_1.npun, (ftnlen)sizeof(integer));
    do_fio(&c__1, tdyver_1.vernum, (ftnlen)30);
    e_wsfe();

/*     ABNORMAL TERMINATIONS HANDLED BY SUBROUTINE DIAGNO. */
    if (misc_1.lerr > 0) {
	diagno_(&c__47);
    }

/*     GET RID OF SCRATCH FILES UNLESS DEBUGGING */
    if (misc_1.mdeb == 0) {
	cl__1.cerr = 0;
	cl__1.cunit = lunits_1.scfil1;
	cl__1.csta = "DELETE";
	f_clos(&cl__1);
	cl__1.cerr = 0;
	cl__1.cunit = lunits_1.scfil2;
	cl__1.csta = "DELETE";
	f_clos(&cl__1);
    }

    s_stop("", (ftnlen)0);

    return 0;
} /* MAIN__ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int pctidy_(logical *douser, char *cfilnm, ftnlen cfilnm_len)
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2];
    olist o__1;
    alist al__1;
    inlist ioin__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void),
	     f_inqu(inlist *);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer f_open(olist *), f_rew(alist *), i_indx(char *, char *, ftnlen, 
	    ftnlen);
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen),
	     s_stop(char *, ftnlen);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static integer idot;
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    static char filnm1[64], filnm2[64], clname[64];
    extern /* Subroutine */ int getarg_(integer *, char *, ftnlen);
    static logical forfil;
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___29 = { 0, 0, 0, "(1x,A)", 0 };
    static cilist io___34 = { 0, 0, 0, "(A)", 0 };


/*  Version 7.2.1 */
/*    by RSS, RSAA, ANU */
/*  Standard F77 file definitions */
/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */
/*  Display version number on console */
    io___29.ciunit = lunits_1.stderr;
    s_wsfe(&io___29);
    do_fio(&c__1, tdyver_1.vernum, (ftnlen)30);
    e_wsfe();
/*  Find and open user control file. */
    ioin__1.inerr = 0;
    ioin__1.infilen = 8;
    ioin__1.infile = "tidy.ini";
    ioin__1.inex = &*douser;
    ioin__1.inopen = 0;
    ioin__1.innum = 0;
    ioin__1.innamed = 0;
    ioin__1.inname = 0;
    ioin__1.inacc = 0;
    ioin__1.inseq = 0;
    ioin__1.indir = 0;
    ioin__1.infmt = 0;
    ioin__1.inform = 0;
    ioin__1.inunf = 0;
    ioin__1.inrecl = 0;
    ioin__1.innrec = 0;
    ioin__1.inblank = 0;
    f_inqu(&ioin__1);
    if (*douser) {
	s_copy(cfilnm, "tidy.ini", (ftnlen)64, (ftnlen)8);
	o__1.oerr = 0;
	o__1.ounit = lunits_1.usrfil;
	o__1.ofnmlen = 64;
	o__1.ofnm = cfilnm;
	o__1.orl = 0;
	o__1.osta = "OLD";
	o__1.oacc = 0;
	o__1.ofm = 0;
	o__1.oblnk = 0;
	f_open(&o__1);
	al__1.aerr = 0;
	al__1.aunit = lunits_1.usrfil;
	f_rew(&al__1);
    }
/*  Find and open source file */
/*  Get first command line argument using GetArg */
/*  A GetArg subroutine (using GetCl) is provided for Lahey compilers */
/*  whereas g77 has GetArg as a non-standard intrinsic */
    getarg_(&c__1, clname, (ftnlen)64);
    s_copy(filnm1, clname, (ftnlen)64, (ftnlen)64);
    idot = i_indx(filnm1, ".", (ftnlen)64, (ftnlen)1);
    if (idot == 0) {
	idot = i_indx(filnm1, " ", (ftnlen)64, (ftnlen)1);
/* Writing concatenation */
	i__1[0] = idot - 1, a__1[0] = filnm1;
	i__1[1] = 4, a__1[1] = ".for";
	s_cat(filnm1, a__1, i__1, &c__2, (ftnlen)64);
	ioin__1.inerr = 0;
	ioin__1.infilen = 64;
	ioin__1.infile = filnm1;
	ioin__1.inex = &forfil;
	ioin__1.inopen = 0;
	ioin__1.innum = 0;
	ioin__1.innamed = 0;
	ioin__1.inname = 0;
	ioin__1.inacc = 0;
	ioin__1.inseq = 0;
	ioin__1.indir = 0;
	ioin__1.infmt = 0;
	ioin__1.inform = 0;
	ioin__1.inunf = 0;
	ioin__1.inrecl = 0;
	ioin__1.innrec = 0;
	ioin__1.inblank = 0;
	f_inqu(&ioin__1);
	if (! forfil) {
/* Writing concatenation */
	    i__1[0] = idot - 1, a__1[0] = filnm1;
	    i__1[1] = 4, a__1[1] = ".f  ";
	    s_cat(filnm1, a__1, i__1, &c__2, (ftnlen)64);
	    ioin__1.inerr = 0;
	    ioin__1.infilen = 64;
	    ioin__1.infile = filnm1;
	    ioin__1.inex = &forfil;
	    ioin__1.inopen = 0;
	    ioin__1.innum = 0;
	    ioin__1.innamed = 0;
	    ioin__1.inname = 0;
	    ioin__1.inacc = 0;
	    ioin__1.inseq = 0;
	    ioin__1.indir = 0;
	    ioin__1.infmt = 0;
	    ioin__1.inform = 0;
	    ioin__1.inunf = 0;
	    ioin__1.inrecl = 0;
	    ioin__1.innrec = 0;
	    ioin__1.inblank = 0;
	    f_inqu(&ioin__1);
	    if (! forfil) {
		io___34.ciunit = lunits_1.stderr;
		s_wsfe(&io___34);
		do_fio(&c__1, " Source file does not exist", (ftnlen)27);
		e_wsfe();
		s_stop("", (ftnlen)0);
	    }
	}
    }
    o__1.oerr = 0;
    o__1.ounit = lunits_1.infile__;
    o__1.ofnmlen = 64;
    o__1.ofnm = filnm1;
    o__1.orl = 0;
    o__1.osta = "OLD";
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.infile__;
    f_rew(&al__1);
/*  Open listing and "punched output" files. */
/*  formatted, sequential, overwrite old files if they exist */
/* Writing concatenation */
    i__1[0] = idot, a__1[0] = filnm1;
    i__1[1] = 3, a__1[1] = "lis";
    s_cat(filnm1, a__1, i__1, &c__2, (ftnlen)64);
    o__1.oerr = 0;
    o__1.ounit = lunits_1.outfil;
    o__1.ofnmlen = 64;
    o__1.ofnm = filnm1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.outfil;
    f_rew(&al__1);
/* Writing concatenation */
    i__1[0] = idot, a__1[0] = filnm1;
    i__1[1] = 3, a__1[1] = "tid";
    s_cat(filnm1, a__1, i__1, &c__2, (ftnlen)64);
    o__1.oerr = 0;
    o__1.ounit = lunits_1.punfil;
    o__1.ofnmlen = 64;
    o__1.ofnm = filnm1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = 0;
    o__1.oblnk = 0;
    f_open(&o__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.punfil;
    f_rew(&al__1);
/*  Open scratch files */
/*  unformatted, sequential, overwrite old files if they exist */
    s_copy(filnm1, "SCFIL1.TDY", (ftnlen)64, (ftnlen)10);
    o__1.oerr = 0;
    o__1.ounit = lunits_1.scfil1;
    o__1.ofnmlen = 64;
    o__1.ofnm = filnm1;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = "UNFORMATTED";
    o__1.oblnk = 0;
    f_open(&o__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil1;
    f_rew(&al__1);
    s_copy(filnm2, "SCFIL2.TDY", (ftnlen)64, (ftnlen)10);
    o__1.oerr = 0;
    o__1.ounit = lunits_1.scfil2;
    o__1.ofnmlen = 64;
    o__1.ofnm = filnm2;
    o__1.orl = 0;
    o__1.osta = 0;
    o__1.oacc = 0;
    o__1.ofm = "UNFORMATTED";
    o__1.oblnk = 0;
    f_open(&o__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil2;
    f_rew(&al__1);
    return 0;
} /* pctidy_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int quit_(integer *m)
{
    /* System generated locals */
    cllist cl__1;

    /* Builtin functions */
    integer f_clos(cllist *);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    extern /* Subroutine */ int exit_(integer *);
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */
    if (misc_1.mdeb == 0) {
	cl__1.cerr = 0;
	cl__1.cunit = lunits_1.scfil1;
	cl__1.csta = "DELETE";
	f_clos(&cl__1);
	cl__1.cerr = 0;
	cl__1.cunit = lunits_1.scfil2;
	cl__1.csta = "DELETE";
	f_clos(&cl__1);
    }
/*   All abnormal terminations are handled with Exit which sets the */
/*   error condition to its argument. */
/*   Many compilers including F77L, LF90, LF95 and g77 provide Exit as */
/*   a non-standard intrinsic. */
    exit_(m);
    return 0;
} /* quit_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int misdat_(void)
{
    return 0;
} /* misdat_ */


/*     THIS BLOCK DATA CONTAINS MISCELLANEOUS DATA STATEMENTS FOR TIDY. */

/*     VERSION 6.2 MODIFICATION ----------------------------------------- */
/*     VARIABLES WHICH ARE CONTROLLED BY SUBROUTINE CONTRL ARE SET IN */
/*     SUBROUTINE INITDY. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */

/*     /ALPHA/ */
/*    1'/ */
/*  $ IN ABOVE STATEMENT REPLACED BY X$, SINCE $ IS NOT SPECIAL */
/*  CHARACTER IN IBM 360/370 FORTRAN. */

/*     /MISCAL/ */


/*     /MISC/ */
/*     LOGICAL UNIT ASSIGNMENTS */


/*     VERSION STRING */

/* Subroutine */ int contrl_(void)
{
    /* Format strings */
    static char fmt_800[] = "(\002 CONTRL ASSIGNING VALUE \002,i6,\002 TO IN"
	    "DEX \002,i3)";

    /* System generated locals */
    address a__1[2];
    integer i__1, i__2[2];
    char ch__1[2];

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen);

    /* Local variables */
    static integer i__, j, jb, jc;
#define l15 ((integer *)&misc_1 + 23)
    static integer jl;
    static char it[2];
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    static integer jsw, javb;
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static integer idl772;
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int rstat_(void), diagno_(integer *);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int initdy_(void);
    extern /* Character */ VOID kupper_(char *, ftnlen, char *, ftnlen);
    extern /* Subroutine */ int kctset_(integer *), kwdwrt_(integer *);

    /* Fortran I/O blocks */
    static cilist io___63 = { 0, 0, 0, "(' CONTRL: ',75A1)", 0 };
    static cilist io___73 = { 0, 0, 0, fmt_800, 0 };



/*     THIS SUBROUTINE EXECUTES THE TIDY CONTROL STATEMENTS. */
/*     ALL TIDY CONTROL STATEMENTS MUST HAVE AN * PUNCHED IN COLUMN 1. */

/*     1   BASE   NOBASE   KB15 */
/*     2   IDIN   ======   KD79 */
/*     3   IDST   ======   KD79 */
/*     4   ROUT   ======   NROUT */
/*     5   STAT   ======   KD15 */
/*     6   CARD   NOCARD   MPUN */
/*     7   COLL   NOCOLL   MCOL */
/*     8   COMM   NOCOMM   MCOM */
/*     9   EXEM   NOEXEM   MEX */
/*     10  LABE   NOLABE   MLBL */
/*     11  LAST   ======   MSTOP */
/*     12  LIST   NOLIST   MLIST */
/*     13  NEWR   ======   NROUT */
/*     14  REFE   NOREFE   MREF */
/*     15  SKIP   ======   MSKP */
/*     16  STOP   ======   MSTOP */
/*     17  SERI   NOSERI   MSER  <0 USE KOL73...=0 USE BLANKS >0 SERIAL */
/*     18  RIGH   ======   MRIT */
/*     19  LEFT   ======   MRIT */
/*     20  COLU   NOCOLU   JUST */
/*     21  INDE   NOINDE   INDENT */
/*     22  DEBU   NODEBU   MDEB */
/*     23  CONT   NOCONT   MCONT */
/*     24  END    ======   SAME AS STOP */
/*     25  ANSI   NOANSI   MANSI */
/*     26  FEND   NOFEND   NFEND */
/*     27  CCHR   ======   KCTCTL */
/*     28  HTRA   ======   KHTRAN */
/*     29  DTRA   NODTRA   KDTRAN */
/*     30  DEL1   ======   KDEL1 */
/*     31  DEL2   ======   KDEL2 */
/*     32  ARET   ======   KALMRK */
/*     33  ARTR   NOARTR   KALTRN */
/*     34  BLAN   NOBLAN   KBKCOK (INCLUDE BLANK LINES IN DECK) */
/*     35  FSPL   NOFSPL   KFSPL  (SPLIT STRINGS IN INDENTED FMTS) */
/*     36  HLOG   NOHLOG   KHLOG  (LOG TRANSLATED H-FIELDS TO LISTING) */
/*     37  CASE   NOCASE   MCASE  (TRANSLATE NON-STRINGS TO UPPER CASE) */
/*     38  UCAS   ======   MCASE  (TRANSLATE NON-STRINGS TO UPPER CASE) */
/*     39  LCAS   ======   MCASE  (TRANSLATE NON-STRINGS TO LOWER CASE) */
/*     40  ENDO   NOENDO   MNDOO  (RETAIN END-DO STATEMENTS) */
/*     41  FMTB   ======   MFMTB  (BASE NUMBER FOR COLLECTED FORMATS) */
/*     42  MAXC   ======   MAXCNT (MAX. NUMBER OF CONTINUATIONS) */
/*     43  OLDS   NOOLDS   K72    (OLD DECK HAS SERIALIZATION) */
/*     44  MCHR   ======   KCMCTL (COMMENT CHARACTER, OVERRIDES MNDOO) */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*  FORTRAN LOGICAL UNITS */

    if (misc_1.mdeb > 0) {
	io___63.ciunit = lunits_1.outfil;
	s_wsfe(&io___63);
	i__1 = misc_1.jmax;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    do_fio(&c__1, miscal_1.jint + (i__ - 1 << 1), (ftnlen)2);
	}
	e_wsfe();
    }
    i__ = 14;
    misc_1.istar = -1;
    jsw = 0;
    jl = misc_1.jmax - 1;

/*     SCAN FOR 'NO' AT START */
    i__1 = jl;
    for (jb = 2; jb <= i__1; ++jb) {
	s_copy(it, miscal_1.jint + (jb - 1 << 1), (ftnlen)2, (ftnlen)2);
	if (s_cmp(it, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0) {
	    kupper_(ch__1, (ftnlen)2, it, (ftnlen)2);
	    s_copy(it, ch__1, (ftnlen)2, (ftnlen)2);
	    if (s_cmp(it, alpha_1.kabc + (i__ - 1 << 1), (ftnlen)2, (ftnlen)2)
		     != 0) {
		jc = 2;
		goto L20;
	    }
/*               MATCHED N OR O. INCREMENT CHARACTER. */
	    ++i__;
/*               IF WE'RE TO P, THEN FOUND 'NO' */
	    if (i__ > 15) {
		jsw = 1;
		jc = jb + 1;
		goto L20;
	    }
	}
/* L10: */
    }
    misc_1.istar = 1;
    return 0;

L20:
    for (j = 1; j <= 44; ++j) {
	i__ = 1;
	i__1 = misc_1.jmax;
	for (misc_1.jcol = jc; misc_1.jcol <= i__1; ++misc_1.jcol) {
	    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), 
		    (ftnlen)2);
	    s_copy(it, ch__1, (ftnlen)2, (ftnlen)2);
	    if (s_cmp(it, contdy_1.ktrl + (i__ + (j << 2) - 5 << 1), (ftnlen)
		    2, (ftnlen)2) == 0) {
		if (i__ >= 4) {
		    goto L60;
		}
		++i__;
	    } else {
		if (s_cmp(it, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0) {
		    goto L40;
		}
	    }
/* L30: */
	}
L40:
	;
    }
L50:
    misc_1.istar = 1;
    return 0;

/*     EXECUTE CONTROL STATEMENT */

L60:
    --misc_1.nrec;
/*                  JSW=1 IF CARD STARTS WITH NO */
    if (jsw == 1) {
	switch (j) {
	    case 1:  goto L500;
	    case 2:  goto L50;
	    case 3:  goto L50;
	    case 4:  goto L50;
	    case 5:  goto L50;
	    case 6:  goto L110;
	    case 7:  goto L130;
	    case 8:  goto L190;
	    case 9:  goto L290;
	    case 10:  goto L390;
	    case 11:  goto L50;
	    case 12:  goto L530;
	    case 13:  goto L50;
	    case 14:  goto L460;
	    case 15:  goto L50;
	    case 16:  goto L50;
	    case 17:  goto L490;
	    case 18:  goto L50;
	    case 19:  goto L50;
	    case 20:  goto L510;
	    case 21:  goto L520;
	    case 22:  goto L230;
	    case 23:  goto L210;
	    case 24:  goto L50;
	    case 25:  goto L90;
	    case 26:  goto L310;
	    case 27:  goto L50;
	    case 28:  goto L370;
	    case 29:  goto L260;
	    case 30:  goto L50;
	    case 31:  goto L250;
	    case 32:  goto L50;
	    case 33:  goto L70;
	    case 34:  goto L150;
	    case 35:  goto L340;
	    case 36:  goto L360;
	    case 37:  goto L160;
	    case 38:  goto L170;
	    case 39:  goto L180;
	    case 40:  goto L280;
	    case 41:  goto L320;
	    case 42:  goto L410;
	    case 43:  goto L440;
	    case 44:  goto L50;
	}
    } else {
	switch (j) {
	    case 1:  goto L530;
	    case 2:  goto L530;
	    case 3:  goto L530;
	    case 4:  goto L530;
	    case 5:  goto L530;
	    case 6:  goto L100;
	    case 7:  goto L120;
	    case 8:  goto L530;
	    case 9:  goto L530;
	    case 10:  goto L380;
	    case 11:  goto L400;
	    case 12:  goto L530;
	    case 13:  goto L420;
	    case 14:  goto L450;
	    case 15:  goto L470;
	    case 16:  goto L400;
	    case 17:  goto L480;
	    case 18:  goto L530;
	    case 19:  goto L530;
	    case 20:  goto L530;
	    case 21:  goto L530;
	    case 22:  goto L220;
	    case 23:  goto L200;
	    case 24:  goto L400;
	    case 25:  goto L80;
	    case 26:  goto L300;
	    case 27:  goto L530;
	    case 28:  goto L530;
	    case 29:  goto L240;
	    case 30:  goto L530;
	    case 31:  goto L530;
	    case 32:  goto L530;
	    case 33:  goto L530;
	    case 34:  goto L140;
	    case 35:  goto L330;
	    case 36:  goto L350;
	    case 37:  goto L530;
	    case 38:  goto L530;
	    case 39:  goto L530;
	    case 40:  goto L270;
	    case 41:  goto L530;
	    case 42:  goto L530;
	    case 43:  goto L430;
	    case 44:  goto L530;
	}
    }

/*     IF FALL THRU HERE, ABORT - ABOVE LIST NOT COMPLETE. */
    diagno_(&c__48);

/*                  NOARTRAN */
L70:
    s_copy(alpha_1.kaltrn, alpha_1.kbl, (ftnlen)2, (ftnlen)2);
    return 0;
/*                  ANSI */
L80:
    misc_1.mansi = 0;
    return 0;
/*                  NOANSI */
L90:
    misc_1.mansi = 1;
    return 0;
/*                  CARD */
L100:
    misc_1.mpun = -1;
    misc_1.kpun = -1;
    return 0;
/*                  NOCARD */
L110:
    misc_1.mpun = 0;
    misc_1.kpun = 0;
    return 0;
/*                  COLL */
L120:
    misc_1.mcol = -1;
    return 0;
/*                  NOCOLL */
L130:
    misc_1.mcol = 0;
    return 0;
/*                  BLAN */
L140:
    misc_1.kbkcok = 1;
    return 0;
/*                  NOBLAN */
L150:
    misc_1.kbkcok = 0;
    return 0;
/*                  NOCASE */
L160:
    misc_1.mcase = -1;
    return 0;

/*                  NOUCASE - CHANGE TO *LCASE */
L170:
    j = 39;
    idl772 = 0;
    goto L570;

/*                  NOLCASE - CHANGE TO *UCASE */
L180:
    j = 38;
    idl772 = 0;
    goto L570;
/*                  NOCOMM */
L190:
    misc_1.mcom = 0;
    return 0;
/*                  CONT */
L200:
    misc_1.mcont = 1;
    return 0;
/*                  NOCONT */
L210:
    misc_1.mcont = 0;
    return 0;
/*                  DEBUG */
L220:
    misc_1.mdeb = 1;
    return 0;
/*                  NODEBUG */
L230:
    misc_1.mdeb = 0;
    return 0;
/*                  DTRAN */
L240:
    misc_1.kdtran = 1;
    return 0;
/*                  NODEL2 -- IMPLIES *NODTRAN */
L250:
    s_copy(alpha_1.kdel2, "\"\"", (ftnlen)2, (ftnlen)2);
/*                  NODTRAN */
L260:
    misc_1.kdtran = 0;
    return 0;
/*                  ENDO */
L270:
    misc_1.mndoo = 1;
    return 0;
/*                  NOENDO */
L280:
    misc_1.mndoo = 0;
    return 0;
/*                  NOEXEM */
L290:
    *mex = 0;
    return 0;
/*                  FEND */
L300:
    misc_1.nfend = 0;
    return 0;
/*                  NOFEND */
L310:
    misc_1.nfend = 1;
    return 0;
/*                  NOFMTB */
L320:
    misc_1.mfmtb = 0;
    return 0;
/*                  FSPL */
L330:
    misc_1.kfspl = 0;
    return 0;
/*                  NOFSPL */
L340:
    misc_1.kfspl = 1;
    return 0;
/*                  HLOG */
L350:
    misc_1.khlog = 0;
    return 0;
/*                  NOHLOG */
L360:
    misc_1.khlog = 1;
    return 0;
/*                  NOHTRAN */
L370:
    misc_1.khtran = 0;
    return 0;
/*                  LABE */
L380:
    misc_1.mlbl = -1;
    return 0;
/*                  NOLABE */
L390:
    misc_1.mlbl = 0;
    return 0;
/*                  LAST/STOP */
L400:
    misc_1.mstop = -1;
    return 0;
/*                  NOMAXC - DEFAULTS TO NQCNTS */
L410:
    misc_1.maxcnt = 40;
    return 0;
/*                  NEWR */
L420:
    initdy_();
    return 0;
/*                  OLDS - OLD DECK HAS SERIAL */
L430:
    misc_1.k72 = 72;
    return 0;
/*                  NOOLDS - OLD DECK HAS SERIAL */
L440:
    misc_1.k72 = 80;
    return 0;
/*                  REFE */
L450:
    misc_1.mref = -1;
    return 0;
/*                  NOREFE */
L460:
    misc_1.mref = 0;
    return 0;
/*                  SKIP */
L470:
    misc_1.mskp = -1;
    return 0;
/*                  SERI */
L480:
    misc_1.mser = -1;
    return 0;
/*                  NOSERI */
L490:
    misc_1.mser = 0;
    return 0;
/*                  NOBASE */
L500:
    misc_1.kb15 = 0;
    return 0;

/*                  NOCOLU */
L510:
    misc_1.just = 0;
    return 0;

/*                  NOINDENT */
L520:
    misc_1.indent = 0;
    return 0;

/*     GET NUMBER FOLLOWING (=) SIGN. */

L530:
    javb = misc_1.jcol;
    i__1 = misc_1.jmax;
    for (misc_1.jcol = javb; misc_1.jcol <= i__1; ++misc_1.jcol) {
	if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kspk, (
		ftnlen)2, (ftnlen)2) == 0) {
	    goto L550;
	}
/* L540: */
    }
    misc_1.l772 = 1.;
    goto L560;
L550:
    ++misc_1.jcol;
    javb = misc_1.jcol;
    rstat_();

/*     EVERYTHING REQUIRES AN INTEGER - THE DOUBLE PRECISION IS TO */
/*      HANDLE SOME BIG CONSTANTS IN DATA STATEMENTS WITH RSTAT. */
L560:
    idl772 = (integer) misc_1.l772;
    if (misc_1.mdeb > 0) {
	io___73.ciunit = lunits_1.outfil;
	s_wsfe(&io___73);
	do_fio(&c__1, (char *)&idl772, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&j, (ftnlen)sizeof(integer));
	e_wsfe();
    }
L570:
    switch (j) {
	case 1:  goto L580;
	case 2:  goto L630;
	case 3:  goto L630;
	case 4:  goto L650;
	case 5:  goto L700;
	case 6:  goto L50;
	case 7:  goto L50;
	case 8:  goto L610;
	case 9:  goto L620;
	case 10:  goto L50;
	case 11:  goto L50;
	case 12:  goto L770;
	case 13:  goto L50;
	case 14:  goto L50;
	case 15:  goto L50;
	case 16:  goto L50;
	case 17:  goto L50;
	case 18:  goto L750;
	case 19:  goto L760;
	case 20:  goto L710;
	case 21:  goto L740;
	case 22:  goto L50;
	case 23:  goto L50;
	case 24:  goto L50;
	case 25:  goto L50;
	case 26:  goto L50;
	case 27:  goto L780;
	case 28:  goto L730;
	case 29:  goto L50;
	case 30:  goto L780;
	case 31:  goto L780;
	case 32:  goto L780;
	case 33:  goto L780;
	case 34:  goto L50;
	case 35:  goto L50;
	case 36:  goto L50;
	case 37:  goto L590;
	case 38:  goto L590;
	case 39:  goto L600;
	case 40:  goto L50;
	case 41:  goto L720;
	case 42:  goto L640;
	case 43:  goto L50;
	case 44:  goto L780;
    }

/*     IF FALL THRU HERE, ABORT - ABOVE LIST NOT COMPLETE. */
    diagno_(&c__48);

/*                  BASE */
L580:
    misc_1.kb15 = idl772;
    return 0;

/*                  CASE, UCAS */
/*     0 = ALL, 1 = KEYWORDS ONLY, 2 = NON-KEYWORDS ONLY */
L590:
    misc_1.mcase = 0;
    if (idl772 % 2 == 0) {
	kctset_(&c__0);
    }
    if (idl772 <= 1) {
	kwdwrt_(&c_n1);
    }
    return 0;
/*                  LCASE */
L600:
    misc_1.mcase = 0;
    if (idl772 % 2 == 0) {
	kctset_(&c__1);
    }
    if (idl772 <= 1) {
	kwdwrt_(&c_n2);
    }
    return 0;
/*                  COMM */
/*     KEEP *COMM = *COMM=1   FOR UPWARD COMPATIBILITY */
/*      *COMM=2 IS ALSO EQUIVALENT... */
L610:
    misc_1.mcom = idl772;
    if (misc_1.mcom <= 2) {
	misc_1.mcom = -1;
    } else if (misc_1.mcom > 7) {
	misc_1.mcom = 7;
    }
    return 0;
/*                  EXEM */
L620:
    *mex = idl772;
/*     KEEP *EXEM = *EXEM=1   FOR UPWARD COMPATIBILITY */
    if (*mex <= 1) {
	*mex = -1;
    } else if (*mex == 2) {
	*mex = 1;
    } else {
	goto L50;
    }
    return 0;
/*                  IDIN/IDST */
L630:
    misc_1.kd79 = max(idl772,1);
    return 0;

/*                  MAXCNT */
L640:
    misc_1.maxcnt = max(idl772,1);
    if (misc_1.maxcnt > 40) {
	diagno_(&c__50);
    }
    return 0;
/*                  ROUT */
/*     USE TWO LETTERS FOR ROUTINE CODE, CONSTRUCT VALUE OF NROUT. */
L650:
    misc_1.jcol = javb - 1;
    misc_1.nrout = 0;
    for (i__ = 1; i__ <= 2; ++i__) {
L660:
	++misc_1.jcol;
	kupper_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (
		ftnlen)2);
	s_copy(it, ch__1, (ftnlen)2, (ftnlen)2);
	if (s_cmp(it, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0) {
	    goto L660;
	}
	if (s_cmp(it, alpha_1.kerm, (ftnlen)2, (ftnlen)2) == 0) {
	    goto L690;
	}
	for (j = 1; j <= 26; ++j) {
	    if (s_cmp(it, alpha_1.kabc + (j - 1 << 1), (ftnlen)2, (ftnlen)2) 
		    != 0) {
		goto L670;
	    }
	    misc_1.nrout = misc_1.nrout * 26 + j;
	    goto L680;
L670:
	    ;
	}
L680:
	;
    }

L690:
/* Computing MAX */
    i__1 = misc_1.nrout - 1;
    misc_1.nrout = max(i__1,1);
    return 0;
/*                  STAT */
L700:
    misc_1.kd15 = max(idl772,1);
    return 0;
/*                  COLU */
L710:
    misc_1.just = max(idl772,7);
    return 0;
/*                  FMTB */
L720:
    misc_1.mfmtb = max(idl772,0);
    return 0;
/*                  HTRAN */
L730:
    misc_1.khtran = min(idl772,3);
    if (misc_1.khtran < 0) {
	misc_1.khtran = 0;
    }
    return 0;
/*                            INDENT */
L740:
    misc_1.indent = min(10,idl772);
    return 0;
/*                            RIGHT */
L750:
    misc_1.mrit = min(idl772,5);
    if (misc_1.mrit == 1) {
	misc_1.mrit = 5;
    }
    return 0;
/*                            LEFT */
L760:
    misc_1.mrit = max(idl772,1);
    if (misc_1.mrit > 5) {
	misc_1.mrit = 1;
    }
    misc_1.mrit = -misc_1.mrit;
    return 0;
/*                            LIST/NOLIST */
L770:
    if (idl772 == 2) {
	if (jsw == 0) {
/*                            LIST=2. */
	    misc_1.kprin = 1;
	    misc_1.mprin = 1;
	} else {
/*                            NOLIST=2. */
	    misc_1.mprin = 0;
	    misc_1.kprin = 0;
	}
    } else {
	if (jsw == 0) {
/*                            LIST */
	    misc_1.mlist = -1;
	} else {
/*                            NOLIST */
	    misc_1.mlist = 0;
	}
    }
    return 0;

/*                  CARDS USING CHARACTER ARGUMENT */
L780:
    misc_1.jcol = javb - 1;
L790:
    ++misc_1.jcol;
    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)
	    2);
    s_copy(it, ch__1, (ftnlen)2, (ftnlen)2);
    if (s_cmp(it, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0) {
	goto L790;
    }
    if (j == 27) {
/*                            CCHR (CONTINUATION CHAR) */
	if (s_cmp(it, alpha_1.kerm, (ftnlen)2, (ftnlen)2) != 0 && s_cmp(it, 
		alpha_1.kdig, (ftnlen)2, (ftnlen)2) != 0) {
	    misc_1.kctctl = 1;
	    s_copy(alpha_1.kctchr, miscal_1.jint + (misc_1.jcol - 1 << 1), (
		    ftnlen)2, (ftnlen)2);
	    return 0;
	}
/*     NO CHARACTER SPECIFIED OR ZERO. */
	misc_1.kctctl = 0;
	s_copy(alpha_1.kctchr, alpha_1.kspk + 18, (ftnlen)2, (ftnlen)2);
	if (s_cmp(it, alpha_1.kdig, (ftnlen)2, (ftnlen)2) == 0) {
	    diagno_(&c__38);
	}
    } else if (j == 30) {
/*                            DEL1 (PRIMARY STRING DELIMITER) */
	s_copy(alpha_1.kdel1, alpha_1.kbl, (ftnlen)2, (ftnlen)2);
	*(unsigned char *)alpha_1.kdel1 = *(unsigned char *)it;
/* Writing concatenation */
	i__2[0] = 1, a__1[0] = alpha_1.kdel1;
	i__2[1] = 1, a__1[1] = alpha_1.kat + 1;
	s_cat(alpha_1.kapstr, a__1, i__2, &c__2, (ftnlen)2);
    } else if (j == 31) {
/*                            DEL2 (SECONDARY STRING DELIMITER) */
	s_copy(alpha_1.kdel2, alpha_1.kbl, (ftnlen)2, (ftnlen)2);
	*(unsigned char *)alpha_1.kdel2 = *(unsigned char *)it;
    } else if (j == 32) {
/*                            ARET (ALT. RETURNS IN CALLS) */
	s_copy(alpha_1.kalmrk, it, (ftnlen)2, (ftnlen)2);
    } else if (j == 33) {
/*                            ARTR (TRANSLATE KALMRK TO THIS) */
	s_copy(alpha_1.kaltrn, it, (ftnlen)2, (ftnlen)2);
    } else if (j == 44) {
/*                            MCHR (COMMENT CHARACTER OVERRIDE) */
	if (s_cmp(it, alpha_1.kerm, (ftnlen)2, (ftnlen)2) != 0 && s_cmp(it, 
		alpha_1.kdig, (ftnlen)2, (ftnlen)2) != 0) {
	    misc_1.kcmctl = 1;
	    s_copy(alpha_1.kcmchr, miscal_1.jint + (misc_1.jcol - 1 << 1), (
		    ftnlen)2, (ftnlen)2);
	    return 0;
	}
/*     NO CHARACTER SPECIFIED OR ZERO. */
	misc_1.kcmctl = 1;
	s_copy(alpha_1.kcmchr, "C", (ftnlen)2, (ftnlen)1);
	if (s_cmp(it, alpha_1.kdig, (ftnlen)2, (ftnlen)2) == 0) {
	    diagno_(&c__54);
	}
    }
    return 0;

} /* contrl_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int ctldat_(void)
{
    return 0;
} /* ctldat_ */



/*     /CONTDY/ */

/* Subroutine */ int initdy_(void)
{
    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int kctset_(integer *);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int kwdwrt_(integer *);


/*     INITIALIZE TIDY -- USED AT START AND WHEN *NEWR EXECUTED. */


/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    misc_1.indent = 2;
    misc_1.just = 7;
    misc_1.k72 = 72;
    s_copy(alpha_1.kalmrk, "* ", (ftnlen)2, (ftnlen)2);
    s_copy(alpha_1.kaltrn, "  ", (ftnlen)2, (ftnlen)2);
    misc_1.kbkcok = 1;
    s_copy(alpha_1.kblcmt, " @", (ftnlen)2, (ftnlen)2);
    misc_1.kb15 = 0;
    misc_1.kctctl = 1;
    s_copy(alpha_1.kctchr, alpha_1.kspk + 24, (ftnlen)2, (ftnlen)2);
    misc_1.kcmctl = 0;
    s_copy(alpha_1.kcmchr, alpha_1.kabc + 4, (ftnlen)2, (ftnlen)2);
    misc_1.kd15 = 10;
    misc_1.kd79 = 1;
    s_copy(alpha_1.kdel1, "' ", (ftnlen)2, (ftnlen)2);
    s_copy(alpha_1.kdel2, "\"\"", (ftnlen)2, (ftnlen)2);
    misc_1.kdtran = 0;
    misc_1.khtran = 1;
    misc_1.khlog = 0;
    misc_1.kprin = 0;
    misc_1.kpun = -1;
    misc_1.kfspl = 1;
    misc_1.mansi = 1;
    misc_1.maxcnt = 19;
    misc_1.mcase = 0;
    misc_1.mcol = 0;
    misc_1.mcom = -1;
    misc_1.mcont = 0;
    *mex = 0;
    misc_1.mfmtb = 0;
    misc_1.mlbl = 0;
    misc_1.mlist = 0;
    misc_1.mndoo = 1;
    misc_1.mprin = 0;
    misc_1.mpun = -1;
    misc_1.mref = 0;
    misc_1.mrit = 5;
    misc_1.mser = 0;
    misc_1.nfend = 0;
    misc_1.nlhtrn = 0;
    misc_1.nrout = 1;
/*     DEFAULT CASE TRANSLATIONS = UPPER */

/*     SUBROUTINE KWDWRT WRITES FORTRAN KEYWORDS IN DESIRED CASE. */
/*       CHANGE (-1) TO (-2) FOR DEFAULT TRANSLATION TO LOWER-CASE. */
    kwdwrt_(&c_n1);

/*     SUBROUTINE KCTSET CONTROLS TRANSLATION OF EXECUTABLE CODE WHICH */
/*      IS NOT FORTRAN KEYWORDS. */
/*       CHANGE (1) TO (0) FOR DEFAULT TRANSLATION TO UPPER-CASE */
    kctset_(&c__1);

    return 0;
} /* initdy_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int kwscan_(integer *jt, integer *kstcr)
{
    /* Format strings */
    static char fmt_70[] = "(\002 KWSCAN checking \002,10a1,\002 mode = \002"
	    ",i2)";
    static char fmt_80[] = "(\002   NINS  =\002,i3,\002 KLASS  =\002,i3,\002"
	    " JTYPE =\002,i3/\002   NANSI =\002,i3,\002 KSTROK =\002,i3,\002 "
	    "KPOS  =\002,i3)";
    static char fmt_90[] = "(\002  --- no match\002)";

    /* System generated locals */
    integer i__1, i__2;
    char ch__1[2];

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen), s_wsfe(cilist *), do_fio(
	    integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
    static integer nl, it, nu;
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    static char wkstr[2*10];
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Character */ VOID kupper_(char *, ftnlen, char *, ftnlen);

    /* Fortran I/O blocks */
    static cilist io___96 = { 0, 0, 0, fmt_70, 0 };
    static cilist io___98 = { 0, 0, 0, fmt_80, 0 };
    static cilist io___99 = { 0, 0, 0, fmt_90, 0 };


/*     PARAMETER (NKST=83) */

/*     THIS ROUTINE SCANS FOR FORTRAN KEYWORDS, SETS JT TO CORRECT */
/*     TYPE IF FOUND, ELSE ZERO. */

/*     INPUT: IF JT = 0, SCANS WHOLE LIST */
/*               JT > 0, ONLY SCANS THAT WORD. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*  FORTRAN LOGICAL UNITS */

    /* Parameter adjustments */
    --kstcr;

    /* Function Body */
    if (*jt == 0) {
	nl = 1;
	nu = 86;
/*     ZERO OUT KSTCR FOR NEW SCANS ONLY */
	for (i__ = 1; i__ <= 5; ++i__) {
	    kstcr[i__] = 0;
/* L10: */
	}
    } else {
	nl = *jt;
	nu = *jt;
    }

/*     MAKE UPPER-CASE COPY OF 10 CHARS (MAX STRING LENGTH) */
    misc_1.last = misc_1.jcol - 1;
    for (i__ = 1; i__ <= 10; ++i__) {
L20:
	++misc_1.last;
	if (misc_1.last > misc_1.jmax) {
	    s_copy(wkstr + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (ftnlen)2);
	} else {
	    if (s_cmp(miscal_1.jint + (misc_1.last - 1 << 1), alpha_1.kbl, (
		    ftnlen)2, (ftnlen)2) == 0) {
		goto L20;
	    }
	    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.last - 1 << 1), 
		    (ftnlen)2);
	    s_copy(wkstr + (i__ - 1 << 1), ch__1, (ftnlen)2, (ftnlen)2);
	}
/* L30: */
    }
    if (misc_1.mdeb > 0) {
	io___96.ciunit = lunits_1.outfil;
	s_wsfe(&io___96);
	do_fio(&c__10, wkstr, (ftnlen)2);
	do_fio(&c__1, (char *)&(*jt), (ftnlen)sizeof(integer));
	e_wsfe();
    }

    i__1 = nu;
    for (it = nl; it <= i__1; ++it) {
	misc_1.nins = kstnum_1.kstc[it * 6 - 6];

	i__2 = misc_1.nins;
	for (i__ = 1; i__ <= i__2; ++i__) {
	    if (s_cmp(wkstr + (i__ - 1 << 1), kstcom_1.kst + (i__ + it * 10 - 
		    11 << 1), (ftnlen)2, (ftnlen)2) != 0) {
		goto L60;
	    }
/* L40: */
	}
	*jt = kstnum_1.kstc[it * 6 - 1];
	for (i__ = 1; i__ <= 5; ++i__) {
	    kstcr[i__] = kstnum_1.kstc[i__ + it * 6 - 7];
/* L50: */
	}
	if (misc_1.mdeb > 0) {
	    io___98.ciunit = lunits_1.outfil;
	    s_wsfe(&io___98);
	    do_fio(&c__5, (char *)&kstcr[1], (ftnlen)sizeof(integer));
	    do_fio(&c__1, (char *)&(*jt), (ftnlen)sizeof(integer));
	    e_wsfe();
	}
	return 0;
/*                  LOOP FOR NEXT STATEMENT. */
L60:
	;
    }

/*     NO MATCH. */
    if (misc_1.mdeb > 0) {
	io___99.ciunit = lunits_1.outfil;
	s_wsfe(&io___99);
	e_wsfe();
    }
    *jt = 0;

    return 0;


} /* kwscan_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int kstdat_(void)
{
    return 0;
} /* kstdat_ */


/*    X    ,KST81 ,KST82 ,KST83 */


/*     CHARACTER*2 KST81(10),KST82(10),KST83(10) */

/*    X    ,KSTC81 ,KSTC82 ,KSTC83 */
/*     DIMENSION KSTC81(6),KSTC82(6),KSTC83(6) */

/*     /KST/ */

/*     /KSTNUM/ */
/*     ********* NOTE - KPOS IS ADDED TO INSULATE PASS1 FROM ADDITIONS */
/*     TO ABOVE TABLE.  WHEN ADDING NEW STATEMENTS, SET KPOS TO THE */
/*     NEW VALUE OF NKST RATHER THAN THE ORDINAL POSITION OF THE NEW */
/*     ADDITION TO THE TABLE. */
/*      (NOTE WHEN ADDING - SIMILAR STRINGS MUST BE IN DESCENDING ORDER */
/*       BY LENGTH, I.E. END MUST FOLLOW ENDIF) */
/*     WARNING - DO NOT MOVE LINES 69 OR 82 WITHOUT ALTERING PASS1 - */
/*               THERE ARE EXPLICIT REFERENCES TO THESE LINES. */

/*                KLASS  DESCRIPTION */
/*                  0.   CONTROL CARD */
/*                  1.   COMMENT */
/*                  2.   HEADER */
/*                  3.   NO STATEMENT NO ALLOWED (NON-EXECTUABLE) */
/*                  4.   CONTINUE */
/*                  5.   FORMAT STATEMENT. */
/*                  6.   STATEMENT NO. ALLOWED, NO REFERENCES */
/*                  7.   REFERENCES PRESENT, STATEMENT NO. ALLOWED. */
/*                  8.   END */
/*                  9.   INTRODUCTORY */
/*                  10.  DO */
/*                  11.  ELSE,ENDIF,ELSEIF, UNRECOGNIZED */
/*                       (TRANSFER CAN GET HERE REGARDLESS OF LABEL) */

/*     KLASS 0.   CONTROL CARD */
/*             RESERVED FOR FUTURE DEVELOPMENT. */


/*                   NINS  KLASS  JTYPE NANSI   KSTROK     KPOS */
/*                   NINS  KLASS  JTYPE NANSI   KSTROK     KPOS */

/* Subroutine */ int adnum_(integer *jerr)
{
    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int rlist_(void), diagno_(integer *);
#define icolsv ((integer *)&misc_1 + 28)

/*     ADDS STATEMENT NUMBER TO CROSS-REF LIST, AND PLACES SPECIAL */
/*     MARK IN OUTPUT CARD IMAGE. */

/*     JERR = RETURN CODE 0 = NORMAL TERMINATION */
/*                        1 = CROSS-REF TABLE OVERFLOW */
/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    ++misc_1.icol;
    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), alpha_1.klr2, (ftnlen)2, (
	    ftnlen)2);
    if (*nxrf <= misc_1.mxref) {
	*jerr = 0;
	_BLNK__1.ioutn[*nxrf - 1] = (integer) misc_1.l772;
	++(*nxrf);
	rlist_();
    } else {
	*jerr = 1;
/*          TOO MANY CROSS-REFERENCES */
	diagno_(&c__35);
	misc_1.mp2 = 0;
    }
    return 0;
} /* adnum_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


logical bakscn_(char *c1, char *c2, ftnlen c1_len, ftnlen c2_len)
{
    /* System generated locals */
    logical ret_val;
    char ch__1[2];

    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
    static integer ip;
    static char jt[2];
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    static char jnt[2];
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Character */ VOID kupper_(char *, ftnlen, char *, ftnlen);


/*     SCANS A STRING BACKWARD FROM CURRENT POSITION FOR C1 AND C2 */
/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    ip = misc_1.jcol;
/*     FIRST BACK TO LCPY */
L5:
    if (s_cmp(miscal_1.jint + (ip - 1 << 1), miscal_1.lcpy, (ftnlen)2, (
	    ftnlen)2) != 0) {
	--ip;
	goto L5;
    }

/*     NOW SCAN FOR C1, C2 */
    s_copy(jt, c1, (ftnlen)2, (ftnlen)2);
    i__ = 1;
L15:
    --ip;
    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (ip - 1 << 1), (ftnlen)2);
    s_copy(jnt, ch__1, (ftnlen)2, (ftnlen)2);
    if (s_cmp(jnt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0) {
	goto L15;
    }
    if (s_cmp(jnt, jt, (ftnlen)2, (ftnlen)2) != 0) {
	ret_val = FALSE_;
	return ret_val;
    }
    if (i__ == 1) {
	s_copy(jt, c2, (ftnlen)2, (ftnlen)2);
	i__ = 2;
	goto L15;
    }
    ret_val = TRUE_;
    return ret_val;
} /* bakscn_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int copy_(integer *n)
{
    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
    static char jt[2];
    static integer nt;
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int diagno_(integer *);
    static logical savblk;
#define icolsv ((integer *)&misc_1 + 28)


/*     COPY NON-BLANK CHARACTERS FROM JINT TO IOUT. */
/*       (UNLESS *EXEM IS SET, THEN COPY BLANKS ALSO) */

/*                        ===   ON ENTRY   === */
/*     N .LT. 0 COPIES UNTIL PARENTHESIS COUNT IS ZERO. */
/*     N .EQ. 0 COPIES ALL REMAINING NON-BLANK DATA FROM JINT TO IOUT. */
/*     N .GT. 0 COPIES N NON-BLANK DATA FROM JINT TO IOUT. */
/*     THE FIRST ITEM INSPECTED IS JINT(JCOL). */
/*     THE FIRST ITEM STORED GOES TO IOUT(ICOL+1). */

/*                        ===   ON EXIT   === */
/*     THE LAST ITEM INSPECTED WAS JINT(JCOL-1). */
/*     THE LAST ITEM STORED WENT TO IOUT(ICOL) AND IS IN LCPY. */

/*     MEOF .LT. 0  FOR NORMAL EXIT. */
/*     MEOF .EQ. 0  FOR KERM FOUND WHILE COPYING  ALL REMAINING DATA, */
/*                  OR FOR KERM FOUND BEFORE LEFT PARENTHESIS. */
/*     MEOF .GT. 0  FOR MISSING RIGHT PARENTHESIS, OR FOR MEOF =0 ON */
/*                  ENTRY TO COPY. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

    if (misc_1.meof >= 0 || misc_1.jcol > misc_1.jmax) {
	misc_1.meof = 1;
	s_copy(miscal_1.lcpy, alpha_1.kerm, (ftnlen)2, (ftnlen)2);
	return 0;
    }

/*     SET BLANK STRIP MODE */
    savblk = *mex > 0 || *mex < 0 && (*klass == 3 || *klass == 5);

    nt = *n;
    if (nt == 0) {

/*     COPY ALL REMAINING NON-BLANK CHARACTERS. */

L10:
	s_copy(jt, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)
		2);
	if (s_cmp(jt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0 || savblk) {
	    ++misc_1.icol;
	    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), jt, (ftnlen)2, (
		    ftnlen)2);
	}
	if (s_cmp(jt, alpha_1.kerm, (ftnlen)2, (ftnlen)2) != 0) {
	    ++misc_1.jcol;
	    goto L10;
	}
	goto L70;

    } else if (nt > 0) {

/*     COPY --N-- NON-BLANK CHARACTERS. */

L20:
	s_copy(jt, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)
		2);
	if (s_cmp(jt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0) {
	    ++misc_1.icol;
	    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), jt, (ftnlen)2, (
		    ftnlen)2);
	    --nt;
	    if (nt == 0) {
		goto L80;
	    }
	    if (s_cmp(jt, alpha_1.kerm, (ftnlen)2, (ftnlen)2) == 0) {
		goto L70;
	    }
	}
	++misc_1.jcol;
	goto L20;
    } else {

/*     COPY TO PARENTHESIS COUNT OF ZERO. */
/*     LOOK FOR LEFT PARENTHESIS. */

L30:
	s_copy(jt, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)
		2);
	if (s_cmp(jt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0) {
	    ++misc_1.icol;
	    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), jt, (ftnlen)2, (
		    ftnlen)2);
	    s_copy(miscal_1.lcpy, jt, (ftnlen)2, (ftnlen)2);
	    if (s_cmp(jt, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) == 0) {
/*        HAVE LEFT PARENTHESIS, COPY UNTIL COUNT OF ZERO. */
		misc_1.npar = 1;
L40:
		++misc_1.jcol;
		s_copy(jt, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, 
			(ftnlen)2);
		if (s_cmp(jt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0) {
		    ++misc_1.icol;
		    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), jt, (
			    ftnlen)2, (ftnlen)2);
		    s_copy(miscal_1.lcpy, jt, (ftnlen)2, (ftnlen)2);
		    if (s_cmp(jt, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) != 
			    0) {
			if (s_cmp(jt, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) 
				!= 0) {
			    if (s_cmp(jt, alpha_1.kerm, (ftnlen)2, (ftnlen)2) 
				    != 0) {
				goto L40;
			    }
			    diagno_(&c__2);
			    s_copy(miscal_1.lcpy, alpha_1.kerm, (ftnlen)2, (
				    ftnlen)2);
			    goto L60;
			}
			--misc_1.npar;
/*                         IF (NPAR) 50,80,40 */
			if (misc_1.npar < 0) {
			    goto L50;
			} else if (misc_1.npar == 0) {
			    goto L80;
			} else {
			    goto L40;
			}
		    }
		    ++misc_1.npar;
		} else if (savblk) {
		    ++misc_1.icol;
		    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), jt, (
			    ftnlen)2, (ftnlen)2);
		}
		goto L40;
	    }
	    if (s_cmp(jt, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) == 0) {
		goto L50;
	    }
	    if (s_cmp(jt, alpha_1.kerm, (ftnlen)2, (ftnlen)2) == 0) {
		goto L70;
	    }
	} else if (savblk) {
	    ++misc_1.icol;
	    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), jt, (ftnlen)2, (
		    ftnlen)2);
	}
	++misc_1.jcol;
	goto L30;

L50:
	diagno_(&c__3);
L60:
	misc_1.meof = 1;
	++misc_1.jcol;
	return 0;
    }

L70:
    s_copy(miscal_1.lcpy, alpha_1.kerm, (ftnlen)2, (ftnlen)2);
    --misc_1.icol;
    misc_1.meof = 0;
    return 0;

L80:
    ++misc_1.jcol;
    s_copy(miscal_1.lcpy, jt, (ftnlen)2, (ftnlen)2);
    return 0;
} /* copy_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int diagno_(integer *n)
{
    /* Initialized data */

    static char ermsg[60*54] = "THE ABOVE STATEMENT IS ILLEGAL AND HAS BEEN "
	    "DELETED.        " "THE ABOVE STATEMENT HAS A MISSING RIGHT PAREN"
	    "THESIS.        " "THE ABOVE STATEMENT HAS AN EXCESS RIGHT PARENT"
	    "HESIS.        " "THE ABOVE STATEMENT INCORRECTLY TERMINATES A DO"
	    " LOOP.       " "THE ABOVE STATEMENT CANNOT BE REACHED BY THE PRO"
	    "GRAM.       " "STATEMENT NUMBER TABLE FULL.  RENUMBER PASS DELET"
	    "ED.        " "REFERENCE NUMBER TABLE FULL.  RENUMBER PASS DELETE"
	    "D.        " "THE ABOVE STATEMENT IS OBSOLETE AND IS DELETED.    "
	    "         " "ABOVE STATEMENT HAS AN ILLEGAL FIRST SPECIAL CHARACT"
	    "ER.     " "ILLEGAL DATA, FUNCTION, OR SUBROUTINE STATEMENT.     "
	    "       " "THE ABOVE COMMON OR DATA STATEMENT IS MISSING A (/).  "
	    "      " "THE ABOVE CONTINUE STATEMENT IS REDUNDANT AND IS DELETE"
	    "D.   " "THE ABOVE DIMENSION STATEMENT IS NOT COMPLETE.          "
	    "    " "W A R N I N G .  STATEMENT SHOULD BE FIRST IN ROUTINE.   "
	    "   " "THE ABOVE DO STATEMENT HAS AN INVALID TERMINAL STATEMENT. "
	    "  " "W A R N I N G .  UNSATISFIED DO LOOPS.                      "
	     "UNNUMBERED OR INVALID FORMAT STATEMENT DELETED.             " 
	    "WARNING.  ABOVE STATEMENT IS POOR PROGRAMMING PRACTICE.     " 
	    "ABOVE GO TO STATEMENT IS ILLEGAL.                           " 
	    "ILLEGAL ARITHMETIC IF STATEMENT.   IF (ARITH) 1,2,3         " 
	    "ABOVE NAMELIST STATEMENT MISSING (/).                       " 
	    "ILLEGAL READ, WRITE , OR PUNCH STATEMENT.                   " 
	    "ILLEGAL READ (12) LIST, OR WRITE (12) LIST, STATEMENT.      " 
	    "DO LOOP TABLE FULL.  RENUMBER PASS DELETED.                 " 
	    "W A R N I N G .  COMMA INSERTED FOLLOWING X IN ABOVE FORMAT." 
	    "TIDY CANNOT PROCESS THIS CLASS OF PROGRAM.  (COPY EXECUTED.)" 
	    "WARNING.  ABOVE DO-LOOP TERMINUS PREVIOUSLY REFERENCED.     " 
	    "WARNING.  TIDY MAY HAVE CHANGED CARD 2 OF THIS ROUTINE      " 
	    "W A R N I N G .  END CARD INSERTED.                         " 
	    "THE ABOVE STATEMENT IS TRANSMITTED WITHOUT PROCESSING.      " 
	    "ILLEGAL CLOSE, INQUIRE, OR OPEN STATEMENT                   " 
	    "W A R N I N G .   UNBALANCED ELSE/ELSEIF/ENDIF STATEMENT    " 
	    "W A R N I N G .   UNSATISFIED IF BLOCKS.                    " 
	    "W A R N I N G .   ABOVE STATEMENT NOT ANSI FORTRAN 77.      " 
	    "TOO MANY REFERENCES IN ABOVE. RENUMBER PASS DELETED.        " 
	    "W A R N I N G .   NON-ANSI (L OR R) HOLLERITH SPEC.         " 
	    "ABOVE STATEMENT HAS TOO MANY CONTINUATION LINES.            " 
	    "CCHR CARD IGNORED:   CANNOT USE ZERO.                       " 
	    ">>> HOLLERITH CONSTANT CONVERTED <<<                        " 
	    "W A R N I N G. *n PRECISION ON NUMERIC/LOGICAL VARS NOT ANSI" 
	    "W A R N I N G.    VARIABLE NAME LONGER THAN 6 CHARACTERS    " 
	    "W A R N I N G.    INITIALIZED TYPE DECLARATIONS NOT ANSI    " 
	    "MORE <END DO> THAN <DO> STATEMENTS                          " 
	    "FATAL ERROR - DO LIST UNDERFLOW                             " 
	    "FATAL ERROR                                                 " 
	    "FATAL PROBLEM IN DO-LOOP RENUMBERING - SUBROUTINE EDIT      " 
	    "ABNORMAL TERMINATION                                        " 
	    "CONTRL INTERNAL ERROR - A COMPUTED GO TO LIST IS TOO SHORT  " 
	    "*FMTB CONFLICTS WITH REGULAR STATEMENTS - IGNORED.          " 
	    "TOO MANY CONTINUATION CARDS REQUESTED - RECOMPILE           " 
	    "COLUMNS 73-80 IN ABOVE ADDED TO STATEMENT - CHECK CAREFULLY " 
	    "BLANKS REMOVED FROM STRING INCLUDING COLS 73-80             " 
	    "REFERENCE TO MISSING STATEMENT NUMBER IN NEXT LINE          " 
	    "MCHR CARD IGNORED:   CANNOT USE ZERO.                       ";
    static integer lv[54] = { 2,2,2,2,1,2,2,2,2,2,2,1,2,1,2,2,1,1,2,2,2,2,2,2,
	    0,0,0,1,1,1,2,1,2,0,2,0,3,0,0,0,0,0,2,3,3,3,-1,3,0,3,2,2,2,0 };

    /* Format strings */
    static char fmt_320[] = "(7x,72a1,19(/12x,\002X\002,66a1))";
    static char fmt_340[] = "(\002 ******(\002,i3,\002) ***\002,a60,\002****"
	    "**\002,20x,\002**********\002)";
    static char fmt_330[] = "(1x,i4,2x,80a1)";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__, j;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int page_(integer *);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    extern /* Subroutine */ int quit_(integer *);
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___146 = { 0, 0, 0, fmt_320, 0 };
    static cilist io___148 = { 0, 0, 0, fmt_340, 0 };
    static cilist io___149 = { 0, 0, 0, fmt_330, 0 };



/*     THIS ROUTINE WRITES THE GENERAL DIAGNOSTICS FOR TIDY. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*     ***                                                            *** */
/*      1 THE ABOVE STATEMENT IS ILLEGAL AND HAS BEEN DELETED. */
/*      2 THE ABOVE STATEMENT HAS A MISSING RIGHT PARENTHESIS. */
/*      3 THE ABOVE STATEMENT HAS AN EXCESS RIGHT PARENTHESIS. */
/*      4 THE ABOVE STATEMENT INCORRECTLY TERMINATES A DO LOOP. */
/*      5 THE ABOVE STATEMENT CANNOT BE REACHED BY THE PROGRAM. */
/*      6 STATEMENT NUMBER TABLE FULL.  RENUMBER PASS DELETED. */
/*      7 REFERENCE NUMBER TABLE FULL.  RENUMBER PASS DELETED. */
/*      8 THE ABOVE STATEMENT IS OBSOLETE AND IS DELETED. */
/*      9 ABOVE STATEMENT HAS AN ILLEGAL FIRST SPECIAL CHARACTER. */
/*     10 ILLEGAL DATA, FUNCTION, OR SUBROUTINE STATEMENT. */
/*     11 THE ABOVE COMMON OR DATA STATEMENT IS MISSING A (/). */
/*     12 THE ABOVE CONTINUE STATEMENT IS REDUNDANT AND IS DELETED. */
/*     13 THE ABOVE DIMENSION STATEMENT IS NOT COMPLETE. */
/*     14 W A R N I N G .  STATEMENT SHOULD BE FIRST IN ROUTINE. */
/*     15 THE ABOVE DO STATEMENT HAS AN INVALID TERMINAL STATEMENT. */
/*     16 W A R N I N G .  UNSATISFIED DO LOOPS. */
/*     17 UNNUMBERED OR INVALID FORMAT STATEMENT DELETED. */
/*     18 WARNING.  ABOVE STATEMENT IS POOR PROGRAMMING PRACTICE. */
/*     19 ABOVE GO TO STATEMENT IS ILLEGAL. */
/*     20 ILLEGAL ARITHMETIC IF STATEMENT.   IF (ARITH) 1,2,3 */
/*     21 ABOVE NAMELIST STATEMENT MISSING (/). */
/*     22 ILLEGAL READ, WRITE , OR PUNCH STATEMENT. */
/*     23 ILLEGAL READ (12) LIST, OR WRITE (12) LIST, STATEMENT. */
/*     24 DO LOOP TABLE FULL.  RENUMBER PASS DELETED. */
/*     25 W A R N I N G .   COMMA FOLLOWING X INSERTED IN ABOVE FORMAT. */
/*     26 TIDY CANNOT PROCESS THIS CLASS OF PROGRAM.  (COPY EXECUTED.) */
/*     27 WARNING.  ABOVE DO-LOOP TERMINUS PREVIOUSLY REFERENCED. */
/*     28 WARNING.  TIDY MAY HAVE CHANGED CARD 2 OF THIS ROUTINE */
/*     29 W A R N I N G .   END CARD INSERTED. */
/*     30 THE ABOVE STATEMENT IS TRANSMITTED WITHOUT PROCESSING */
/*     31 ILLEGAL CLOSE, INQUIRE, OR OPEN STATEMENT */
/*     32 W A R N I N G .   UNBALANCED ELSE/ELSEIF/ENDIF STATEENT */
/*     33 W A R N I N G .   UNSATISFIED IF BLOCKS. */
/*     34 W A R N I N G .   ABOVE STATEMENT NOT ANSI FORTRAN 77 */
/*     35 TOO MANY REFERENCES IN ABOVE. RENUMBER PASS DELETED. */
/*     36 W A R N I N G .   NON-ANSI (L OR R) HOLLERITH SPEC. */
/*     37 ABOVE STATEMENT HAS MORE THAN 19 CONTINUATION LINES. */
/*     38 CCHR CARD IGNORED:   CANNOT USE ZERO. */
/*     39 >>> HOLLERITH CONSTANT CONVERTED <<< */
/*     40 W A R N I N G.   *PRECISION ON NUMERIC/LOGICAL VARS NOT ANSI */
/*     41 W A R N I N G.    VARIABLE NAME LONGER THAN 6 CHARACTERS */
/*     42 W A R N I N G.    INITIALIZED TYPE DECLARATIONS NOT ANSI */
/*     43 MORE <END DO> THAN <DO> STATEMENTS */
/*     44 FATAL ERROR - DO LIST UNDERFLOW */
/*     45 FATAL ERROR */
/*     46 FATAL PROBLEM IN DO-LOOP RENUMBERING - SUBROUTINE EDIT */
/*     47 ABNORMAL TERMINATION */
/*     48 CONTRL INTERNAL ERROR */
/*     49 *FMTB CONFLICTS WITH REGULAR STATEMENTS - IGNORED. */
/*     50 TOO MANY CONTINUATION CARDS - RECOMPILE */
/*     51 SOMETHING IN COLS 73-80 */
/*     52 BLANKS REMOVED FROM STRING INCLUDING 73-80 */
/*     53 REFERENCE TO MISSING STATEMENT NUMBER */
/*     54 MCHR CARD IGNORED:   CANNOT USE ZERO. */

/*  FORTRAN LOGICAL UNITS */
/*     LV=0 - TIDY USER WARNING - CAUSES NORMAL TERMINATION */
/*        1 - MINOR FORTRAN ERROR - STOP 1 */
/*        2 - MAJOR FORTRAN ERROR - STOP 2 */
/*        3 - IMMEDIATELY FATAL   - STOP 3 */

/*       -1 - TERMINATE WITH PREVIOUS HIGHEST ERROR LEVEL */


    j = *n;
    if (j <= 0 || j > 54) {
	j = 1;
    }
    ++misc_1.nmsg;
    if (misc_1.lerr < lv[j - 1]) {
	misc_1.lerr = lv[j - 1];
    }
    if (misc_1.mlist == -1) {
	page_(&c__1);
    } else {
	i__1 = (misc_1.jmax - 7) / 66 + 4;
	page_(&i__1);
	io___146.ciunit = lunits_1.outfil;
	s_wsfe(&io___146);
	i__1 = misc_1.jmax;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    do_fio(&c__1, miscal_1.jint + (i__ - 1 << 1), (ftnlen)2);
	}
	e_wsfe();
    }
    io___148.ciunit = lunits_1.outfil;
    s_wsfe(&io___148);
    do_fio(&c__1, (char *)&misc_1.nmsg, (ftnlen)sizeof(integer));
    do_fio(&c__1, ermsg + (j - 1) * 60, (ftnlen)60);
    e_wsfe();

    if (misc_1.mlist != -1) {
	io___149.ciunit = lunits_1.outfil;
	s_wsfe(&io___149);
	do_fio(&c__1, (char *)&misc_1.nrec, (ftnlen)sizeof(integer));
	do_fio(&c__80, miscal_1.kbuff, (ftnlen)2);
	e_wsfe();
    }

/*      IF (LERR.GE.3) STOP 3 */
    if (misc_1.lerr >= 3) {
	quit_(&c__3);
    }
    if (lv[j - 1] < 0) {
/*           IF (LERR.EQ.2) STOP 2 */
/*           IF (LERR.EQ.1) STOP 1 */
	if (misc_1.lerr == 2) {
	    quit_(&c__2);
	}
	if (misc_1.lerr == 1) {
	    quit_(&c__1);
	}
    }
    return 0;


/* 330  FORMAT (1X,I4,2X,80A1,/' ') */
} /* diagno_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int dlist_(integer *merr)
{
    /* Initialized data */

    static integer jtypp = 0;

    /* Format strings */
    static char fmt_100[] = "(\002 DLIST - NDEF = \002,i4,\002 LDEF()= \002,"
	    "i4,\002 LOCDEF()=\002,i4,\002 NNMKLS()= \002,i4)";
    static char fmt_110[] = "(\002 ****  (\002,i3,\002) *** DO LOOP LEVEL"
	    "\002,i2,\002 TERMINATES WHILE\rLEVEL\002,i2,\002 IS IN EFFECT.  "
	    "   ***\002)";
    static char fmt_120[] = "(\002 ****  (\002,i3,\002) *** STATEMENT NUMBE"
	    "R\002,i6,\002 DUPLICATES THE NUMBER AT\002,i4,\002.\002,8x,\002*"
	    "**\002)";

    /* System generated locals */
    integer i__1, i__2;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__, j;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int page_(integer *);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int diagno_(integer *);
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___161 = { 0, 0, 0, fmt_100, 0 };
    static cilist io___162 = { 0, 0, 0, fmt_110, 0 };
    static cilist io___164 = { 0, 0, 0, fmt_120, 0 };



/*     THIS SUBROUTINE UPDATES THE DEFINED STATEMENT NUMBER LIST, LDEF, */
/*     BY ADDING THE STATEMENT NUMBER IN L15, IF IT IS UNIQUE. */
/*              RETURNS MERR = 0 IF LABEL IS OK. */
/*                             1 IF LABEL TERMINATED A DO-LOOP (OK) */
/*                            -1 IF ERROR */
/*                       POSSIBLE ERRORS-- */
/*                            ILLEGAL DO-LOOP NEST */
/*                            DUPLICATE STATEMENT NUMBER */
/*                            STATEMENT NUMBER TABLE FULL */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */
    *merr = 0;
    if (*klass < 4) {
	jtypp = *jtype;
	return 0;
    }

/*     CHECK FOR FORMAT STATEMENT, WHICH IS LABELED BUT CAN'T HAVE */
/*      FALL-THRU */
    if (*klass == 5) {
/*          PROCESS FORMAT STATEMENT */
/*           SCAN FOR DUPLICATE STATEMENT NUMBER */
	if (misc_1.ndef > 0) {
	    i__1 = misc_1.ndef;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		if ((i__2 = _BLNK__1.ldef[i__ - 1], abs(i__2)) == *l15) {
		    goto L60;
		}
/* L10: */
	    }
	}

/*          PUT L15 INTO LDEF LIST AFTER LAST NON-NEGATIVE ENTRY */
	if (misc_1.ndef >= 1500) {
	    goto L70;
	}
	i__ = misc_1.ndef;
	++misc_1.ndef;
L20:
	if (i__ == 0 || _BLNK__1.ldef[i__ - 1] >= 0) {
	    _BLNK__1.ldef[i__] = *l15;
	    _BLNK__1.locdef[i__] = misc_1.nrec;
	    _BLNK__1.nnmkls[i__] = 5;
	    goto L90;
	}
	_BLNK__1.ldef[i__] = _BLNK__1.ldef[i__ - 1];
	_BLNK__1.locdef[i__] = _BLNK__1.locdef[i__ - 1];
	_BLNK__1.nnmkls[i__] = _BLNK__1.nnmkls[i__ - 1];
	--i__;
	goto L20;
    }

/*     EXECUTABLE STATEMENT (OR END) */
    if (*l15 == 0) {
/*          UNLABELLED. IS THERE A FALL-THRU... */
	if (misc_1.l25 == 0) {

/*               UNLABELLED STATEMENT. ERROR IF IT FOLLOWS TRANSFER */
/*                (EXCEPT COMPUTED GO TO) */
	    if (misc_1.ntran != 0 && jtypp != 23) {
		diagno_(&c__5);
	    }
	} else {
/*               THERE IS A FALL-THRU LABEL. USE IT. */
	    *l15 = misc_1.l25;
	    misc_1.l25 = 0;
	    _BLNK__1.ldef[misc_1.ndef - 1] = (i__1 = _BLNK__1.ldef[
		    misc_1.ndef - 1], abs(i__1));
	}
	goto L90;
    }
/*               LABELLED. SCRATCH FALL-THRU LABEL */
    misc_1.l25 = 0;

/*     SCAN FOR DUPLICATE STATEMENT NUMBERS. */

    if (misc_1.ndef > 0) {
	i__1 = misc_1.ndef;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if ((i__2 = _BLNK__1.ldef[i__ - 1], abs(i__2)) == *l15) {
		goto L60;
	    }
/* L30: */
	}
    }

    if (misc_1.ndef >= 1500) {
	goto L70;
    }
    ++misc_1.ndef;
    _BLNK__1.ldef[misc_1.ndef - 1] = *l15;
    _BLNK__1.locdef[misc_1.ndef - 1] = misc_1.nrec;
    _BLNK__1.nnmkls[misc_1.ndef - 1] = *klass;
    if (misc_1.mdeb > 0) {
	io___161.ciunit = lunits_1.outfil;
	s_wsfe(&io___161);
	do_fio(&c__1, (char *)&misc_1.ndef, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&_BLNK__1.ldef[misc_1.ndef - 1], (ftnlen)sizeof(
		integer));
	do_fio(&c__1, (char *)&_BLNK__1.locdef[misc_1.ndef - 1], (ftnlen)
		sizeof(integer));
	do_fio(&c__1, (char *)&_BLNK__1.nnmkls[misc_1.ndef - 1], (ftnlen)
		sizeof(integer));
	e_wsfe();
    }

/*     SCAN FOR POSSIBLE DO-LOOP TERMINATIONS. */

    if (misc_1.ndos > 0) {
	i__1 = misc_1.ndos;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (misc_1.ldos[i__ - 1] == *l15) {
/*                                 ITS IN THE LIST */
		*merr = 1;
		if (i__ != misc_1.ndos) {
/*                                 ILLEGAL DO-LOOP NEST */
		    ++misc_1.nmsg;
		    page_(&c__1);
		    io___162.ciunit = lunits_1.outfil;
		    s_wsfe(&io___162);
		    do_fio(&c__1, (char *)&misc_1.nmsg, (ftnlen)sizeof(
			    integer));
		    do_fio(&c__1, (char *)&i__, (ftnlen)sizeof(integer));
		    do_fio(&c__1, (char *)&misc_1.ndos, (ftnlen)sizeof(
			    integer));
		    e_wsfe();

/*          COMPRESS DO-LOOP TERMINAL LIST AFTER DELETIONS. */

		    --misc_1.ndos;
		    i__2 = misc_1.ndos;
		    for (j = i__; j <= i__2; ++j) {
			misc_1.ldos[j - 1] = misc_1.ldos[j];
/* L40: */
		    }
		    goto L80;
		}
/*                                 LAST ONE IN LIST. REMOVE IT */
		--misc_1.ndos;
		if (misc_1.mildo != 0) {
		    diagno_(&c__4);
		}
		goto L90;
	    }
/* L50: */
	}
    }
    goto L90;

/*     ERROR DIAGNOSTICS. */

/*                            DUPLICATE STATEMENT NUMBER */
L60:
    ++misc_1.nmsg;
    page_(&c__1);
    io___164.ciunit = lunits_1.outfil;
    s_wsfe(&io___164);
    do_fio(&c__1, (char *)&misc_1.nmsg, (ftnlen)sizeof(integer));
    do_fio(&c__1, (char *)&(*l15), (ftnlen)sizeof(integer));
    do_fio(&c__1, (char *)&_BLNK__1.locdef[i__ - 1], (ftnlen)sizeof(integer));
    e_wsfe();
    goto L80;
/*                            NUMBER TABLE FULL */
L70:
    diagno_(&c__6);
    misc_1.ndef = -1;
    misc_1.mp2 = 0;
/*                            ERROR EXIT */
L80:
    misc_1.mpun = 0;
    *merr = -1;
/*                            EXIT */
L90:
    misc_1.mildo = 0;
    ++misc_1.nxeq;
    jtypp = *jtype;
    return 0;



} /* dlist_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int edit_(void)
{
    /* Format strings */
    static char fmt_130[] = "(\002 FOLLOWING *DEBUG OUTPUT FROM SUBR EDIT"
	    "\002/\002 NDEF = \002,i7,\002\r NREF = \002,i7)";
    static char fmt_170[] = "(\002 \002,12x,\002*** THE FOLLOWING STATEMENTS"
	    " ARE IN ENDLESS CHAINS OF GOTO'S.\002)";
    static char fmt_160[] = "(13x,\002*** PSEUDO-STATEMENT NUMBERS HAVE BEEN"
	    " ASSIGNED.\002/\002 \002)";
    static char fmt_140[] = "(7x,\002(\002,i3,\002) *** STATEMENT NUMBER\002"
	    ",i7,\002 IS ASSIGNED NUMBER\002,i7,\002.\002,13x,\002***\002)";
    static char fmt_150[] = "(\002 \002,12x,\002*** THE FOLLOWING REFERENCED"
	    " STATEMENTS ARE NOT DEFINED\002)";

    /* System generated locals */
    integer i__1, i__2, i__3;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__, j, i1, ic;
#define l15 ((integer *)&misc_1 + 23)
    static integer it;
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int page_(integer *);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static integer nnum, nnfm;
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    static integer kfmts;
    extern /* Subroutine */ int rlist_(void), diagno_(integer *);
    static integer mfmbas;
    extern /* Subroutine */ int edtdmp_(char *, ftnlen);
    static integer maxfmt;
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___174 = { 0, 0, 0, fmt_130, 0 };
    static cilist io___185 = { 0, 0, 0, fmt_170, 0 };
    static cilist io___186 = { 0, 0, 0, fmt_160, 0 };
    static cilist io___187 = { 0, 0, 0, fmt_140, 0 };
    static cilist io___188 = { 0, 0, 0, fmt_150, 0 };
    static cilist io___189 = { 0, 0, 0, fmt_160, 0 };
    static cilist io___190 = { 0, 0, 0, fmt_140, 0 };



/*     THIS SUBROUTINE EDITS THE DEFINED AND THE REFERENCED STATEMENT */
/*     NUMBER LIST. */

/*     ON ENTRY, LDEF(I) CONTAINS THE STATEMENT LABELS, IN THE */
/*     ORDER IN WHICH THEY WERE USED.  THE LABELS OF CONTINUE */
/*     STATEMENTS WHICH WERE NOT PASSED ON ARE NEGATIVE. */
/*     LOCDEF(I) CONTAINS THE CARD NUMBER (NREC) OF THE LINE */
/*     IDENTIFIED BY THAT LABEL.  EXCEPTION FOR DOUBLE BRANCHES-- */
/*     IF LDEF(I)=0, THEN THE STATEMENT WITH THE LABEL LDEF(I-1) */
/*     WAS A GOTO.  THE TARGET LABEL IS IN LOCDEF(I). */

/*     (1)     DEFINED STATEMENTS THAT ARE NOT REFERENCED ARE DELETED. */
/*     (2)     THE NEW STATEMENT NUMBERS ARE GENERATED */
/*     (3)     A STATEMENT NUMBER WHICH IS NEGATIVE IN THE LDEF */
/*             LIST IS ASSIGNED A NEW STATEMENT NUMBER THE SAME */
/*             AS THE NEXT POSITIVE LABEL IN THE LDEF LIST */
/*     (4)     A LABEL FOLLOWED BY A ZERO IN THE LDEF LIST IS */
/*             ASSIGNED A NEW STATEMENT NUMBER THE SAME AS THE */
/*             STATEMENT NUMBER ASSIGNED TO THE LABEL GIVEN IN */
/*             THE LOCREF ARRAY.  (FOR DOUBLE BRANCHES) */
/*     (5)     PSEUDO-STATEMENT NUMBERS OUTSIDE THE RANGE OF RENUMBERED */
/*             DEFINED STATEMENT NUMBERS ARE GENERATED FOR EACH */
/*             REFERENCED STATEMENT WHICH IS NOT DEFINED. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */
    if (misc_1.nref <= 0) {
	misc_1.ndef = 0;
    }
    if (misc_1.ndef <= 0) {
	return 0;
    }

    if (misc_1.mdeb != 0) {
	io___174.ciunit = lunits_1.outfil;
	s_wsfe(&io___174);
	do_fio(&c__1, (char *)&misc_1.ndef, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&misc_1.nref, (ftnlen)sizeof(integer));
	e_wsfe();
	edtdmp_("Start EDIT", (ftnlen)10);
    }

/*     SET UP NEWNUM SO THAT IF LDEF(I) NEEDS A NEW NUMBER, */
/*     NEWNUM(I)=0. IF LDEF(I) WILL REFERENCE LDEF(J), THEN */
/*     NEWNUM(I)=-LDEF(J).  REMOVE ENTRIES WITH LDEF(I)=0 */

    it = 0;
    kfmts = 0;
    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (_BLNK__1.nnmkls[i__ - 1] == 5) {
	    ++kfmts;
	}
	if (_BLNK__1.ldef[i__ - 1] > 0) {
/*                            POSITIVE IS NORMAL */
	    ++it;
	    _BLNK__1.newnum[it - 1] = 0;
	    _BLNK__1.ldef[it - 1] = _BLNK__1.ldef[i__ - 1];
	} else if (_BLNK__1.ldef[i__ - 1] == 0) {
/*                            ZERO MEANS LAST WAS A BRANCH */
	    _BLNK__1.newnum[it - 1] = -_BLNK__1.locdef[i__ - 1];
	    goto L20;
	} else {
/*                            NEGATIVE MEANS CONTINUE. LOOK AHEAD */
	    j = i__;
L10:
	    ++j;
	    if (_BLNK__1.ldef[j - 1] < 0 || _BLNK__1.locdef[j - 1] < 0) {
		goto L10;
	    }
/*                            CHECK FOR A FORMAT STATEMENT */
	    ++it;
	    _BLNK__1.newnum[it - 1] = -_BLNK__1.ldef[j - 1];
	    if (_BLNK__1.ldef[j - 1] == 0) {
		_BLNK__1.newnum[it - 1] = -(i__2 = _BLNK__1.ldef[j - 2], abs(
			i__2));
	    }
	    _BLNK__1.ldef[it - 1] = (i__2 = _BLNK__1.ldef[i__ - 1], abs(i__2))
		    ;
	}
	_BLNK__1.locdef[it - 1] = (i__2 = _BLNK__1.locdef[i__ - 1], abs(i__2))
		;
L20:
	;
    }
    misc_1.ndef = it;

    if (misc_1.mdeb != 0) {
	edtdmp_("Nonzero NEWNUM = refs to be changed", (ftnlen)35);
    }

/*     LDEF NOW CONTAINS DEFINED STATEMENT NUMBERS. LOCDEF(I) */
/*     HAS LINE NUMBER OF LDEF(I).  NEWNUM(I) HAS ZERO IF LDEF(I) */
/*     WILL NEED A NEW NUMBER, AND -NNN IF REFERENCES TO LDEF(I) */
/*     SHOULD BE CHANGED TO REFERENCES TO NNN. */

/*     FOR EACH LREF, SCAN LDEF FOR CHAINS.  BE SURE */
/*     TARGETS OF GOTOS ARE REFERENCED ALSO. */

    it = misc_1.nref;
    i__1 = it;
    for (i__ = 1; i__ <= i__1; ++i__) {
	i1 = _BLNK__1.lref[i__ - 1];
/*                      GET REFERENCE IN LDEF */
	i__2 = misc_1.ndef;
	for (j = 1; j <= i__2; ++j) {
	    if (i1 == _BLNK__1.ldef[j - 1]) {
/*                         NEXT LINK IN CHAIN */
		i1 = (i__3 = _BLNK__1.newnum[j - 1], abs(i__3));
		if (i1 == 0) {
		    goto L40;
		}
		misc_1.l772 = (doublereal) i1;
/*                      ADD TARGET TO REF LIST */
		rlist_();
		goto L40;
	    }
/* L30: */
	}
/*                               NOT DEFINED */
L40:
	;
    }

    if (misc_1.mdeb != 0) {
	edtdmp_("Chains identified - ready to renumber", (ftnlen)37);
    }

/*     SCAN DEFINED LIST FOR REFERENCES.  DELETE NON-REFERENCED */
/*     DEFINED STATEMENT NUMBERS. */

/*     FIRST CHECK IF FMTBASE IS LEGAL, IF NOT, IGNORE WITH DIAGNOSTIC. */
/*       KFMTS COUNTED THE FORMATS, SO CHECK IF HIGHEST NON-FORMAT */
/*       STATEMENT NUMBER TO BE GENERATED WOULD OVERLAP, OR VICE-VERSA */
/*       IF FORMATS TO BE NUMBERED BELOW EXECUTABLES (RARE BUT POSSIBLE). */

    if (misc_1.mfmtb == misc_1.kb15) {
	mfmbas = 0;
    } else if (misc_1.mfmtb > misc_1.kb15) {
	maxfmt = misc_1.kb15 + (misc_1.ndef - kfmts) * misc_1.kd15;
	if (misc_1.mfmtb <= maxfmt) {
	    mfmbas = 0;
	    diagno_(&c__49);
	} else {
	    mfmbas = misc_1.mfmtb;
	}
    } else {
	maxfmt = misc_1.mfmtb + kfmts * misc_1.kd15;
	if (maxfmt > misc_1.kb15) {
	    mfmbas = 0;
	    diagno_(&c__49);
	} else {
	    mfmbas = misc_1.mfmtb;
	}
    }

    it = 0;
    nnum = 0;
    nnfm = 0;
    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	i__2 = misc_1.nref;
	for (j = 1; j <= i__2; ++j) {
	    if (_BLNK__1.ldef[i__ - 1] == _BLNK__1.lref[j - 1]) {
		if (_BLNK__1.newnum[i__ - 1] == 0) {
/*                          MAKE NEW NUMBER */
		    if (_BLNK__1.nnmkls[i__ - 1] == 5 && mfmbas > 0) {
			++nnfm;
			_BLNK__1.newnum[i__ - 1] = misc_1.kd15 * nnfm + 
				mfmbas;
		    } else {
			++nnum;
			_BLNK__1.newnum[i__ - 1] = misc_1.kd15 * nnum + 
				misc_1.kb15;
		    }
		}
		++it;
		_BLNK__1.ldef[it - 1] = _BLNK__1.ldef[i__ - 1];
		_BLNK__1.newnum[it - 1] = _BLNK__1.newnum[i__ - 1];
		_BLNK__1.locdef[it - 1] = _BLNK__1.locdef[i__ - 1];
		_BLNK__1.nnmkls[it - 1] = _BLNK__1.nnmkls[i__ - 1];
		goto L60;
	    }
/* L50: */
	}
/*                            NOT REFERENCED */
L60:
	;
    }
    misc_1.ndef = it;

    if (misc_1.mdeb != 0) {
	edtdmp_("New statement numbers:", (ftnlen)22);
    }

/*     SCAN LDEF FOR INDIRECT REFERENCES AND REPLACE THEM */

    it = 0;
    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	for (ic = 1; ic <= 10; ++ic) {
	    if (_BLNK__1.newnum[i__ - 1] > 0) {
		goto L100;
	    }
	    i1 = (i__2 = _BLNK__1.newnum[i__ - 1], abs(i__2));
	    i__2 = misc_1.ndef;
	    for (j = 1; j <= i__2; ++j) {
		if (_BLNK__1.ldef[j - 1] == i1) {
		    _BLNK__1.newnum[i__ - 1] = _BLNK__1.newnum[j - 1];
		    goto L80;
		}
/* L70: */
	    }
	    diagno_(&c__46);
L80:
	    ;
	}
/*                            LOOP OF GOTO-S. BREAK IT */
	if (it != 0) {
	    goto L90;
	}
	it = 1;
	page_(&c_n20);
	page_(&c__1);
	io___185.ciunit = lunits_1.outfil;
	s_wsfe(&io___185);
	e_wsfe();
	io___186.ciunit = lunits_1.outfil;
	s_wsfe(&io___186);
	e_wsfe();
L90:
	++nnum;
	_BLNK__1.newnum[i__ - 1] = misc_1.kd15 * nnum + misc_1.kb15;
	++misc_1.nmsg;
	page_(&c__1);
	io___187.ciunit = lunits_1.outfil;
	s_wsfe(&io___187);
	do_fio(&c__1, (char *)&misc_1.nmsg, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&i1, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&_BLNK__1.newnum[i__ - 1], (ftnlen)sizeof(
		integer));
	e_wsfe();
L100:
	;
    }

/*     SCAN REFERENCED STATEMENT LIST FOR MISSING DEFINITIONS. */

    it = 0;
    i__1 = misc_1.nref;
    for (i__ = 1; i__ <= i__1; ++i__) {
	i__2 = misc_1.ndef;
	for (j = 1; j <= i__2; ++j) {
	    if (_BLNK__1.lref[i__ - 1] == _BLNK__1.ldef[j - 1]) {
		goto L120;
	    }
/* L110: */
	}

/*     ADD PSEUDO-STATEMENT NUMBER. */

	misc_1.lerr = 2;
	if (it <= 0) {
	    it = 1;
	    page_(&c_n20);
	    page_(&c__4);
	    io___188.ciunit = lunits_1.outfil;
	    s_wsfe(&io___188);
	    e_wsfe();
	    io___189.ciunit = lunits_1.outfil;
	    s_wsfe(&io___189);
	    e_wsfe();
	}
	++misc_1.ndef;
	if (misc_1.ndef > 1500) {
	    diagno_(&c__6);
	    misc_1.ndef = -1;
	    misc_1.mp2 = 0;
	    return 0;
	}
	_BLNK__1.ldef[misc_1.ndef - 1] = _BLNK__1.lref[i__ - 1];
	_BLNK__1.locdef[misc_1.ndef - 1] = 0;
	_BLNK__1.newnum[misc_1.ndef - 1] = misc_1.ndef * misc_1.kd15 + 
		misc_1.kb15;
	++misc_1.nmsg;
	page_(&c__1);
	io___190.ciunit = lunits_1.outfil;
	s_wsfe(&io___190);
	do_fio(&c__1, (char *)&misc_1.nmsg, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&_BLNK__1.lref[i__ - 1], (ftnlen)sizeof(integer)
		);
	do_fio(&c__1, (char *)&_BLNK__1.newnum[misc_1.ndef - 1], (ftnlen)
		sizeof(integer));
	e_wsfe();
L120:
	;
    }
    return 0;



} /* edit_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int edtdmp_(char *msg, ftnlen msg_len)
{
    /* Format strings */
    static char fmt_10[] = "(\002 \002,a)";
    static char fmt_20[] = "(\002 LDEF  \002,9i7)";
    static char fmt_30[] = "(\002 NEWNUM\002,9i7)";
    static char fmt_40[] = "(\002 LOCDEF\002,9i7)";
    static char fmt_50[] = "(\002 LREF  \002,9i7)";
    static char fmt_60[] = "(\002 KLASS \002,9i7)";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___200 = { 0, 0, 0, fmt_10, 0 };
    static cilist io___201 = { 0, 0, 0, fmt_20, 0 };
    static cilist io___203 = { 0, 0, 0, fmt_30, 0 };
    static cilist io___204 = { 0, 0, 0, fmt_40, 0 };
    static cilist io___205 = { 0, 0, 0, fmt_50, 0 };
    static cilist io___206 = { 0, 0, 0, fmt_60, 0 };



/*     DUMP TABLES FOR DEBUG OF SUBROUTINE EDIT. */
/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*  FORTRAN LOGICAL UNITS */
    io___200.ciunit = lunits_1.outfil;
    s_wsfe(&io___200);
    do_fio(&c__1, msg, msg_len);
    e_wsfe();
    io___201.ciunit = lunits_1.outfil;
    s_wsfe(&io___201);
    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	do_fio(&c__1, (char *)&_BLNK__1.ldef[i__ - 1], (ftnlen)sizeof(integer)
		);
    }
    e_wsfe();
    io___203.ciunit = lunits_1.outfil;
    s_wsfe(&io___203);
    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	do_fio(&c__1, (char *)&_BLNK__1.newnum[i__ - 1], (ftnlen)sizeof(
		integer));
    }
    e_wsfe();
    io___204.ciunit = lunits_1.outfil;
    s_wsfe(&io___204);
    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	do_fio(&c__1, (char *)&_BLNK__1.locdef[i__ - 1], (ftnlen)sizeof(
		integer));
    }
    e_wsfe();
    io___205.ciunit = lunits_1.outfil;
    s_wsfe(&io___205);
    i__1 = misc_1.nref;
    for (i__ = 1; i__ <= i__1; ++i__) {
	do_fio(&c__1, (char *)&_BLNK__1.lref[i__ - 1], (ftnlen)sizeof(integer)
		);
    }
    e_wsfe();
    io___206.ciunit = lunits_1.outfil;
    s_wsfe(&io___206);
    i__1 = misc_1.nref;
    for (i__ = 1; i__ <= i__1; ++i__) {
	do_fio(&c__1, (char *)&_BLNK__1.nnmkls[i__ - 1], (ftnlen)sizeof(
		integer));
    }
    e_wsfe();
    return 0;


} /* edtdmp_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int header_(void)
{
    /* System generated locals */
    integer i__1;
    char ch__1[2];

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__, j, k, ib;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Character */ VOID kupper_(char *, ftnlen, char *, ftnlen);


/*                  THIS ROUTINE CENTERS JOB HEADINGS */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    if (misc_1.ipass == 1) {
	for (i__ = 1; i__ <= 72; ++i__) {
	    s_copy(miscal_1.job + (i__ - 1 << 1), miscal_1.jint + (i__ - 1 << 
		    1), (ftnlen)2, (ftnlen)2);
/* L10: */
	}
    } else {

	for (i__ = 1; i__ <= 80; ++i__) {
	    s_copy(miscal_1.job + (i__ - 1 << 1), miscal_1.iout + (i__ - 1 << 
		    1), (ftnlen)2, (ftnlen)2);
/* L20: */
	}

	if (misc_1.mser < 0) {

/*     SET UP COLUMNS 73-75 BASED ON *LABE OPTION */
	    if (misc_1.mlbl == 0) {
/*     USE *ROUT VALUE */
		i__ = (misc_1.nrout - 1) / 26;
		j = misc_1.nrout - i__ * 26;
		if (i__ == 0) {
		    s_copy(miscal_1.kol73 + 4, alpha_1.kbl, (ftnlen)2, (
			    ftnlen)2);
		    s_copy(miscal_1.kol73 + 2, alpha_1.kabc + (j - 1 << 1), (
			    ftnlen)2, (ftnlen)2);
		} else {
		    s_copy(miscal_1.kol73 + 2, alpha_1.kabc + (i__ - 1 << 1), 
			    (ftnlen)2, (ftnlen)2);
		    s_copy(miscal_1.kol73 + 4, alpha_1.kabc + (j - 1 << 1), (
			    ftnlen)2, (ftnlen)2);
		}

		s_copy(miscal_1.kol73, alpha_1.kbl, (ftnlen)2, (ftnlen)2);
	    } else {

/*     COPY PROGRAM/SUBROUTINE/FUNCTION CARD SERIAL INFORMATION */
		for (i__ = 1; i__ <= 3; ++i__) {
		    kupper_(ch__1, (ftnlen)2, miscal_1.serial + (i__ - 1 << 1)
			    , (ftnlen)2);
		    s_copy(miscal_1.kol73 + (i__ - 1 << 1), ch__1, (ftnlen)2, 
			    (ftnlen)2);
/* L30: */
		}
	    }
	}
    }

    for (i__ = 73; i__ <= 80; ++i__) {
	s_copy(miscal_1.job + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (ftnlen)
		2);
/* L40: */
    }

/*          COMPRESS STATEMENT BY ELIMINATING MULTIPLE BLANKS */

    j = 1;
    k = 0;
    for (i__ = 1; i__ <= 80; ++i__) {
	if (s_cmp(miscal_1.job + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2) == 0) {
	    if (k == 1) {
		goto L50;
	    }
	    k = 1;
	} else {
	    k = 0;
	}
	s_copy(miscal_1.job + (j - 1 << 1), miscal_1.job + (i__ - 1 << 1), (
		ftnlen)2, (ftnlen)2);
	++j;
L50:
	;
    }
    for (i__ = j; i__ <= 80; ++i__) {
	s_copy(miscal_1.job + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (ftnlen)
		2);
/* L60: */
    }

/*                           CENTER HEADING */

    ib = (80 - j) / 2;
L70:
    i__ = j + ib;
    s_copy(miscal_1.job + (i__ - 1 << 1), miscal_1.job + (j - 1 << 1), (
	    ftnlen)2, (ftnlen)2);
    --j;
    if (j > 0) {
	goto L70;
    }

/*                   ELIMINATE REMAINING NON-BLANKS */

    ib = i__ - 1;
    i__1 = ib;
    for (i__ = 1; i__ <= i__1; ++i__) {
	s_copy(miscal_1.job + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (ftnlen)
		2);
/* L80: */
    }
    return 0;
} /* header_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int holscn_(integer *ltype, integer *lsscn, integer *lnstr)
{
    /* Format strings */
    static char fmt_320[] = "(\002 HOLSCN: IFIR = \002,i2,\002 AT COL \002,i"
	    "4)";

    /* System generated locals */
    integer i__1, i__2;
    char ch__1[2];

    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__, j, n;
#define l15 ((integer *)&misc_1 + 23)
    static integer jj, ip;
    static char it[2];
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static integer ktmp;
    static logical isdel;
    static integer igoof;
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    static logical lhtrn, strp73;
    static integer lntmp;
    extern /* Subroutine */ int rstat_(void), diagno_(integer *);
    static char kparam[2];
    extern /* Character */ VOID kctran_(char *, ftnlen, char *, ftnlen);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Character */ VOID kupper_(char *, ftnlen, char *, ftnlen);
    extern /* Subroutine */ int movstr_(integer *);

    /* Fortran I/O blocks */
    static cilist io___237 = { 0, 0, 0, fmt_320, 0 };
    static cilist io___243 = { 0, 0, 0, fmt_320, 0 };


/*     THIS SUBROUTINE SCANS ALL FORTRAN CARDS FOR FIELDS OF HOLLERITH- */
/*     TYPE CONSTANTS.  IN THESE FIELDS, */
/*     CHARACTERS ARE REPLACED WITH EQUIVALENT CHARACTERS WHICH WILL NOT */
/*     BE TREATED BY ANALYSIS ROUTINES. */
/*     THE SEARCH IS MADE BY CHECKING FOR PATTERNS -SNNNL-, WHERE S IS A */
/*     SPECIAL CHARACTER, NNN IS A DECIMAL NUMBER, AND L IS THE LETTER H, */
/*     L, OR R.  IN ADDITION, FOR FORMAT STATEMENTS ONLY, IT ACCEPTS THE */
/*     PATTERN SNNNXNNNL, THE RESULT OF A MISSING -,- AFTER X. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */

    strp73 = TRUE_;
    misc_1.jcol = 6;
    *lnstr = 0;
    lntmp = 0;
    misc_1.nlhtrn = 0;
/*     IF FORMAT STATEMENT, SKIP FIRST 7 NON-BLANK CHARACTERS */
    if (*ltype == 26) {
	for (n = 1; n <= 7; ++n) {
L10:
	    ++misc_1.jcol;
	    if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kbl, (
		    ftnlen)2, (ftnlen)2) == 0) {
		goto L10;
	    }
	    if (misc_1.mcase == 0) {
		kctran_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 
			1), (ftnlen)2);
		s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), ch__1, (ftnlen)
			2, (ftnlen)2);
	    }
/* L20: */
	}
	goto L130;
    }

/*                  ***************************************** */
/*                  *                                       * */
/*                  *    PROCESS NON-FORMAT STATEMENTS.     * */
/*                  *                                       * */
/*                  ***************************************** */

    misc_1.lfir = 6;
    misc_1.ifir = 14;
/*                            SET FLAG FOR NON-FORMAT */
    igoof = -1;
/*                   LOOK FOR SPECIAL CHARACTERS. */
L30:
    i__ = misc_1.jcol;
    i__1 = misc_1.jmax;
    for (misc_1.jcol = i__; misc_1.jcol <= i__1; ++misc_1.jcol) {
	s_copy(it, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)
		2);
	isdel = FALSE_;
/*          (CHECK FOR SPL CHAR BEFORE DELIMS SINCE NEED J TO SET IFIR.) */

/*     =    ,    (    /    )    +    -    *    .    $    -    '    & NONE */
/*     1    2    3    4    5    6    7    8    9    10   11   12   13  14 */

	for (j = 1; j <= 13; ++j) {
	    if (s_cmp(it, alpha_1.kspk + (j - 1 << 1), (ftnlen)2, (ftnlen)2) 
		    == 0) {
/*                   FOUND ONE.  IS IT THE FIRST... */
		if (misc_1.ifir == 14) {
/*                   YES */
		    misc_1.ifir = j;
		    misc_1.lfir = misc_1.jcol;
/*     QUIT IF THIS STATEMENT TYPE DOESN'T ALLOW STRINGS.  JUST NEEDED */
/*     IFIR AND LFIR POINTERS. */
		    if (*lsscn == 0 && *ltype != 0) {
			if (misc_1.mcase == 0) {
			    i__2 = misc_1.jmax;
			    for (i__ = misc_1.jcol; i__ <= i__2; ++i__) {
				kctran_(ch__1, (ftnlen)2, miscal_1.jint + (
					i__ - 1 << 1), (ftnlen)2);
				s_copy(miscal_1.jint + (i__ - 1 << 1), ch__1, 
					(ftnlen)2, (ftnlen)2);
/* L40: */
			    }
			}
			if (misc_1.mdeb > 0) {
			    io___237.ciunit = lunits_1.outfil;
			    s_wsfe(&io___237);
			    do_fio(&c__1, (char *)&misc_1.ifir, (ftnlen)
				    sizeof(integer));
			    do_fio(&c__1, (char *)&misc_1.lfir, (ftnlen)
				    sizeof(integer));
			    e_wsfe();
			}
			return 0;
		    }
		}
		isdel = s_cmp(it, alpha_1.kdel1, (ftnlen)2, (ftnlen)2) == 0 ||
			 s_cmp(it, alpha_1.kdel2, (ftnlen)2, (ftnlen)2) == 0 
			&& *ltype != 13;
		if (isdel) {
		    goto L180;
		}
		goto L70;
	    }
/* L50: */
	}
/*     (DELIMS MAY NOT BE SPECIAL CHARACTER, CHECK TO BE SURE) */
	isdel = s_cmp(it, alpha_1.kdel1, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(
		it, alpha_1.kdel2, (ftnlen)2, (ftnlen)2) == 0 && *ltype != 13;
	if (isdel) {
	    goto L180;
	}
	if (misc_1.mcase == 0) {
	    kctran_(ch__1, (ftnlen)2, it, (ftnlen)2);
	    s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), ch__1, (ftnlen)2, (
		    ftnlen)2);
	}
/* L60: */
    }
    goto L310;
/*                   LOOK FOR FOLLOWING NUMBER. */
L70:
    if (misc_1.jcol == misc_1.jmax) {
	goto L310;
    }
    ++misc_1.jcol;
    rstat_();
/*                   REPEAT IF NO NUMBER. */
    if ((integer) misc_1.l772 == 0) {
	goto L30;
    }
/*     MAKE IT UPPER CASE */
    if (misc_1.mcase == 0) {
	kctran_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (
		ftnlen)2);
	s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), ch__1, (ftnlen)2, (
		ftnlen)2);
    }
    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)
	    2);
    s_copy(it, ch__1, (ftnlen)2, (ftnlen)2);
/*                  IS IT -H-,-L-, OR -R- */
    if (s_cmp(it, alpha_1.kabc + 14, (ftnlen)2, (ftnlen)2) == 0) {
	lhtrn = misc_1.khtran % 2 == 0;
    } else if (s_cmp(it, alpha_1.kabc + 22, (ftnlen)2, (ftnlen)2) == 0 || 
	    s_cmp(it, alpha_1.kabc + 34, (ftnlen)2, (ftnlen)2) == 0) {
	lhtrn = misc_1.khtran < 2;
/*     COMPLAIN ABOUT L OR R IF ANSI FLAG SET. */
	if (misc_1.mansi == 0) {
	    diagno_(&c__36);
	}
    } else {
	goto L30;
    }
/*                  MARK AS PART OF STRING (FOR INDENTING) */
    if (lhtrn) {
	*(unsigned char *)&miscal_1.jint[(misc_1.jcol - 1 << 1) + 1] = *(
		unsigned char *)&alpha_1.kat[1];
    }

/*     ALSO MARK THE NUMBERS. */
    ktmp = (integer) misc_1.l772;
    i__ = misc_1.jcol;
L80:
    --i__;
    if (s_cmp(miscal_1.jint + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (ftnlen)
	    2) == 0) {
	goto L80;
    }
    if (lhtrn) {
	*(unsigned char *)&miscal_1.jint[(i__ - 1 << 1) + 1] = *(unsigned 
		char *)&alpha_1.kat[1];
    }
    ktmp /= 10;
    if (ktmp > 0) {
	goto L80;
    }
    ip = i__;
/*                  FIND LIMITS OF HOLLERITH FIELD. */
    i__ = misc_1.jcol + 1;
    misc_1.jcol += (integer) misc_1.l772;
/*                   L772 IS THE LENGTH OF THE FIELD, AS FOUND BY RSTAT */
/*                  CHECK FOR CASE OF HOLLERITH BLANKS SPILLING OFF */
/*                  END OF CARD. E.G. I=6HXXXXX */
    if (misc_1.jcol > misc_1.jmax) {
/*                  REPLACE CURRENT END CARD MARK. */
	s_copy(miscal_1.jint + (misc_1.jmax << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2);
/*                   AND SET NEW ONE */
	misc_1.jmax = misc_1.jcol;
	s_copy(miscal_1.jint + (misc_1.jmax << 1), alpha_1.kerm, (ftnlen)2, (
		ftnlen)2);
    }
/*                  CHANGE ALL CHARACTERS IN HOLLERITH FIELD. */
/* L90: */
    i__1 = misc_1.jcol;
    for (j = i__; j <= i__1; ++j) {
	jj = j;
/*                  SKIP CHARACTERS IN 73-80 OF ORIGINAL CARD. */
L95:
	if (*(unsigned char *)&miscal_1.jint[(jj - 1 << 1) + 1] == '!') {
	    *(unsigned char *)&miscal_1.jint[(jj - 1 << 1) + 1] = ' ';
	    ++jj;
	    if (strp73) {
		strp73 = FALSE_;
		diagno_(&c__52);
	    }
	    goto L95;
	} else {
	    *(unsigned char *)&miscal_1.jint[(jj - 1 << 1) + 1] = *(unsigned 
		    char *)&alpha_1.kat[1];
	}
/* L100: */
    }
    misc_1.jcol = jj;
    if (! lhtrn) {

/*     TURN THIS ON IF WANT LOGGING OF H TRANSLATIONS IN FORMATS */
	if (misc_1.khlog == 0) {
	    ++misc_1.nlhtrn;
	}

/*     IF TRANSLATING H-FIELDS, COPY STRING AND DUPLICATE APOSTROPHES. */
/* Computing MAX */
	i__1 = (integer) misc_1.l772;
	lntmp = max(i__1,lntmp);
	s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2);
	++ip;
	j = i__;
/*         SKIP ANY EXTRA CHARS FROM 73-80 */
L110:
	if (*(unsigned char *)&miscal_1.jint[(j - 1 << 1) + 1] == '!') {
	    ++misc_1.jcol;
	    ++j;
	    goto L110;
	}

	s_copy(miscal_1.jint + (ip - 1 << 1), miscal_1.jint + (j - 1 << 1), (
		ftnlen)2, (ftnlen)2);
	if (s_cmp(miscal_1.jint + (j - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2) == 0) {
	    ++ip;
	    if (ip >= j) {
		movstr_(&j);
	    }
	    s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		    ftnlen)2);
	}
	++j;
	++ip;
	if (j <= misc_1.jcol) {
	    goto L110;
	}
	s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2);
L120:
	++ip;
	if (ip <= misc_1.jcol) {
	    s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2);
	    goto L120;
	}
    }
    goto L30;

/*                  ********************************** */
/*                  *                                * */
/*                  *   PROCESS FORMAT STATEMENTS.   * */
/*                  *                                * */
/*                  ********************************** */

L130:
    igoof = 0;
    misc_1.ifir = 3;
    misc_1.lfir = misc_1.jcol;
    goto L170;

/*                  LOOK FOR SPECIAL CHARACTER */
L140:
    if (misc_1.jcol > misc_1.jmax) {
	goto L310;
    }
    i__ = misc_1.jcol;
    i__1 = misc_1.jmax;
    for (misc_1.jcol = i__; misc_1.jcol <= i__1; ++misc_1.jcol) {
	s_copy(it, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)
		2);
	isdel = s_cmp(it, alpha_1.kdel1, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(
		it, alpha_1.kdel2, (ftnlen)2, (ftnlen)2) == 0;
	if (isdel) {
	    goto L180;
	}
	for (j = 1; j <= 12; ++j) {
	    if (s_cmp(it, alpha_1.kspk + (j - 1 << 1), (ftnlen)2, (ftnlen)2) 
		    == 0) {
		goto L220;
	    }
/* L150: */
	}
	if (misc_1.mcase == 0) {
	    kctran_(ch__1, (ftnlen)2, it, (ftnlen)2);
	    s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), ch__1, (ftnlen)2, (
		    ftnlen)2);
	}
/* L160: */
    }
    goto L310;

/*                  SKIP IF NOT * OR ' */
L170:
    if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kdel1, (ftnlen)
	    2, (ftnlen)2) != 0 && s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1)
	    , alpha_1.kdel2, (ftnlen)2, (ftnlen)2) != 0) {
	goto L220;
    }
/*                  CHANGE ALL CHARACTERS BETWEEN *S OR 'S */
L180:
    s_copy(kparam, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)
	    2);
/*                  MARK AS PART OF STRING (FOR INDENTING) */
    *(unsigned char *)&miscal_1.jint[(misc_1.jcol - 1 << 1) + 1] = *(unsigned 
	    char *)&alpha_1.kat[1];
    ip = misc_1.jcol;

L190:
    if (misc_1.jcol == misc_1.jmax) {
	goto L310;
    }
    ++misc_1.jcol;
    s_copy(it, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)2);

/*     IF CHAR WAS IN COLS 73-80, UNMARK IT SO COPY WILL EAT IT. */
    if (*(unsigned char *)&it[1] == '~') {
	*(unsigned char *)&miscal_1.jint[(misc_1.jcol - 1 << 1) + 1] = ' ';
	if (strp73) {
	    strp73 = FALSE_;
	    diagno_(&c__52);
	}
    } else {
	*(unsigned char *)&miscal_1.jint[(misc_1.jcol - 1 << 1) + 1] = *(
		unsigned char *)&alpha_1.kat[1];
    }
    if (s_cmp(it, kparam, (ftnlen)2, (ftnlen)2) == 0) {
	if (s_cmp(miscal_1.jint + (misc_1.jcol << 1), kparam, (ftnlen)2, (
		ftnlen)2) != 0) {
	    goto L200;
	}
/*     THIS IS A LITERAL -- NOT TERMINAL DELIMITER */
	++misc_1.jcol;
	*(unsigned char *)&miscal_1.jint[(misc_1.jcol - 1 << 1) + 1] = *(
		unsigned char *)&alpha_1.kat[1];
    }
    goto L190;
/*                            ALL CHANGED, CHANGE DELIMS IF DESIRED. */
L200:
    if (misc_1.kdtran == 1 && s_cmp(kparam, alpha_1.kdel1, (ftnlen)2, (ftnlen)
	    2) != 0) {
	s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2);
	s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kapstr, (
		ftnlen)2, (ftnlen)2);
	j = ip;
L210:
	++j;
	if (j < misc_1.jcol) {
	    if (s_cmp(miscal_1.jint + (j - 1 << 1), alpha_1.kapstr, (ftnlen)2,
		     (ftnlen)2) == 0) {
/*     DUPLICATE LITERAL VERSION OF DELIMITER */
		movstr_(&j);
		s_copy(miscal_1.jint + (j - 1 << 1), alpha_1.kapstr, (ftnlen)
			2, (ftnlen)2);
	    }
	    goto L210;
	}
    }
    if (igoof == -1) {
	goto L70;
    }
/*                  LOOK FOR FOLLOWING NUMBER */
L220:
    if (misc_1.jcol == misc_1.jmax) {
	goto L310;
    }
    ++misc_1.jcol;
    rstat_();
/*                  IF NOT A NUMBER, START AGAIN */
    if ((integer) misc_1.l772 == 0) {
	goto L140;
    }
/*                  NUMBER FOUND. LOOK AT NEXT CHARACTER. */
    if (misc_1.mcase == 0) {
	kctran_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (
		ftnlen)2);
	s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), ch__1, (ftnlen)2, (
		ftnlen)2);
    }
    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)
	    2);
    s_copy(it, ch__1, (ftnlen)2, (ftnlen)2);
/*                  IS IT -H- */
    if (s_cmp(it, alpha_1.kabc + 14, (ftnlen)2, (ftnlen)2) == 0) {
	lhtrn = misc_1.khtran % 2 == 0;
	goto L250;
/*                  MAYBE L OR R */
    } else if (s_cmp(it, alpha_1.kabc + 22, (ftnlen)2, (ftnlen)2) == 0 || 
	    s_cmp(it, alpha_1.kabc + 34, (ftnlen)2, (ftnlen)2) == 0) {
	lhtrn = misc_1.khtran < 2;
	if (misc_1.mansi == 0) {
	    diagno_(&c__36);
	}
	goto L250;
    }
/*                  IF NOT -X-, START AGAIN. */
    if (s_cmp(it, alpha_1.kabc + 46, (ftnlen)2, (ftnlen)2) != 0) {
	goto L140;
    }
/*                  X FOUND.  LOOK AT NEXT. */
L230:
    if (misc_1.jcol == misc_1.jmax) {
	goto L310;
    }
    ++misc_1.jcol;
    if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kbl, (ftnlen)2, 
	    (ftnlen)2) == 0) {
	goto L230;
    }
    if (misc_1.mcase == 0) {
	kctran_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (
		ftnlen)2);
	s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), ch__1, (ftnlen)2, (
		ftnlen)2);
    }
    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)
	    2);
    s_copy(it, ch__1, (ftnlen)2, (ftnlen)2);
/*                  IS IT -*- */
    if (s_cmp(it, alpha_1.kdel1, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(it, 
	    alpha_1.kdel2, (ftnlen)2, (ftnlen)2) == 0) {
	goto L170;
    }
/*                  IS IT -)- OR -,- */
    if (s_cmp(it, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) == 0) {
	goto L220;
    }
    if (s_cmp(it, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) == 0) {
	goto L220;
    }

/*     INSERT A COMMA */
    i__1 = misc_1.jcol;
    for (j = misc_1.jmax; j >= i__1; --j) {
	s_copy(miscal_1.jint + (j << 1), miscal_1.jint + (j - 1 << 1), (
		ftnlen)2, (ftnlen)2);
/* L240: */
    }
    s_copy(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kspk + 2, (ftnlen)
	    2, (ftnlen)2);
    ++misc_1.jmax;
    s_copy(miscal_1.jint + (misc_1.jmax << 1), alpha_1.kerm, (ftnlen)2, (
	    ftnlen)2);
    diagno_(&c__25);
    igoof = 1;
    goto L220;

/*                  HOLLERITH FOUND.   FIND LIMITS OF FIELD. */
L250:
    if (lhtrn) {
	*(unsigned char *)&miscal_1.jint[(misc_1.jcol - 1 << 1) + 1] = *(
		unsigned char *)&alpha_1.kat[1];
    }

/*     ALSO MARK THE NUMBERS. */
    j = (integer) misc_1.l772;
    i__ = misc_1.jcol;
L260:
    --i__;
    if (s_cmp(miscal_1.jint + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (ftnlen)
	    2) == 0) {
	goto L260;
    }
    if (lhtrn) {
	*(unsigned char *)&miscal_1.jint[(i__ - 1 << 1) + 1] = *(unsigned 
		char *)&alpha_1.kat[1];
    }
    j /= 10;
    if (j > 0) {
	goto L260;
    }

    ip = i__;
    i__ = misc_1.jcol + 1;
    misc_1.jcol += (integer) misc_1.l772;
    if (misc_1.jcol <= misc_1.jmax) {
	goto L270;
    }
    s_copy(miscal_1.jint + (misc_1.jmax << 1), alpha_1.kbl, (ftnlen)2, (
	    ftnlen)2);
    misc_1.jmax = misc_1.jcol;
    s_copy(miscal_1.jint + (misc_1.jmax << 1), alpha_1.kerm, (ftnlen)2, (
	    ftnlen)2);
L270:
    i__1 = misc_1.jcol;
    for (j = i__; j <= i__1; ++j) {
	jj = j;
L275:
	if (*(unsigned char *)&miscal_1.jint[(jj - 1 << 1) + 1] == '~') {
	    *(unsigned char *)&miscal_1.jint[(jj - 1 << 1) + 1] = ' ';
	    ++jj;
	    if (strp73) {
		strp73 = FALSE_;
		diagno_(&c__52);
	    }
	    goto L275;
	}
	*(unsigned char *)&miscal_1.jint[(jj - 1 << 1) + 1] = *(unsigned char 
		*)&alpha_1.kat[1];
/* L280: */
    }
    if (! lhtrn) {

/*     IF TRANSLATING H-FIELDS, COPY STRING AND DUPLICATE APOSTROPHES. */
	if (misc_1.khlog == 0) {
	    ++misc_1.nlhtrn;
	}
	s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2);
	++ip;
	j = i__;
/*          SKIP ANYTHING IN 73-80 IF MARKED. */
L290:
	if (*(unsigned char *)&miscal_1.jint[(j - 1 << 1) + 1] == '~') {
	    ++misc_1.jcol;
	    ++j;
	    goto L290;
	}
	s_copy(miscal_1.jint + (ip - 1 << 1), miscal_1.jint + (j - 1 << 1), (
		ftnlen)2, (ftnlen)2);
	if (s_cmp(miscal_1.jint + (j - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2) == 0) {
	    ++ip;
	    if (ip >= j) {
		movstr_(&j);
	    }
	    s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		    ftnlen)2);
	}
	++j;
	++ip;
	if (j <= misc_1.jcol) {
	    goto L290;
	}
	s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2);
L300:
	++ip;
	if (ip <= misc_1.jcol) {
	    s_copy(miscal_1.jint + (ip - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2);
	    goto L300;
	}
    }
    goto L220;

L310:
    if (lntmp > 0) {
	*lnstr = lntmp;
    }
    if (misc_1.nlhtrn > 0) {
	if (*ltype != 26) {
	    diagno_(&c__39);
	}
	misc_1.nlhtrn = 0;
    }
    if (misc_1.mdeb > 0) {
	io___243.ciunit = lunits_1.outfil;
	s_wsfe(&io___243);
	do_fio(&c__1, (char *)&misc_1.ifir, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&misc_1.lfir, (ftnlen)sizeof(integer));
	e_wsfe();
    }
    return 0;
} /* holscn_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int jtyp19_(integer *jrtcod, integer *nbcold)
{
    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    extern /* Subroutine */ int copy_(integer *);
    static integer merr;
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int wrbin_(integer *, integer *, char *, char *, 
	    ftnlen, ftnlen), dlist_(integer *);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int kwdwrt_(integer *);


/*                  ***** JTYPE = 19 */
/*     FORMAT ( */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*     ERROR IF NO STATEMENT NUMBER OR FIRST SPECIAL CHAR NOT ( */
/*  FORTRAN LOGICAL UNITS */
    if (*l15 == 0 || s_cmp(miscal_1.jint + (misc_1.jmax - 1 << 1), 
	    alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) != 0) {
	*jrtcod = 1;
	return 0;
    }

    if (*mex == 0) {
	if (misc_1.mcol == -1) {

/*          IF COLLECTING FORMATS, START THEM IN COLUMN 7 (OR JUST). */
	    misc_1.icol = 6;
	    if (misc_1.just > 0) {
		misc_1.icol = misc_1.just - 1;
	    }
	}

	kwdwrt_(&c__26);
/*                            COPY REST OF CARD */
	if (misc_1.mcol == 0) {
	    *jrtcod = 3;
	    return 0;
	}
/*                            ONTO UNIT 2 */
	copy_(&c__0);
	*imax = misc_1.icol;
	*jtype = misc_1.nrec;
	wrbin_(&lunits_1.scfil2, misc_1.kili, miscal_1.serial, miscal_1.iout, 
		(ftnlen)2, (ftnlen)2);
	++misc_1.nrt2;
	misc_1.nblc = *nbcold;
    } else {

/*     EXEMPT FLAG IS ON - TRANSFER TO TAPE1 OR TAPE2 WITHOUT REMOVING */
/*     ANY BLANKS. */

/*          ITYPE=NREC */
	dlist_(&merr);
	misc_1.nblc = *nbcold;
	*icolsv = 6;
	if (merr >= 0) {
	    if (misc_1.mcol != 0) {
		wrbin_(&lunits_1.scfil2, misc_1.kili, miscal_1.serial, 
			miscal_1.jint, (ftnlen)2, (ftnlen)2);
		++misc_1.nrt2;
	    } else {
		wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, 
			miscal_1.jint, (ftnlen)2, (ftnlen)2);
		++misc_1.nrt1;
	    }
	}
    }

    *jrtcod = 2;
    return 0;
} /* jtyp19_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int jtyp31_(integer *jrtcod)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
    static char jt[2];
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    extern /* Subroutine */ int copy_(integer *);
    static integer ncom, merr, jerr;
    extern /* Subroutine */ int adnum_(integer *);
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int rstat_(void), dlist_(integer *), diagno_(
	    integer *), kwscan_(integer *, integer *);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int kwdwrt_(integer *);


/*                  ***** JTYPE = 31 */
/*     IF (ARITHMETIC) 1,2,3   OR   IF (LOGICAL) STATEMENT. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

    kwdwrt_(&c__38);
/*                  COPY UNTIL CLOSED PARENTHESES */
    copy_(&c_n1);
    if (misc_1.meof >= 0) {
	goto L80;
    }
    ++misc_1.icol;
    rstat_();
    if ((integer) misc_1.l772 != 0) {

/*     STATEMENT IS    IF (ARITHMETIC) 1,2,3 */

	ncom = 0;
	misc_1.mildo = -1;
	dlist_(&merr);
	if (merr < 0) {
	    goto L80;
	}
L10:
	adnum_(&jerr);
	if (jerr == 1) {
	    *jrtcod = 2;
	    return 0;
	}
	copy_(&c__1);
	if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) == 0)
		 {
	    ++ncom;
	    if (ncom > 3) {
		goto L80;
	    }
	    if (ncom == 3) {
		diagno_(&c__18);
	    }
	    rstat_();
	    if ((integer) misc_1.l772 == 0) {
		goto L80;
	    }
	    goto L10;
	}
	if (s_cmp(miscal_1.lcpy, alpha_1.kerm, (ftnlen)2, (ftnlen)2) != 0) {
	    goto L80;
	}
	if (ncom <= 0) {
	    goto L80;
	}
	if (ncom == 1) {
	    diagno_(&c__18);
	}
	*mtran = misc_1.mlgc;
	*jrtcod = 3;
	return 0;
    }

/*     STATEMENT IS   IF (LOGICAL) STATEMENT */

    misc_1.mlgc = 0;

/*        CHECK FOR 'IF () THEN' UNLESS IT IS  ELSEIF () THEN */
    if (*jtype == 43) {
	goto L40;
    }
    i__ = 69;
    kwscan_(&i__, ps1sub_1.kstc);
    if (i__ != 69) {
	goto L40;
    }
    kwdwrt_(&i__);
/*        LOOP TO CHECK REST FOR BLANKS. */
    i__1 = misc_1.jmax;
    for (i__ = misc_1.jcol; i__ <= i__1; ++i__) {
	if (s_cmp(miscal_1.jint + (i__ - 1 << 1), alpha_1.kerm, (ftnlen)2, (
		ftnlen)2) == 0) {
	    goto L30;
	}
	if (s_cmp(miscal_1.jint + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2) != 0) {
	    goto L40;
	}
/* L20: */
    }
L30:
    ++ps1sub_1.nifblk;
    *jrtcod = 4;
    return 0;

/*                   LOOK FOR FIRST SPECIAL CHARACTER. */
L40:
    i__1 = misc_1.jmax;
    for (misc_1.lfir = misc_1.jcol; misc_1.lfir <= i__1; ++misc_1.lfir) {
	s_copy(jt, miscal_1.jint + (misc_1.lfir - 1 << 1), (ftnlen)2, (ftnlen)
		2);
	for (misc_1.ifir = 1; misc_1.ifir <= 11; ++misc_1.ifir) {
	    if (s_cmp(jt, alpha_1.kspk + (misc_1.ifir - 1 << 1), (ftnlen)2, (
		    ftnlen)2) == 0) {
		goto L70;
	    }
/* L50: */
	}
/* L60: */
    }
    misc_1.lfir = 6;
    misc_1.ifir = 14;
L70:
    *jrtcod = 5;
    return 0;

L80:
    *jrtcod = 1;
    return 0;

} /* jtyp31_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int jtyp33_(integer *itype, integer *jrtcod)
{
    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    extern /* Subroutine */ int copy_(integer *), adnum_(integer *);
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int rstat_(void);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int kwdwrt_(integer *);


/*     PROCESS TYPE 33 CARDS - AGS 23 DEC 1993 */

/*     JRTCOD IS RETURN CODE - USE COMPUTED GOTO TO BRANCH TO PROPER */
/*      PLACE IN PASS1. */


/*                  ***** JTYPE = 33 */
/*     PRINT, TYPE, WRITE, PUNCH, READ, ACCEPT. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    kwdwrt_(itype);
    rstat_();
    if ((integer) misc_1.l772 != 0) {
	goto L20;
    }

/*     HAVE WRITE  FMT,LIST */

/*            , AS IN PRINT IFT,XXX */
    if (misc_1.ifir != 2) {
/*            *, AS IN PRINT *,XXX */
	if (misc_1.ifir == 8 || misc_1.ifir == 12 || misc_1.ifir == 14) {
	    *jrtcod = 1;
	} else {
	    *jrtcod = 2;
	}
	return 0;
    }

L10:
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) == 0) {
	*jrtcod = 3;
	return 0;
    }
    if (misc_1.meof < 0) {
	goto L10;
    }
    *jrtcod = 2;
    return 0;

/*     HAVE WRITE  12345 LIST */

L20:
    adnum_(jrtcod);
    if (*jrtcod == 1) {
	*jrtcod = 4;
	return 0;
    }
    if (misc_1.ifir == 2) {
	goto L10;
    }
    if (misc_1.jmax > misc_1.jcol) {
	*jrtcod = 2;
    } else {
	*imax = misc_1.icol;
	*jrtcod = 5;
    }
    return 0;
} /* jtyp33_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Character */ VOID kctran_(char *ret_val, ftnlen ret_val_len, char *c__, 
	ftnlen c_len)
{
    /* Builtin functions */
    integer i_indx(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer j;
    static char ct[1];


/*     CONVERTS ALL LETTERS TO A SINGLE CASE, SELECTED BY USER'S CALL TO */
/*      SUBROUTINE KCTSET. */
/*     PORTABLE VERSION - NOT ASCII/EBCDIC DEPENDENT. */
/*     AGS 12 OCT 93 */


/*     COMMON BLOCK FOR CHARACTER TRANSLATION TABLES */

/*     FIND POSITION OF CHARACTER IN INPUT-CASE ALPHABET */
    *(unsigned char *)ct = *(unsigned char *)c__;
    j = i_indx(ctran_1.linin, ct, (ftnlen)26, (ftnlen)1);

/*     IF FOUND, RETURN OUTPUT-CASE EQUIVALENT, OTHERWISE ORIGINAL CHAR. */
    if (j > 0) {
	s_copy(ret_val, ctran_1.linout + (j - 1), (ftnlen)2, (ftnlen)1);
    } else {
	s_copy(ret_val, c__, (ftnlen)2, (ftnlen)2);
    }

    return ;
} /* kctran_ */

/* Subroutine */ int kctset_(integer *ip)
{
    /* Initialized data */

    static char ctbl[26*2] = "abcdefghijklmnopqrstuvwxyz" "ABCDEFGHIJKLMNOPQ"
	    "RSTUVWXYZ";

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);


/*     SET CHARACTER TRANSLATION TABLE FOR KCTRAN: */
/*     IP = 0 - LOWER TO UPPER */
/*     IP = 1 - UPPER TO LOWER */

/*     COMMON BLOCK FOR CHARACTER TRANSLATION TABLES */

/*     ASSIGN INPUT AND OUTPUT ALPHABETS BASED ON VALUE OF IP. */
    s_copy(ctran_1.linin, ctbl + (0 + (0 + (*ip - 0) * 26)), (ftnlen)26, (
	    ftnlen)26);
    s_copy(ctran_1.linout, ctbl + (1 - *ip) * 26, (ftnlen)26, (ftnlen)26);

    return 0;
} /* kctset_ */

/* Character */ VOID khide_(char *ret_val, ftnlen ret_val_len, char *c__, 
	ftnlen c_len)
{
    /* System generated locals */
    address a__1[2];
    integer i__1[2];

    /* Builtin functions */
    /* Subroutine */ int s_cat(char *, char **, integer *, integer *, ftnlen),
	     s_copy(char *, char *, ftnlen, ftnlen);


/*     CONVERT CHARACTERS IN HOLSCN STRINGS TO SPECIAL FORM */
/*      (UNLESS ALREADY SET TO INDICATE EMBEDDED COMMENT STATEMENT) */
/*      SO THAT BLANKS WILL NOT BE REMOVED FROM STRINGS. */

    if (*(unsigned char *)&c__[1] == ' ') {
/* Writing concatenation */
	i__1[0] = 1, a__1[0] = c__;
	i__1[1] = 1, a__1[1] = "@";
	s_cat(ret_val, a__1, i__1, &c__2, (ftnlen)2);
    } else {
	s_copy(ret_val, c__, (ftnlen)2, (ftnlen)2);
    }
    return ;
} /* khide_ */

/* Subroutine */ int kimpak_(void)
{
    /* Format strings */
    static char fmt_130[] = "(\002 KIMPAK - IOUT IN:\002/(1x,75a1))";
    static char fmt_140[] = "(\002 KIMPAK - OUTPUT:\002/(1x,80a1))";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__, j, k7;
#define l15 ((integer *)&misc_1 + 23)
    static integer jl, jr;
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    static integer krr;
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int diagno_(integer *);
    static logical conind, savblk;
#define icolsv ((integer *)&misc_1 + 28)
    static logical splstr;

    /* Fortran I/O blocks */
    static cilist io___292 = { 0, 0, 0, fmt_130, 0 };
    static cilist io___299 = { 0, 0, 0, fmt_140, 0 };



/*     THIS ROUTINE PACKS SUPER-CARD IMAGES FROM IOUT(I) INTO KIM(I,J). */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */

    conind = TRUE_;
    splstr = FALSE_;

/*     SET BLANK STRIP MODE */
    savblk = *mex > 0 || *mex < 0 && (*klass == 3 || *klass == 5);

    if (misc_1.mdeb > 0) {
	io___292.ciunit = lunits_1.outfil;
	s_wsfe(&io___292);
	i__1 = *imax;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    do_fio(&c__1, miscal_1.iout + (i__ - 1 << 1), (ftnlen)2);
	}
	e_wsfe();
    }
L10:
    j = 0;

L20:
    ++j;

/*     KLASS 2 AND BELOW HAVE NO CONTINUATIONS. */
    if (*klass < 2) {
	k7 = 0;
	jl = 1;
	if (*klass == 1 && misc_1.mser == 0) {
	    jr = 80;
	} else {
	    jr = 72;
	}
	goto L90;
    }

/*     INDENTING COULD MAKE CARD OVERFLOW CONTINUATIONS, IF SO, REPACK. */
    if (j > misc_1.maxcnt + 1) {
/*         ISSUE DIAGNOSTIC IF WE HAVE ALREADY TRIED TO REPACK IT. */
	if (! conind) {
	    diagno_(&c__37);
	    j = misc_1.maxcnt + 1;
	    goto L120;
	}
/*         FIRST TIME - SET FLAG AND TRY AGAIN WITHOUT INDENTING. */
	conind = FALSE_;
	jl = 7;
	jr = 72;
	k7 = *icolsv;
	goto L10;
    }

/*     PREPARE COLUMNS 1-6 OF FIRST CARD. */
    if (conind) {
	if (j == 1) {
	    k7 = *icolsv;
	    for (i__ = 1; i__ <= 6; ++i__) {
		s_copy(kim + (i__ - 1 << 1), miscal_1.iout + (i__ - 1 << 1), (
			ftnlen)2, (ftnlen)2);
/* L30: */
	    }
	} else {
/*     BLANK COLUMN 1-5 */
	    for (i__ = 1; i__ <= 5; ++i__) {
		s_copy(kim + (i__ + j * 80 - 81 << 1), alpha_1.kbl, (ftnlen)2,
			 (ftnlen)2);
/* L40: */
	    }
/*     COLUMN 6 - NUMBER SERIALLY UNLESS CCHR SET OTHERWISE. */
	    if (misc_1.kctctl == 0) {
		if (j < 11) {
		    s_copy(kim + (j * 80 - 75 << 1), alpha_1.kdig + (j - 1 << 
			    1), (ftnlen)2, (ftnlen)2);
		} else {
		    s_copy(kim + (j * 80 - 75 << 1), alpha_1.kspk + 18, (
			    ftnlen)2, (ftnlen)2);
		}
	    } else {
		s_copy(kim + (j * 80 - 75 << 1), alpha_1.kctchr, (ftnlen)2, (
			ftnlen)2);
	    }
	}

/*     SET LEFT EDGE OF TEXT */
/*      (USE COL 7 IF EXEMPT, NON-INDENTED, OR IF PART OF STRING */
	if (savblk || *icolsv == 6 || *(unsigned char *)&miscal_1.iout[(k7 - 
		1 << 1) + 1] == *(unsigned char *)&alpha_1.kat[1] && *(
		unsigned char *)&miscal_1.iout[(k7 << 1) + 1] == *(unsigned 
		char *)&alpha_1.kat[1]) {
	    jl = 7;
	} else {
	    jl = *icolsv;
	    if (j > 1) {
		++jl;
	    }
	    i__1 = jl;
	    for (i__ = 7; i__ <= i__1; ++i__) {
		s_copy(kim + (i__ + j * 80 - 81 << 1), alpha_1.kbl, (ftnlen)2,
			 (ftnlen)2);
/* L50: */
	    }
	    ++jl;
	}

/*     SET RIGHT EDGE OF TEXT */
/*     FIRST GET RIGHT-MOST POTENTIAL CHAR IN STRING (KRR) */
	jr = 72;
	krr = k7 + jr - jl + 1;
	if (krr > *imax) {
/*     IF PAST END OF STATEMENT, STOP AT END. */
	    jr = jl + *imax - k7 - 1;
	    goto L90;
	}

/*     NOW CHECK IF WE CAN BREAK IT HERE. */
/*     BREAK IF PART OF A STRING. KIMPAK PROTECTS DELIMETERS ALSO. */
L60:
	if (*(unsigned char *)&miscal_1.iout[(krr - 1 << 1) + 1] == *(
		unsigned char *)&alpha_1.kat[1]) {

/*     FORMAT STATEMENTS - MAY HAVE PROBLEMS WITH QUOTES AT END. */
	    if (*klass == 5) {
/*          DON'T SPLIT IF TURNED OFF OR AT TOP INDENT LEVEL. */
		if (misc_1.kfspl == 1 || *icolsv == 6) {
		    goto L90;
		}
/*          IF NEXT CHAR NOT IN STRING, BREAK IS FINE. */
		if (*(unsigned char *)&miscal_1.iout[(krr << 1) + 1] != *(
			unsigned char *)&alpha_1.kat[1]) {
		    goto L90;
		}

/*          COLUMN 72 NOT A QUOTE, CAN SPLIT ON COL 71 */
		if (s_cmp(miscal_1.iout + (krr - 1 << 1), alpha_1.kapstr, (
			ftnlen)2, (ftnlen)2) != 0) {
/*          INSERT ',' IN STRING */
		    --jr;
		    splstr = TRUE_;
		} else {
/*          COLUMN 72 QUOTE WITHIN A STRING, BACKTRACK. */
		    --krr;
		    --jr;
		    if (jr > jl) {
			goto L60;
		    }
		}
/*     END FORMAT STRING BREAKER */
	    }
	    goto L90;
	}

/*     BREAK IF IT IS A BLANK (NOT IN STRING) */
	if (s_cmp(miscal_1.iout + (krr - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2) == 0) {
	    goto L90;
	}

/*     GO BACK IF LEFT PARENTHESIS */
L70:
	if (s_cmp(miscal_1.iout + (krr - 1 << 1), alpha_1.kspk + 4, (ftnlen)2,
		 (ftnlen)2) == 0) {
	    --krr;
	    --jr;
	    goto L70;
	}

/*     BREAK FOR SPECIAL CHARACTERS (EXCEPT DECIMAL POINTS) */
	for (i__ = 1; i__ <= 14; ++i__) {
	    if (s_cmp(miscal_1.iout + (krr - 1 << 1), alpha_1.kspk + (i__ - 1 
		    << 1), (ftnlen)2, (ftnlen)2) == 0 && i__ != 9) {
		goto L90;
	    }
/* L80: */
	}

/*     OTHERWISE BACK UP ONE, TRY AGAIN. */
	--krr;
	--jr;
	if (jr > jl) {
	    goto L60;
	}

/*     IF GO ALL THE WAY BACK, FORCE IT TO 72 */
	jr = 72;
    }

/*     COPY THE TEXT */
L90:
    i__1 = jr;
    for (i__ = jl; i__ <= i__1; ++i__) {
	++k7;
	if (k7 <= *imax) {
	    s_copy(kim + (i__ + j * 80 - 81 << 1), miscal_1.iout + (k7 - 1 << 
		    1), (ftnlen)2, (ftnlen)2);
	} else {
	    s_copy(kim + (i__ + j * 80 - 81 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2);
	}
/* L100: */
    }

/*     STRING SPLITTER */
    if (splstr) {
	s_copy(kim + (jr + 1 + j * 80 - 81 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2);
	s_copy(miscal_1.iout + (k7 - 2 << 1), alpha_1.kspk + 2, (ftnlen)2, (
		ftnlen)2);
	s_copy(miscal_1.iout + (k7 - 1 << 1), alpha_1.kapstr, (ftnlen)2, (
		ftnlen)2);
	k7 += -2;
	++jr;
	splstr = FALSE_;
    }

/*     SCRUB GARBAGE OFF END IF SHORTER THAN 72 */
/*     IF (JR.LT.72) THEN */
    for (i__ = jr + 1; i__ <= 80; ++i__) {
	s_copy(kim + (i__ + j * 80 - 81 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2);
/* L110: */
    }
/*     END IF */

/*     DO ANOTHER CONTINUATION IF NECESSARY. */
    if (k7 < *imax) {
	goto L20;
    }

L120:
    misc_1.ncd = j;
    if (misc_1.mdeb > 0) {
	io___299.ciunit = lunits_1.outfil;
	s_wsfe(&io___299);
	i__1 = misc_1.ncd;
	for (j = 1; j <= i__1; ++j) {
	    for (i__ = 1; i__ <= 80; ++i__) {
		do_fio(&c__1, kim + (i__ + j * 80 - 81 << 1), (ftnlen)2);
	    }
	}
	e_wsfe();
    }
    return 0;

} /* kimpak_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Character */ VOID kupper_(char *ret_val, ftnlen ret_val_len, char *c__, 
	ftnlen c_len)
{
    /* Initialized data */

    static char lc[26] = "abcdefghijklmnopqrstuvwxyz";
    static char uc[26] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    /* Builtin functions */
    integer i_indx(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer j;
    static char ct[1];


/*     CONVERTS LOWER-CASE LETTERS TO UPPER-CASE. PORTABLE VERSION. */
/*     AGS 23 APR 93 */


/*     FIND POSITION OF CHARACTER IN LOWER-CASE ALPHABET */
    *(unsigned char *)ct = *(unsigned char *)c__;
    j = i_indx(lc, ct, (ftnlen)26, (ftnlen)1);

/*     IF FOUND, RETURN UPPER-CASE EQUIVALENT, OTHERWISE ORIGINAL CHAR. */
    if (j > 0) {
	s_copy(ret_val, uc + (j - 1), (ftnlen)2, (ftnlen)1);
    } else {
	s_copy(ret_val, c__, (ftnlen)2, (ftnlen)2);
    }

    return ;
} /* kupper_ */

/* Subroutine */ int kwdwrt_(integer *kw)
{
    /* Initialized data */

    static integer kwl[90] = { 7,7,7,11,11,10,11,5,10,7,8,9,5,8,10,17,17,8,10,
	    6,9,6,12,8,6,8,7,3,9,7,6,26,23,18,11,16,17,3,8,8,8,9,6,6,8,6,6,6,
	    6,5,5,7,8,8,12,5,11,5,7,7,7,8,6,10,9,6,5,5,5,7,8,9,10,6,10,5,9,4,
	    7,6,7,10,7,13,3,3,9,6,5,5 };
    static struct {
	char e_1[14];
	char fill_2[38];
	char e_3[14];
	char fill_4[38];
	char e_5[14];
	char fill_6[38];
	char e_7[22];
	char fill_8[30];
	char e_9[22];
	char fill_10[30];
	char e_11[20];
	char fill_12[32];
	char e_13[22];
	char fill_14[30];
	char e_15[10];
	char fill_16[42];
	char e_17[20];
	char fill_18[32];
	char e_19[14];
	char fill_20[38];
	char e_21[16];
	char fill_22[36];
	char e_23[18];
	char fill_24[34];
	char e_25[10];
	char fill_26[42];
	char e_27[16];
	char fill_28[36];
	char e_29[20];
	char fill_30[32];
	char e_31[34];
	char fill_32[18];
	char e_33[34];
	char fill_34[18];
	char e_35[16];
	char fill_36[36];
	char e_37[20];
	char fill_38[32];
	char e_39[12];
	char fill_40[40];
	char e_41[18];
	char fill_42[34];
	char e_43[12];
	char fill_44[40];
	char e_45[24];
	char fill_46[28];
	char e_47[16];
	char fill_48[36];
	char e_49[12];
	char fill_50[40];
	char e_51[16];
	char fill_52[36];
	char e_53[14];
	char fill_54[38];
	char e_55[16];
	char fill_56[36];
	char e_57[18];
	char fill_58[34];
	char e_59[14];
	char fill_60[38];
	char e_61[12];
	char fill_62[40];
	char e_63[98];
	char fill_64[6];
	char e_65[36];
	char fill_66[16];
	char e_67[22];
	char fill_68[30];
	char e_69[32];
	char fill_70[20];
	char e_71[34];
	char fill_72[18];
	char e_73[6];
	char fill_74[46];
	char e_75[16];
	char fill_76[36];
	char e_77[16];
	char fill_78[36];
	char e_79[16];
	char fill_80[36];
	char e_81[18];
	char fill_82[34];
	char e_83[12];
	char fill_84[40];
	char e_85[12];
	char fill_86[40];
	char e_87[16];
	char fill_88[36];
	char e_89[12];
	char fill_90[40];
	char e_91[12];
	char fill_92[40];
	char e_93[12];
	char fill_94[40];
	char e_95[12];
	char fill_96[40];
	char e_97[10];
	char fill_98[42];
	char e_99[10];
	char fill_100[42];
	char e_101[14];
	char fill_102[38];
	char e_103[16];
	char fill_104[36];
	char e_105[16];
	char fill_106[36];
	char e_107[24];
	char fill_108[28];
	char e_109[10];
	char fill_110[42];
	char e_111[22];
	char fill_112[30];
	char e_113[10];
	char fill_114[42];
	char e_115[14];
	char fill_116[38];
	char e_117[14];
	char fill_118[38];
	char e_119[14];
	char fill_120[38];
	char e_121[16];
	char fill_122[36];
	char e_123[12];
	char fill_124[40];
	char e_125[20];
	char fill_126[32];
	char e_127[18];
	char fill_128[34];
	char e_129[12];
	char fill_130[40];
	char e_131[16];
	char fill_132[36];
	char e_133[10];
	char fill_134[42];
	char e_135[10];
	char fill_136[42];
	char e_137[14];
	char fill_138[38];
	char e_139[16];
	char fill_140[36];
	char e_141[18];
	char fill_142[34];
	char e_143[20];
	char fill_144[32];
	char e_145[12];
	char fill_146[40];
	char e_147[20];
	char fill_148[32];
	char e_149[10];
	char fill_150[42];
	char e_151[18];
	char fill_152[34];
	char e_153[8];
	char fill_154[44];
	char e_155[14];
	char fill_156[38];
	char e_157[12];
	char fill_158[40];
	char e_159[14];
	char fill_160[38];
	char e_161[20];
	char fill_162[32];
	char e_163[14];
	char fill_164[38];
	char e_165[26];
	char fill_166[26];
	char e_167[6];
	char fill_168[46];
	char e_169[6];
	char fill_170[46];
	char e_171[18];
	char fill_172[34];
	char e_173[12];
	char fill_174[40];
	char e_175[10];
	char fill_176[42];
	char e_177[10];
	char fill_178[42];
	} equiv_325 = { "A C C E P T   ", {0}, "A S C E N T   ", {0}, "A S S"
		" I G N   ", {0}, "B A C K S P A C E   ( ", {0}, "B L O C K  "
		" D A T A   ", {0}, "B U F F E R   I N   ", {0}, "B U F F E R"
		"   O U T   ", {0}, "C A L L   ", {0}, "C H A R A C T E R   ", 
		{0}, "C O M M O N   ", {0}, "C O M P L E X   ", {0}, "C O N "
		"T I N U E   ", {0}, "D A T A   ", {0}, "D E C O D E   ( ", {0}
		, "D I M E N S I O N   ", {0}, "D O U B L E   P R E C I S I "
		"O N   ", {0}, "D O U B L E   P R E C I S I O N   ", {0}, 
		"E N C O D E   ( ", {0}, "E N D   F I L E   ( ", {0}, "E N D"
		"   I F ", {0}, "E N D   F I L E   ", {0}, "E N T R Y   ", {0},
		 "E Q U I V A L E N C E   ", {0}, "E X T E R N A L ", {0}, 
		"F I N I S   ", {0}, "F O R M A T   ( ", {0}, "F O R T R A N "
		, {0}, "I F   ( U N I T ", {0}, "F U N C T I O N   ", {0}, 
		"G O   T O   ( ", {0}, "G O   T O   ", {0}, "I F   ( A C C U"
		" M U L A T O R   O V E R F L O W )   I F   ( Q U O T I E N T"
		"   O V E R F L O W )   ", {0}, "I F   ( D I V I D E   C H E "
		"C K )   ", {0}, "I F   ( E N D F I L E ", {0}, "I F   ( S E "
		"N S E   L I G H T   ", {0}, "I F   ( S E N S E   S W I T C H"
		"   ", {0}, "I F   ", {0}, "I N T E G E R   ", {0}, "L O G I "
		"C A L   ", {0}, "M A C H I N E   ", {0}, "N A M E L I S T   ",
		 {0}, "P A U S E   ", {0}, "P R I N T   ", {0}, "P R O G R A"
		" M   ", {0}, "P U N C H   ", {0}, "R E A D   ( ", {0}, "R E "
		"A D   ( ", {0}, "R E A D   ( ", {0}, "R E A D   ", {0}, "R E"
		" A L   ", {0}, "R E T U R N   ", {0}, "R E W I N D   ( ", {0},
		 "S E G M E N T   ", {0}, "S E N S E   L I G H T   ", {0}, 
		"S T O P   ", {0}, "S U B R O U T I N E   ", {0}, "T Y P E   "
		, {0}, "W R I T E   ( ", {0}, "W R I T E   ( ", {0}, "W R I "
		"T E   ( ", {0}, "O V E R L A Y   ", {0}, "I D E N T   ", {0}, 
		"F R E Q U E N C Y   ", {0}, "I M P L I C I T   ", {0}, "L E"
		" V E L   ", {0}, "E L S E   I F   ", {0}, "E L S E   ", {0}, 
		"T H E N   ", {0}, "C L O S E   ( ", {0}, "I N C L U D E   ", 
		{0}, "I N Q U I R E   ( ", {0}, "I N T R I N S I C   ", {0}, 
		"O P E N   ( ", {0}, "P A R A M E T E R   ", {0}, "S A V E   "
		, {0}, "B A C K S P A C E ", {0}, "E N D   ", {0}, "R E W I "
		"N D   ", {0}, "C L O S E   ", {0}, "E N D   D O   ", {0}, 
		"D O   W H I L E   ( ", {0}, "R E P E A T   ", {0}, "S E N S"
		" E   S W I T C H   ", {0}, "T O   ", {0}, "D O   ", {0}, 
		"C O N T I N U E   ", {0}, "C Y C L E   ", {0}, "E X I T   ", 
		{0}, "N O N E   " };

#define kwd ((char *)&equiv_325)

    static integer kskp[90] = { 6,6,6,10,9,8,9,4,9,6,7,8,4,7,9,15,6,7,8,5,7,5,
	    11,8,5,7,7,7,8,5,4,23,20,15,10,13,14,2,7,7,7,8,5,5,7,5,13,8,5,4,4,
	    6,7,7,10,4,10,4,15,9,6,7,5,9,8,5,4,4,4,6,7,8,9,5,9,4,9,3,6,5,5,8,
	    6,11,2,2,0,5,4,4 };
    static integer curcas = 1;
    static char lc[26*2] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" "abcdefghijklmnopqrs"
	    "tuvwxyz";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer i_indx(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__, j, k;
#define l15 ((integer *)&misc_1 + 23)
    static char ct[1], jt[2];
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
    static integer nskip;
#define jtype ((integer *)&misc_1 + 22)
    static integer newcas;
#define icolsv ((integer *)&misc_1 + 28)


/*     PRINTS FORTRAN KEYWORDS (KW > 0) */
/*     SETS CASE OF KEYWORDS (KW < 0) : -1 = UPPER CASE, -2 = LOWER-CASE */

/*     NOTE - SOME KEYWORDS ARE DUPLICATED BECAUSE OF FORTRAN STATEMENT */
/*      TRANSLATIONS AS FROM FORTRAN II TO FORTRAN-77 FORMS. */

/*     PARAMETER (NKWD=87) */

/*     KWL IS LENGTH OF STRING TO COPY TO BUFFER, KSKP IS NUMBER OF */
/*      ORIGINAL CHARACTERS TO SKIP. */
/*     MOST KEYS HAVE EXTRA SPACE AT END FOR AUTOMATIC SPACING. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*     ONLY NEED 3 CHARS OF THIS. */
/*     READ INPUT TAPE TRANSLATES TO READ ( */
/*     DATA KWL(47),(KWD(I,47),I=1, 16)/16 , 'R','E','A','D',' ','I','N' */
/*    1,'P','U','T',' ','T','A','P','E',' '/ */
/*     DATA KWL(48),(KWD(I,48),I=1, 10)/10 , 'R','E','A','D',' ','T','A' */
/*    1,'P','E',' '/ */
/*     DATA KWL(59),(KWD(I,59),I=1, 18)/18 , 'W','R','I','T','E',' ','O' */
/*    1,'U','T','P','U','T',' ','T','A','P','E',' '/ */
/*     DATA KWL(60),(KWD(I,60),I=1, 11)/11 , 'W','R','I','T','E',' ','T' */
/*    1,'A','P','E',' '/ */


/*     CURCAS = CURRENT CASE: 1 = UPPER, 2 = LOWER */

/*     NEGATIVE VALUES MEAN RESET CASE OF KEYWORDS. */
    if (*kw <= 0) {
	newcas = abs(*kw);
	if (newcas != curcas && newcas > 0 && newcas <= 2) {
/*          CHANGE CASE OF KEYWORD TABLE. */
	    for (j = 1; j <= 90; ++j) {
		i__1 = kwl[j - 1];
		for (i__ = 1; i__ <= i__1; ++i__) {

/*     FIND POSITION OF CHARACTER IN CURRENT-CASE ALPHABET */
		    *(unsigned char *)ct = *(unsigned char *)&kwd[(i__ + j * 
			    26 - 27) * 2];
		    k = i_indx(lc + (curcas - 1) * 26, ct, (ftnlen)26, (
			    ftnlen)1);

/*     IF FOUND, CHANGE TO NEW-CASE EQUIVALENT, OTHERWISE IGNORE. */
		    if (k > 0) {
			s_copy(kwd + (i__ + j * 26 - 27 << 1), lc + ((newcas 
				- 1) * 26 + (k - 1)), (ftnlen)2, (ftnlen)1);
		    }
/* L10: */
		}
/* L20: */
	    }
	    curcas = newcas;
	}
	return 0;
    }

/*     WRITE A KEYWORD AND SKIP THE ORIGINAL TEXT */


/*     COPY THE KEYWORD TO IOUT */
    i__1 = kwl[*kw - 1];
    for (i__ = 1; i__ <= i__1; ++i__) {
	++misc_1.icol;
	s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), kwd + (i__ + *kw * 26 
		- 27 << 1), (ftnlen)2, (ftnlen)2);
/* L25: */
    }

/*     SKIP NSKIP CHARS OF ORIGINAL TEXT. */
    nskip = kskp[*kw - 1];
    if (nskip > 0) {
L30:
	s_copy(jt, miscal_1.jint + (misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)
		2);
	if (s_cmp(jt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0) {
	    --nskip;
	    if (nskip == 0) {
		++misc_1.jcol;
		s_copy(miscal_1.lcpy, jt, (ftnlen)2, (ftnlen)2);
		return 0;
	    }
	    if (s_cmp(jt, alpha_1.kerm, (ftnlen)2, (ftnlen)2) == 0) {
		s_copy(miscal_1.lcpy, alpha_1.kerm, (ftnlen)2, (ftnlen)2);
		--misc_1.icol;
		misc_1.meof = 0;
		return 0;
	    }
	}
	++misc_1.jcol;
	goto L30;
    }
    return 0;
} /* kwdwrt_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15
#undef kwd


/* Subroutine */ int movstr_(integer *j)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)


/*     ADDS 1 BYTE TO STRING BY SHIFTING UNPROCESSED CHARS RIGHT. */
/*     USED BY HOLSCN WHEN REPLICATING APOSTROPHES */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    i__1 = *j;
    for (i__ = misc_1.jmax; i__ >= i__1; --i__) {
	s_copy(miscal_1.jint + (i__ << 1), miscal_1.jint + (i__ - 1 << 1), (
		ftnlen)2, (ftnlen)2);
/* L10: */
    }
    ++misc_1.jmax;
    s_copy(miscal_1.jint + (misc_1.jmax << 1), alpha_1.kerm, (ftnlen)2, (
	    ftnlen)2);
    ++(*j);
    ++misc_1.jcol;
    return 0;
} /* movstr_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int nopro_(void)
{
    /* Format strings */
    static char fmt_5[] = "(\002 Rewinding scratch files - subroutine Nopr"
	    "o\002)";

    /* System generated locals */
    integer i__1;
    alist al__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), e_wsfe(void), f_rew(alist *), s_cmp(char *, 
	    char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__, j, k;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int wrbin_(integer *, integer *, char *, char *, 
	    ftnlen, ftnlen), diagno_(integer *), reader_(void);
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___345 = { 0, 0, 0, fmt_5, 0 };



/*     THIS SUBROUTINE EXECUTES A HIGH-SPEED SEARCH FOR AN END STATEMENT. */
/*     IF MP2 IS ON, CARD IMAGES ARE WRITTEN ON TAPE 1 FOR USE BY PASS2. */
/*     NO INTERNAL PROCESSING IS DONE ON THE STATEMENTS. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*     SET INITIAL VALUES. */

/*  FORTRAN LOGICAL UNITS */
    if (misc_1.mdeb != 0) {
	io___345.ciunit = lunits_1.stderr;
	s_wsfe(&io___345);
	e_wsfe();
    }
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil1;
    f_rew(&al__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil2;
    f_rew(&al__1);
    misc_1.nrt2 = 0;
    misc_1.ndef = 0;
    *klass = 1;

/*     ITYPE=0 */
    *l15 = 0;
    if (misc_1.mp2 != 0) {

/*     WRITE OUT STATEMENT CURRENTLY IN JINT. */

	*imax = misc_1.jmax;
	*klass = 2;
	wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, miscal_1.jint, 
		(ftnlen)2, (ftnlen)2);
	misc_1.nrt1 = 1;
	*klass = 3;
	if (misc_1.jmax > 72) {
	    diagno_(&c__28);
	}
    }
    goto L20;

/*     READ AND COPY CARD IMAGES BY WAY OF KBUFF. */

L10:
    reader_();
L20:
    ++misc_1.nrec;

/*     LOOK FOR LAST NON-BLANK CHARACTER ON CARD. */

    i__ = 72;
L30:
    if (s_cmp(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
	    ftnlen)2) == 0) {
	--i__;
	if (i__ > 7) {
	    goto L30;
	}
    }
    *imax = i__;

/*     LOOK FOR END STATEMENT IN INPUT BUFFER KBUFF */

    j = 3;
    i__1 = *imax;
    for (i__ = 7; i__ <= i__1; ++i__) {
	k = i__;
	if (s_cmp(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2) != 0) {
	    if (s_cmp(miscal_1.kbuff + (i__ - 1 << 1), miscal_1.kend + (j - 1 
		    << 1), (ftnlen)2, (ftnlen)2) != 0) {
		goto L50;
	    }
	    --j;
	    if (j == 0) {
/*     FOUND AN END CARD IF NEXT CHAR IS BLANK. */
		if (s_cmp(miscal_1.kbuff + (k << 1), alpha_1.kbl, (ftnlen)2, (
			ftnlen)2) == 0) {
		    *klass = 8;
		}
		goto L50;
	    }
	}
/* L40: */
    }


/*     WRITE OUT CARD IMAGE FOR PASS2. */

L50:
    if (misc_1.mp2 != 0) {
	wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, miscal_1.kbuff,
		 (ftnlen)2, (ftnlen)2);
	++misc_1.nrt1;
    }

/*     GET NEXT RECORD UNLESS END CARD OR EOF */
    if (misc_1.iquit != 1 && *klass != 8) {
	goto L10;
    }

/*     CLOSE FILE */
    if (misc_1.mp2 != 0) {
	al__1.aerr = 0;
	al__1.aunit = lunits_1.scfil1;
	f_rew(&al__1);
    }

/*     LOAD BUFFER, KBUFF, BEFORE EXITING. */

    if (misc_1.iquit == 0) {
	reader_();
    }
    return 0;
} /* nopro_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int page_(integer *n)
{
    /* Initialized data */

    static integer maxlin = 56;

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)


/*     THIS SUBROUTINE DOES THE GENERAL PAGE COUNTING FOR TIDY WHILE */
/*     LIMITING THE OUTPUT TO MAXLIN LINES PER PAGE. */

/*          N>0 -- I WILL WRITE N LINES.  START A NEW PAGE IF NECESSARY. */
/*          N=0 -- START A NEW PAGE. */
/*          N<0 -- START A NEW PAGE IF .LT. -N LINES ARE LEFT. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */

    if (*n < 0) {
/*                            CONDITIONAL EJECT (NO LINES WRITTEN) */
	if (misc_1.line - *n <= maxlin) {
	    return 0;
	}
    } else if (*n > 0) {
	misc_1.line += *n;
	if (misc_1.line <= maxlin) {
	    return 0;
	}
    }
/*                            MAKE NEW PAGE */
    if (misc_1.line != 0) {
	misc_1.line = 0;
	if (*n > 0) {
	    misc_1.line = *n;
	}
	++misc_1.npage;
	++misc_1.mpage;
/*          WRITE (OUTFIL,10) NROUT,IPASS,MPAGE,NPAGE,JOB */
    }
    return 0;


/* 10   FORMAT (/' ',6X,'* T I D Y *          ROUTINE',I4,4X,'PASS',I2,2X, */
/*    1'PAGE',I3,21X,'PAGE',I4/7X,80A1/1X) */
} /* page_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int pass1_(void)
{
    /* Format strings */
    static char fmt_1420[] = "(\002 JTYPE =\002,i3,\002 IS ILLEGAL.  I AM CO"
	    "NFUSED AND CANNOT GO ON.\002)";
    static char fmt_1410[] = "(13x,\002***\002,10i6,\002***\002)";

    /* System generated locals */
    integer i__1, i__2;
    char ch__1[2];
    alist al__1;

    /* Builtin functions */
    integer f_rew(alist *);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen), i_indx(char *, char *, 
	    ftnlen, ftnlen), s_wsfe(cilist *), do_fio(integer *, char *, 
	    ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__, j;
#define l15 ((integer *)&misc_1 + 23)
    static integer nf, kj, jj, ip;
    static char ich[2];
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    static char jnt[2];
    static integer jrt;
    extern /* Subroutine */ int page_(integer *);
    static integer jtmp[8];
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static integer nlps;
    extern /* Subroutine */ int copy_(integer *);
    static integer merr, jret, jcold, kcndo[1500], kcndp, ncoma;
    extern /* Subroutine */ int rdbin_(integer *, integer *, char *, char *, 
	    ftnlen, ftnlen);
    static integer ktdcl, jgoof;
    extern /* Subroutine */ int skard_(void);
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    static integer nfort;
    extern /* Subroutine */ int nopro_(void);
    static integer jclmx;
    extern /* Subroutine */ int wrbin_(integer *, integer *, char *, char *, 
	    ftnlen, ftnlen);
    static integer itype, lngst, lngvr;
    extern /* Subroutine */ int rstat_(void), dlist_(integer *), adnum_(
	    integer *), jtyp19_(integer *, integer *), jtyp31_(integer *), 
	    jtyp33_(integer *, integer *);
    static integer mpass1;
    extern /* Subroutine */ int header_(void);
    extern logical bakscn_(char *, char *, ftnlen, ftnlen);
    extern /* Subroutine */ int diagno_(integer *);
    static integer nbcold, kenddo, jrtcod;
    extern /* Subroutine */ int kwscan_(integer *, integer *), holscn_(
	    integer *, integer *, integer *);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int contrl_(void);
    extern /* Character */ VOID kupper_(char *, ftnlen, char *, ftnlen);
    extern /* Subroutine */ int kwdwrt_(integer *);
    static char prvcpy[2];

    /* Fortran I/O blocks */
    static cilist io___388 = { 0, 0, 0, fmt_1420, 0 };
    static cilist io___395 = { 0, 0, 0, fmt_1410, 0 };



/*     THIS ROUTINE COLLECTS STATEMENT NUMBERS, MAKES DIAGNOSTIC COMMENTS */
/*     AND SETS UP THE FORTRAN STATEMENTS IN A FORM SUITABLE FOR PASS2. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*      CHARACTER*2 JNT,JT,ICH,KUPPER,PRVCPY,KCTRAN */
/*  FORTRAN LOGICAL UNITS */

/*     A    B    C    D    E    F    G    H    I    J    K    L    M */
/*     1    2    3    4    5    6    7    8    9    10   11   12   13 */

/*     N    O    P    Q    R    S    T    U    V    W    X    Y    Z */
/*     14   15   16   17   18   19   20   21   22   23   24   25   26 */

/*     KSPK (SPECIAL CHARACTERS) --- */
/*     =    ,    (    /    )    +    -    *    .    $    -    '    & NONE */
/*     1    2    3    4    5    6    7    8    9    10   11   12   13  14 */


/*     SET UP INITIAL CONDITIONS. */
/*     REWIND TAPE FILES 1 AND 2. */

L10:
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil1;
    f_rew(&al__1);
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil2;
    f_rew(&al__1);
    for (i__ = 1; i__ <= 20; ++i__) {
	misc_1.ldos[i__ - 1] = 0;
/* L20: */
    }
    *imax = 2712;
    misc_1.ipass = 1;
    misc_1.icol = 0;
    misc_1.kount = 0;
    misc_1.mp2 = 1;
    misc_1.nblc = 2;
    misc_1.mpun = misc_1.kpun;
    misc_1.mprin = misc_1.kprin;
    ++misc_1.nrout;
    misc_1.nrt1 = 0;
    misc_1.nrt2 = 0;
    misc_1.mildo = 0;
    misc_1.mlgc = -1;
    misc_1.mskp = 0;
    misc_1.mpage = 0;
    *mtran = 0;
    misc_1.ndef = 0;
    misc_1.ndos = 0;
    nfort = 0;
    misc_1.nrec = 0;
    misc_1.nref = 0;
    misc_1.l25 = 0;
    misc_1.ntran = 0;
    misc_1.nxeq = 0;
    ps1sub_1.nifblk = 0;
    kenddo = 100000;
    kcndp = 0;
    goto L50;

/*                  ILLEGAL FIRST CHARACTER. */
L30:
    jgoof = 9;
/*                  WRITE DIAGNOSTIC */
L40:
    diagno_(&jgoof);
/*                  GET NEW CARD. */
/*     (UNLESS EOF ALREADY) */
L50:
    if (misc_1.iquit != 0) {
	goto L850;
    }
    skard_();
    *nxrf = 1;
    if (*imax < misc_1.icol) {
	*imax = misc_1.icol;
    }
    i__1 = *imax;
    for (i__ = 1; i__ <= i__1; ++i__) {
	s_copy(miscal_1.iout + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2);
/* L60: */
    }
    *imax = 0;
/* new test */
/*     IF (JINT(1).EQ.KSPK(15)) GO TO 130 */

/*     LOOK FOR * IN COLUMN 1 */

    if (s_cmp(miscal_1.jint, alpha_1.kspk + 14, (ftnlen)2, (ftnlen)2) == 0) {
	contrl_();
	if (misc_1.istar < 0) {
/*                  CONTROL CARD FOUND AND EXECUTED. */
	    if (misc_1.mstop != 0) {
/*                            *STOP CARD FOUND. QUIT IF FIRST OF ROUTINE */
		if (nfort <= 0) {
		    misc_1.mp2 = 0;
		    return 0;
		} else {
/*                            OTHERWISE BUILD AN END CARD */
		    goto L830;
		}
	    }
	    if (misc_1.mskp == 0) {
		goto L50;
	    }
	    misc_1.mp2 = 0;
	    nopro_();
	    goto L10;
/*                  CONTROL CARD FOR DELAYED EXECUTION. SAVE FOR PASS 2. */
	} else if (misc_1.istar == 0) {
	    *klass = 0;
	    goto L140;
	} else {
/*                  * IN COL 1. NOT A CONTROL CARD.  PUT OUT LITERALLY */
/*                  UNLESS * IN COL 2. ALSO. */
	    if (s_cmp(miscal_1.jint + 2, alpha_1.kspk + 14, (ftnlen)2, (
		    ftnlen)2) == 0) {
		goto L50;
	    }
	    if (misc_1.mndoo == 1 && misc_1.kcmctl == 0) {
		s_copy(miscal_1.jint, alpha_1.kspk + 28, (ftnlen)2, (ftnlen)2)
			;
	    }
	    if (misc_1.mndoo == 1 && misc_1.kcmctl == 1) {
		s_copy(miscal_1.jint, alpha_1.kcmchr, (ftnlen)2, (ftnlen)2);
	    }
	    goto L130;
	}
    }

/*     *STOP COMMAND EXIT. */

/*     NO * IN COLUMN 1, LOOK FOR C, D, I, F, ., OR $. (UPPER CASE) */


    if (s_cmp(miscal_1.jint, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0) {
	goto L160;
    }
    kupper_(ch__1, (ftnlen)2, miscal_1.jint, (ftnlen)2);
    s_copy(jnt, ch__1, (ftnlen)2, (ftnlen)2);

/*     COMMENT CARD */
/*      IF (JNT.EQ.KABC(3)) THEN */
/* new test */
    if (s_cmp(jnt, alpha_1.kabc + 4, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(jnt, 
	    alpha_1.kspk + 28, (ftnlen)2, (ftnlen)2) == 0) {
	if (misc_1.mcom == 0) {
	    goto L50;
	}
/*          IF (MCASE.EQ.0) JINT(1)=KCTRAN(JINT(1)) */
/*          IF (MNDOO.eq.1) JINT(1)=KSPK(15) */
	if (misc_1.mndoo == 1 && misc_1.kcmctl == 0) {
	    s_copy(miscal_1.jint, alpha_1.kspk + 28, (ftnlen)2, (ftnlen)2);
	}
	if (misc_1.mndoo == 1 && misc_1.kcmctl == 1) {
	    s_copy(miscal_1.jint, alpha_1.kcmchr, (ftnlen)2, (ftnlen)2);
	}

/*     SHIFTED COMMENTS OPTION - SHIFT COMMENTS TO BEGIN IN COLUMN MCOM */
/*      (UNLESS * IN FIELD) */
	if (misc_1.mcom > 0) {
/* Computing MIN */
	    i__1 = misc_1.jmax, i__2 = misc_1.mcom - 1;
	    jclmx = min(i__1,i__2);
	    i__1 = jclmx;
	    for (misc_1.jcol = 2; misc_1.jcol <= i__1; ++misc_1.jcol) {
		if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kbl,
			 (ftnlen)2, (ftnlen)2) != 0) {
		    if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), 
			    alpha_1.kspk + 14, (ftnlen)2, (ftnlen)2) == 0) {
			goto L120;
		    }

/*                         SHIFT CARD TO RIGHT */

		    misc_1.icol = misc_1.mcom;
		    i__2 = misc_1.jmax;
		    for (i__ = misc_1.jcol; i__ <= i__2; ++i__) {
			++misc_1.icol;
			s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), 
				miscal_1.jint + (i__ - 1 << 1), (ftnlen)2, (
				ftnlen)2);
/* L70: */
		    }
		    s_copy(miscal_1.iout, miscal_1.jint, (ftnlen)2, (ftnlen)2)
			    ;
		    if (misc_1.icol > 72) {
			misc_1.icol = 72;
		    }
		    *imax = misc_1.icol;
		    i__2 = jclmx;
		    for (i__ = misc_1.jcol; i__ <= i__2; ++i__) {
			s_copy(miscal_1.iout + (i__ - 1 << 1), alpha_1.kbl, (
				ftnlen)2, (ftnlen)2);
/* L80: */
		    }
		    *klass = 1;
		    *jtype = 0;
		    *l15 = 0;
		    misc_1.nblc = 0;
/*     WRITE THE PROCESSED RECORD.  RAW COMMENTS USE INPUT INSTEAD. */
		    goto L510;
		}
/* L90: */
	    }
	}

/*     LOOK FOR BLANK COMMENT */

	i__1 = misc_1.jmax;
	for (misc_1.jcol = 2; misc_1.jcol <= i__1; ++misc_1.jcol) {
	    if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kbl, (
		    ftnlen)2, (ftnlen)2) != 0) {
		goto L120;
	    }
/* L100: */
	}

/*     BLANK COMMENT. TEST IF TWO PREVIOUS CARDS WERE BLANK */

	++misc_1.nblc;
	if (misc_1.nblc > 2) {
	    goto L50;
	}
	s_copy(miscal_1.iout, miscal_1.jint, (ftnlen)2, (ftnlen)2);
	misc_1.jmax = 7;
	goto L130;
    }

/*     A BLANK LINE PRESERVED AS A COMMENT WITH NON-PRINTING FIRST CHAR */
/*      (SET IN SUBROUTINE READER IF *NOSTRIP OPTION TURNED ON) */
    if (s_cmp(miscal_1.jint, alpha_1.kblcmt, (ftnlen)2, (ftnlen)2) == 0) {
	goto L120;
    }

    if (s_cmp(jnt, alpha_1.kabc + 6, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(jnt, 
	    alpha_1.kabc + 16, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(jnt, 
	    alpha_1.kabc + 10, (ftnlen)2, (ftnlen)2) == 0) {
	diagno_(&c__8);
	goto L50;
    }

/*     LOOK FOR ANY SPECIAL CHARACTER IN COLUMN 1 */
    for (i__ = 1; i__ <= 14; ++i__) {
	if (s_cmp(jnt, alpha_1.kspk + (i__ - 1 << 1), (ftnlen)2, (ftnlen)2) ==
		 0) {

/*     SPECIAL CHAR IN COL 1.  GIVE MSG AND TREAT AS COMMENT */

	    diagno_(&c__30);
	    goto L130;
	}
/* L110: */
    }
    goto L160;

/*     NON-BLANK COMMENT. */

L120:
    misc_1.nblc = 0;
    if (misc_1.jmax > 72 && misc_1.mser != 0) {
	misc_1.jmax = 72;
    }

/*     COMMENT CARD.  DO WE SAVE THEM... */
L130:
    *klass = 1;
L140:
    *jtype = 0;

/*     WRITE STATEMENT IMAGE ON TAPE 1 FOR PASS 2. */

L150:
    *l15 = 0;
    *imax = misc_1.jmax;
    wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, miscal_1.jint, (
	    ftnlen)2, (ftnlen)2);
    ++misc_1.nrt1;
    goto L50;

/*               =============================================== */
/*               *                                             * */
/*               *      START PROCESSING OF FORTRAN CARDS      * */
/*               *                                             * */
/*               =============================================== */

L160:
    if (misc_1.jmax < 8) {
	goto L40;
    }
    ++nfort;
/*     CLASSIFY STATEMENT, THEN CHECK AND CHANGE HOLLERITH FIELDS */
/*       (DO UNCLASSIFIED (REPLACEMENT, ETC) STATEMENTS, AND ALSO */
/*       THOSE IN WHICH STRINGS ARE LEGAL PARTS. */
    itype = 0;
    misc_1.jcol = 6;
    kwscan_(&itype, ps1sub_1.kstc);
    mpass1 = 1;
    i__ = ps1sub_1.kstc[4];
    *klass = ps1sub_1.kstc[1];
    misc_1.nins = ps1sub_1.kstc[0];
    holscn_(&itype, &i__, &lngst);
/*                  CLEAR FLAGS */
    misc_1.mlgc = -1;
    misc_1.ntran = *mtran;
    *mtran = 0;
    misc_1.meof = -1;
    jgoof = 1;
/*                  CLEAR STATEMENT AND REFERENCE NUMBERS */
    *l15 = 0;
    misc_1.l772 = 0.;
/*                  CLEAR BLANK COMMENT COUNTER */
    nbcold = misc_1.nblc;
    misc_1.nblc = 0;
/*                  SET POSITION COUNTERS. */
    misc_1.jcol = 7;
    if (misc_1.just == 0) {
/*                            NO COLUMN SHIFT */
	misc_1.icol = 6;
L170:
	if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kbl, (
		ftnlen)2, (ftnlen)2) != 0) {
	    goto L180;
	}
	++misc_1.jcol;
	++misc_1.icol;
	goto L170;
    }
/*                            COLUMN=SOMETHING */
    misc_1.icol = misc_1.just - 1;
/*                            ADD INDENT */
L180:
    misc_1.icol += misc_1.indent * (misc_1.ndos + ps1sub_1.nifblk);
    misc_1.icol = min(misc_1.icol,misc_1.mxrght);
/*                            REMEMBER THE STARTING COLUMN */
    *icolsv = misc_1.icol;
/*                  ANALYSIS OF LOGICAL IF RE-ENTERS HERE. */

/*                  SELECT NEXT COURSE ON BASIS OF FIRST SPECIAL CH. */
/*             =   ,   (   /  )  +  -  *   .  $  -  '  &  NONE */
L190:
    switch (misc_1.ifir) {
	case 1:  goto L240;
	case 2:  goto L350;
	case 3:  goto L200;
	case 4:  goto L400;
	case 5:  goto L30;
	case 6:  goto L30;
	case 7:  goto L30;
	case 8:  goto L400;
	case 9:  goto L30;
	case 10:  goto L30;
	case 11:  goto L30;
	case 12:  goto L400;
	case 13:  goto L30;
	case 14:  goto L400;
    }

/*                  FIRST IS (.  LOOK FOR ) */
L200:
    misc_1.npar = 0;
    i__1 = misc_1.jmax;
    for (nf = misc_1.lfir; nf <= i__1; ++nf) {
	if (s_cmp(miscal_1.jint + (nf - 1 << 1), alpha_1.kspk + 8, (ftnlen)2, 
		(ftnlen)2) == 0) {
	    --misc_1.npar;
	}
	if (s_cmp(miscal_1.jint + (nf - 1 << 1), alpha_1.kspk + 4, (ftnlen)2, 
		(ftnlen)2) == 0) {
	    ++misc_1.npar;
	}
	if (misc_1.npar == 0) {
	    goto L220;
	}
/* L210: */
    }
/*                            MISSING ) */
    jgoof = 2;
    goto L40;
/*                  THIS IS THE END OF THE FIRST STACK OF PARENS. */
/*                  SKIP BLANKS. */
/*                  FIRST LOOK FOR DO WHILE STATEMENT */
L220:
    if (*klass == 3) {
	goto L400;
    }
    kj = 82;
    kwscan_(&kj, ps1sub_1.kstc);
    if (kj == 82) {
	goto L1390;
    }

L230:
    ++nf;
    if (nf >= misc_1.jmax) {
	goto L400;
    }
    if (s_cmp(miscal_1.jint + (nf - 1 << 1), alpha_1.kbl, (ftnlen)2, (ftnlen)
	    2) == 0) {
	goto L230;
    }

/*                  CHARACTER REPLACEMENT STATEMENTS CAN HAVE 2 SETS OF */
/*                  PARENS BEFORE =. */
    if (s_cmp(miscal_1.jint + (nf - 1 << 1), alpha_1.kspk + 4, (ftnlen)2, (
	    ftnlen)2) == 0) {
	misc_1.lfir = nf;
	goto L200;
    }

    if (s_cmp(miscal_1.jint + (nf - 1 << 1), alpha_1.kspk, (ftnlen)2, (ftnlen)
	    2) == 0) {
/*           IF NEXT CHARACTER IS = PROCESS AS ARITHMETIC REPLACEMENT. */
	misc_1.lqual = nf;
	goto L320;
    }
/*           OTHERWISE, PROCESS AS FORTRAN STATEMENT */
    goto L400;

/*                  FIRST SPECIAL CH. IS =. */
L240:
    misc_1.lqual = misc_1.lfir;
/*                  IS IT A DO STATEMENT.  IF NOT, GO TO ARITHMETIC PROC. */
/*                  LOOK FOR -D- -O- */
    s_copy(ich, alpha_1.kabc + 6, (ftnlen)2, (ftnlen)2);
    i__1 = misc_1.jmax;
    for (j = 7; j <= i__1; ++j) {
	kupper_(ch__1, (ftnlen)2, miscal_1.jint + (j - 1 << 1), (ftnlen)2);
	s_copy(jnt, ch__1, (ftnlen)2, (ftnlen)2);
	if (s_cmp(jnt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0) {
	    goto L250;
	}
	if (s_cmp(jnt, ich, (ftnlen)2, (ftnlen)2) != 0) {
	    goto L320;
	}
	if (s_cmp(ich, alpha_1.kabc + 28, (ftnlen)2, (ftnlen)2) == 0) {
	    goto L260;
	}
	s_copy(ich, alpha_1.kabc + 28, (ftnlen)2, (ftnlen)2);
L250:
	;
    }
    goto L320;
/*                  FOUND -D- -O- NOW LOOK FOR COMMAS.  ALLOW EXACTLY 1 */
/*                  OR 2 COMMAS OUTSIDE OF PARENTHESES, 1 EQUALS. */
/*                  CERTAIN SPECIAL CHARACTERS NOT ALLOWED. */
L260:
    ncoma = 0;
    nlps = 0;
    jj = misc_1.lqual + 1;
    i__1 = misc_1.jmax;
    for (j = jj; j <= i__1; ++j) {
	s_copy(jnt, miscal_1.jint + (j - 1 << 1), (ftnlen)2, (ftnlen)2);
	for (i__ = 1; i__ <= 14; ++i__) {
	    if (s_cmp(jnt, alpha_1.kspk + (i__ - 1 << 1), (ftnlen)2, (ftnlen)
		    2) == 0) {
		switch (i__) {
		    case 1:  goto L320;
		    case 2:  goto L300;
		    case 3:  goto L280;
		    case 4:  goto L310;
		    case 5:  goto L290;
		    case 6:  goto L310;
		    case 7:  goto L310;
		    case 8:  goto L310;
		    case 9:  goto L310;
		    case 10:  goto L320;
		    case 11:  goto L310;
		    case 12:  goto L320;
		    case 13:  goto L320;
		    case 14:  goto L320;
		}
	    }
/* L270: */
	}
	goto L310;

/*     COUNT LEFT PARENTHESES */
L280:
	++nlps;
	goto L310;

/*     COUNT RIGHT PARENTHESES */
L290:
	--nlps;
	goto L310;

/*     A COMMA. DISREGARD IF INSIDE PARENTHESES, ABORT SCAN IF UNBALANCED */
L300:
	if (nlps < 0) {
	    goto L320;
	} else if (nlps == 0) {
	    if (ncoma > 1) {
		goto L320;
	    }
	    ++ncoma;
	}
L310:
	;
    }

    if (ncoma == 0) {
	goto L320;
    }
/*                  O.K.  THIS IS A DO STATEMENT. */
    *klass = 10;
    *jtype = 14;
    goto L430;

/*              ================================================= */
/*              *                                               * */
/*              *   START PROCESSING OF ARITHMETIC STATEMENT.   * */
/*              *                                               * */
/*              ================================================= */
L320:
    *klass = 6;
    *jtype = 0;

/*     IF IN ANSI MODE, CHECK LENGTH OF VARIABLE ON LEFT */
    if (misc_1.mansi == 0) {
	if (misc_1.ifir == 1 || misc_1.ifir == 3) {
	    lngvr = 0;
	    i__1 = misc_1.lfir - 1;
	    for (j = misc_1.jcol; j <= i__1; ++j) {
		if (s_cmp(miscal_1.jint + (j - 1 << 1), alpha_1.kbl, (ftnlen)
			2, (ftnlen)2) != 0) {
		    ++lngvr;
		}
/* L330: */
	    }
	    if (lngvr > 6) {
		diagno_(&c__41);
	    }
	}
    }

L340:
    copy_(&c_n1);
    if (misc_1.meof < 0) {
	goto L340;
    } else if (misc_1.meof > 0 || s_cmp(miscal_1.lcpy, alpha_1.kerm, (ftnlen)
	    2, (ftnlen)2) == 0) {
	if (misc_1.mlgc != 0) {
	    misc_1.jcol = 1;
	    rstat_();
	    *l15 = (integer) misc_1.l772;
	}
	goto L490;
    } else {
	++misc_1.icol;
	misc_1.meof = -1;
	goto L340;
    }


/*     DO STATEMENTS WITH COMMA BEFORE INDEX VARIABLE */
/*                  IS IT A DO STATEMENT.  IF NOT, GO TO ARITHMETIC PROC. */
/*                  LOOK FOR -D- -O- */
/*                  (UNLESS STATEMENT IS CLASSIFIED) */
L350:
    if (*klass == 0) {
	s_copy(ich, alpha_1.kabc + 6, (ftnlen)2, (ftnlen)2);
	i__1 = misc_1.jmax;
	for (j = misc_1.jcol; j <= i__1; ++j) {
	    kupper_(ch__1, (ftnlen)2, miscal_1.jint + (j - 1 << 1), (ftnlen)2)
		    ;
	    s_copy(jnt, ch__1, (ftnlen)2, (ftnlen)2);
	    if (s_cmp(jnt, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0) {
		goto L360;
	    }
	    if (s_cmp(jnt, ich, (ftnlen)2, (ftnlen)2) != 0) {
		goto L400;
	    }
	    if (s_cmp(ich, alpha_1.kabc + 28, (ftnlen)2, (ftnlen)2) == 0) {
		jcold = misc_1.jcol;
		misc_1.jcol = j + 1;
		goto L370;
	    }
	    s_copy(ich, alpha_1.kabc + 28, (ftnlen)2, (ftnlen)2);
L360:
	    ;
	}
	goto L400;

/*          CHECK FOR STATEMENT NUMBER, NEXT NON-BLANK SHOULD BE THE COMM */
L370:
	rstat_();
	if ((integer) misc_1.l772 != 0 && misc_1.lfir == misc_1.jcol) {
/*          NOW CHECK FOR VARIABLE FOLLOWED BY EQUAL SIGN.  IF FOUND, CHA */
/*           COMMA TO BLANK AND USE POSITION OF = AS LQUAL, PROCESS AS DO */
	    ++misc_1.jcol;
	    i__1 = misc_1.jmax;
	    for (j = misc_1.jcol; j <= i__1; ++j) {
		s_copy(jnt, miscal_1.jint + (j - 1 << 1), (ftnlen)2, (ftnlen)
			2);
		for (i__ = 1; i__ <= 13; ++i__) {
		    if (s_cmp(jnt, alpha_1.kspk + (i__ - 1 << 1), (ftnlen)2, (
			    ftnlen)2) == 0) {
			misc_1.jcol = jcold;
			if (i__ == 1) {
			    misc_1.ifir = i__;
			    s_copy(miscal_1.jint + (misc_1.lfir - 1 << 1), 
				    alpha_1.kbl, (ftnlen)2, (ftnlen)2);
			    misc_1.lfir = j;
			    misc_1.lqual = misc_1.lfir;
			    goto L260;
			}
			goto L400;
		    }
/* L380: */
		}
/* L390: */
	    }
	}
    }

/*              ======================================== */
/*              *                                      * */
/*              *     END OF ARITHMETIC PROCESSING     * */
/*              *  START FORTRAN STATEMENT PROCESSING  * */
/*              *                                      * */
/*              ======================================== */

/*                  CHECK EVERY LISTED STATEMENT TYPE. */
L400:
    if (mpass1 > 1) {
/*     MUST RE-CHECK REST OF IF-STATEMENTS */
	itype = 0;
	kwscan_(&itype, ps1sub_1.kstc);
	if (itype == 0) {
	    goto L480;
	}
    }
    misc_1.nins = ps1sub_1.kstc[0];
    ++mpass1;

/*                  FOUND IT. */
    if (itype != 0) {
	*klass = ps1sub_1.kstc[1];
	*jtype = ps1sub_1.kstc[2];
	if (misc_1.ifir != 12) {
/*     COMPLAIN IF NON-ANSI STATEMENT. */
	    if (misc_1.mansi == 0 && ps1sub_1.kstc[3] == 1) {
		diagno_(&c__34);
	    }
	    if (misc_1.mlgc != 0) {
		goto L410;
	    }
/*                            FOLLOWS LOGICAL IF OR IS FUNCTION DECL. */
	    if (*klass == 3 || *klass == 4 || *klass == 6 || *klass == 7 || *
		    klass == 11) {
		goto L450;
	    }
	    goto L40;
	} else {
/*        COMPLAIN IF FIRST SPECIAL CHAR ' AND NOT INCLUDE OR PRINT */
	    if (itype != 71 && itype != 43 && itype != 44) {
		goto L30;
	    }
	}
    } else {

/*                  NOT IN TABLE.  PASS IT WITHOUT PROCESSING. */
	diagno_(&c__30);
	*klass = 11;
	*jtype = 0;
    }

/*                  THIS IS A FORTRAN STATEMENT. */
/*                  SET IMAX IN CASE THIS STATEMENT IS PUT OUT DIRECTLY. */
L410:
    *imax = misc_1.jmax;
/*                  CHECK FOR EXEMPT STATEMENT. */
    if (*klass == 3) {
	for (j = 1; j <= 6; ++j) {
	    s_copy(miscal_1.jint + (j - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2);
/* L420: */
	}
	if (*mex == 0) {
	    goto L450;
	}
/*                  THIS IS A NON-EXECUTABLE (KLASS 3.) FORTRAN STATEMENT */
/*                  AND THE EXEMPT FLAG IS SET.  SO PUT IT OUT DIRECTLY. */
	goto L150;
    }

/*                  GET STATEMENT NUMBER UNLESS FOLLOWING LOGICAL IF. */
    if (misc_1.mlgc == 0) {
	goto L450;
    }
L430:
    for (i__ = 1; i__ <= 5; ++i__) {
	if (s_cmp(miscal_1.jint + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2) != 0) {
	    j = i_indx("0123456789", miscal_1.jint + (i__ - 1 << 1), (ftnlen)
		    10, (ftnlen)1);
	    if (j <= 0) {
		goto L450;
	    }
	    *l15 = *l15 * 10 + j - 1;
	}
/* L440: */
    }

/*        IF THIS IS A WEIRD CARD, ALLOW A TRANSFER TO IT */
L450:
    if (*klass == 11) {
	misc_1.ntran = 0;
    }

/*     GO TO INDIVIDUAL STATEMENT PROCESSING BY JTYPE. */

    i__ = *jtype + 1;
    switch (i__) {
	case 1:  goto L520;
	case 2:  goto L530;
	case 3:  goto L560;
	case 4:  goto L570;
	case 5:  goto L580;
	case 6:  goto L590;
	case 7:  goto L600;
	case 8:  goto L630;
	case 9:  goto L660;
	case 10:  goto L710;
	case 11:  goto L720;
	case 12:  goto L740;
	case 13:  goto L760;
	case 14:  goto L760;
	case 15:  goto L770;
	case 16:  goto L820;
	case 17:  goto L830;
	case 18:  goto L890;
	case 19:  goto L910;
	case 20:  goto L920;
	case 21:  goto L930;
	case 22:  goto L940;
	case 23:  goto L540;
	case 24:  goto L950;
	case 25:  goto L970;
	case 26:  goto L1020;
	case 27:  goto L1020;
	case 28:  goto L1020;
	case 29:  goto L1040;
	case 30:  goto L1070;
	case 31:  goto L1070;
	case 32:  goto L1090;
	case 33:  goto L1100;
	case 34:  goto L1110;
	case 35:  goto L1120;
	case 36:  goto L1130;
	case 37:  goto L1140;
	case 38:  goto L1140;
	case 39:  goto L1180;
	case 40:  goto L1220;
	case 41:  goto L1230;
	case 42:  goto L1240;
	case 43:  goto L1250;
	case 44:  goto L1080;
	case 45:  goto L1140;
	case 46:  goto L1140;
	case 47:  goto L1270;
	case 48:  goto L1350;
	case 49:  goto L1360;
	case 50:  goto L1370;
	case 51:  goto L1380;
	case 52:  goto L1390;
	case 53:  goto L460;
    }

/*     ================================================================== */
/*     *                                                                * */
/*     *  AT THIS POINT, COMMENTS AND ARITHMETIC STATEMENTS HAVE BEEN   * */
/*     *  PROCESSED.  THE STATEMENTS HAVE BEEN CLASSIFIED AS ITYPE AND  * */
/*     *  KLASS.  THE LAST SYMBOL USED IN SCANNING THE FORTRAN STATE-   * */
/*     *  MENT IS KST(NINS,ITYPE), AND WAS FOUND AT JINT(LAST).  THE    * */
/*     *  FIRST SPECIAL CHARACTER, IF ANY, IS KSPK(IFIR), LOCATED AT    * */
/*     *  JINT(LFIR).  IF A STATEMENT                                   * */
/*     *  NUMBER IS PERMITTED, IT IS IN L15.  IF NOT, L15=0.            * */
/*     *  JCOL IS ON THE CURRENT CHARACTER IN THE INPUT STRING (THE     * */
/*     *  FIRST, UNLESS FOLLOWING A LOGICAL IF).  ICOL IS ON THE MOST   * */
/*     *  RECENT CHARACTER TO BE PUT INTO THE OUTPUT STRING (E.G. 6.)   * */
/*     *                                                                * */
/*     ================================================================== */

/*                  ILLEGAL JTYPE */
L460:
    io___388.ciunit = lunits_1.outfil;
    s_wsfe(&io___388);
    do_fio(&c__1, (char *)&(*jtype), (ftnlen)sizeof(integer));
    e_wsfe();
    diagno_(&c__45);

/*                  COPY REST OF CARD. */
L470:
    ++misc_1.icol;
L480:
    copy_(&c__0);
    if (*klass < 4) {
	goto L500;
    }
/*                  DLIST HANDLES THE STATEMENT NUMBER. */
L490:
    dlist_(&merr);
    if (merr < 0) {
	goto L50;
    }
L500:
    *imax = misc_1.icol;
/*                  WRITE STATEMENT IMAGE ON TAPE1 FOR PASS 2. */
L510:
    wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, miscal_1.iout, (
	    ftnlen)2, (ftnlen)2);
    ++misc_1.nrt1;
    goto L50;

/*                  ***** JTYPE = 0 */
/*     UNRECOGNIZED FORTRAN CARD */
/*                  COPY IT, INCLUDING BLANKS */
L520:
    copy_(&c__0);
    goto L490;

/*                  ***** JTYPE = 1 */
/*     ASCENT,MACHINE. */
L530:
    i__ = 0;
    goto L550;

/*                  ***** JTYPE = 22 */
/*     IDENT */

L540:
    misc_1.mp2 = 1;
/*            (MUST BE THE FIRST CARD OF THIS PASS.) */
L550:
    if (nfort != 1) {
	diagno_(&c__14);
    }
    diagno_(&c__26);
    nopro_();
    header_();
    return 0;

/*                  ***** JTYPE = 2 */
/*     ASSIGN */

L560:
    kwdwrt_(&itype);
    rstat_();
    adnum_(&jret);
    if (jret == 1) {
	goto L50;
    }
    ++misc_1.icol;
    kwdwrt_(&c__85);
    if (misc_1.meof < 0) {
	goto L480;
    }
    goto L40;

/*                  ***** JTYPE = 3 */
/*     BACKSPACE, EXTERNAL, IMPLICIT, PAUSE. */

L570:
    kwdwrt_(&itype);
/*     FINISH AN IMPLICIT STATEMENT */
    if (itype == 65) {
	goto L400;
    }
    goto L470;

/*                  ***** JTYPE = 4 */
/*      BLOCK DATA */

L580:
    if (nfort != 1) {
	goto L40;
    }
    kwdwrt_(&itype);
    goto L480;

/*                  ***** JTYPE = 5 */
/*     BUFFER IN (I,P) (A,B) /// BUFFER OUT (I,P) (A,B) */

L590:
    kwdwrt_(&itype);
    copy_(&c_n1);
    ++misc_1.icol;
    copy_(&c_n1);
    if (misc_1.meof < 0 && misc_1.jcol > misc_1.jmax) {
	goto L490;
    }
    goto L40;

/*                  ***** JTYPE = 6 */
/*     CALL   (FUNCTION,SUBROUTINE) */

L600:
    jgoof = 10;
    kwdwrt_(&itype);
    if (misc_1.ifir != 3) {
	goto L480;
    }
    nlps = 0;
L610:
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) != 0) {
	if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) == 0)
		 {
	    --nlps;
	}
	if (misc_1.meof < 0) {
	    goto L610;
	}
	goto L40;
    } else {
	++nlps;
    }
    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), alpha_1.kbl2, (ftnlen)2, (
	    ftnlen)2);
    --misc_1.jcol;
L620:
    s_copy(prvcpy, miscal_1.lcpy, (ftnlen)2, (ftnlen)2);
    copy_(&c__1);
    if (misc_1.meof < 0) {
	if (s_cmp(miscal_1.lcpy, alpha_1.kalmrk, (ftnlen)2, (ftnlen)2) == 0) {
/*     ALTERNATE RETURNS MUST BE PRECEDED BY , OR ( */
	    if (s_cmp(prvcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) != 0 && 
		    s_cmp(prvcpy, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) != 
		    0) {
		goto L620;
	    }
/*                            ARGUMENT IS *STATEMENT NUMBER */
/*     TRANSLATE ALTERNATE RETURN CODE IF DESIRED. */
	    if (s_cmp(alpha_1.kaltrn, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0)
		     {
		s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), alpha_1.kaltrn,
			 (ftnlen)2, (ftnlen)2);
	    }
	    rstat_();

/*     NO NUMBER LEGAL ONLY FOR FUNCTIONS AND SUBROUTINES. */
	    if ((integer) misc_1.l772 == 0) {
		if (itype == 29 || itype == 57) {
		    goto L620;
		}
		goto L40;
	    }
	    adnum_(&jrt);
	    if (jrt == 1) {
		goto L50;
	    }
	}

/*     ADD A SPACE BETWEEN PARAMETERS OR ARGUMENTS. */
	if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) == 0)
		 {
	    ++nlps;
	} else if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)
		2) == 0) {
	    --nlps;
	} else if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)
		2) == 0 && nlps <= 2) {
	    ++misc_1.icol;
	}

	goto L620;
    }

    *imax = misc_1.icol;
    if (misc_1.npar == 0) {
	goto L490;
    }
    goto L40;

/*                  ***** JTYPE = 7 */
/*      COMMON */

L630:
    kwdwrt_(&itype);
/*          J COUNTS SLASHES */
    j = -2;
    if (misc_1.ifir != 4) {
	goto L480;
    }
L640:
    if (j == 0) {
	goto L470;
    }
    ++j;
L650:
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 6, (ftnlen)2, (ftnlen)2) == 0) {
	goto L640;
    }
    if (misc_1.meof < 0) {
	goto L650;
    }
    diagno_(&c__11);
    goto L510;

/*                  ***** JTYPE = 8 */
/*     CONTINUE */

L660:
    jgoof = 12;
    if (*l15 == 0) {
	goto L40;
    }
    if (misc_1.mlgc == 0) {
	i__1 = misc_1.icol;
	for (i__ = 7; i__ <= i__1; ++i__) {
	    s_copy(miscal_1.iout + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2);
/* L670: */
	}
	misc_1.icol = *icolsv;
	misc_1.mlgc = -1;
    }
    if (misc_1.mcont == 0) {
/*                            IS THIS A DO-LOOP TERMINATOR... */
	if (misc_1.ndos > 0) {
	    i__1 = misc_1.ndos;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		if (*l15 == misc_1.ldos[i__ - 1]) {
		    goto L700;
		}
/* L680: */
	    }
	}

/*                            CHECK IF TRANSFER TO IT BUT NOT DO-TERM. */
	i__1 = misc_1.nref;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (*l15 == _BLNK__1.lref[i__ - 1]) {
		goto L700;
	    }
/* L690: */
	}
/*                            COPY THE CARD */
	kwdwrt_(&itype);
/*                            PROCESS STATEMENT NUMBER */
	dlist_(&merr);
/*                            SET A FLAG */
	_BLNK__1.ldef[misc_1.ndef - 1] = -_BLNK__1.ldef[misc_1.ndef - 1];
	misc_1.l25 = *l15;
/*                            TAKE TRANSFER STATUS OF LAST CARD */
	*mtran = misc_1.ntran;
/*                            DONT SAVE STATEMENT FOR PASS2 */
	goto L50;
    }
/*                            THIS CONTINUE STATEMENT IS TO BE RETAINED */
L700:
    if (misc_1.ndos != 0) {
/*                            IT TERMINATES THIS DO-LOOP. INDENT */
/*                            ONE LESS LEVEL */
	if (*l15 == misc_1.ldos[misc_1.ndos - 1] && misc_1.mlgc != 0) {
	    misc_1.icol -= misc_1.indent;
	    *icolsv = misc_1.icol;
	}
    }
    kwdwrt_(&itype);
    goto L490;

/*                  ***** JTYPE = 9 */
/*     DATA */

L710:
    kwdwrt_(&itype);
    if (misc_1.ifir == 4) {
	if (s_cmp(miscal_1.jint + (misc_1.jmax - 1 << 1), alpha_1.kspk + 6, (
		ftnlen)2, (ftnlen)2) != 0 || misc_1.lfir >= misc_1.jmax) {
	    diagno_(&c__11);
	}
    }
    goto L480;

/*                  ***** JTYPE = 10 */
/*     DECODE (C,N,V) LIST  ///  ENCODE (C,N,V) LIST */

L720:
    jgoof = 23;
    kwdwrt_(&itype);
L730:
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) != 0) {
	if (misc_1.meof < 0) {
	    goto L730;
	}
	goto L40;
    }
    rstat_();
    if ((integer) misc_1.l772 > 0) {
	adnum_(&jrt);
	if (jrt == 1) {
	    goto L50;
	}
    }
    goto L1200;

/*                  ***** JTYPE = 11 */
/*     DIMENSION */

L740:
    jgoof = 13;
    kwdwrt_(&itype);
    misc_1.npar = -1;
    i__1 = misc_1.jmax;
    for (i__ = misc_1.jcol; i__ <= i__1; ++i__) {
	copy_(&c__1);
	if (misc_1.npar < 0) {
	    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) 
		    == 0) {
		++misc_1.npar;
	    }
	} else if (misc_1.npar == 0) {
	    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) 
		    == 0) {
		++misc_1.npar;
	    }
	} else {
	    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) 
		    != 0) {
		goto L750;
	    }
	    ++misc_1.icol;
	    misc_1.npar = -1;
	}
L750:
	;
    }
    if (misc_1.npar > 0) {
	goto L500;
    }
    goto L40;

/*                  ***** JTYPE = 12 */
/*     DOUBLE PRECISION */
/*                  ***** JTYPE = 13 */
/*     DOUBLE, (CONVERT TO DOUBLE PRECISION). */

L760:
    kwdwrt_(&itype);
    goto L400;

/*                  ***** JTYPE = 14 */
/*     DO STATEMENT */

L770:
    misc_1.mildo = 1;
    kwdwrt_(&c__86);
    rstat_();

/*     IF NO STATEMENT, GIVE IT IMPOSSIBLE (FROM CARDS) NUMBER */
/*     KCNDO IS STACK OF CURRENTLY-OPEN ENDDO LOOPS */
    if ((integer) misc_1.l772 == 0) {
/*          JUMP IF CONVERSION TO F-77 LOOP NOT DESIRED. */
	if (misc_1.mndoo != 0) {
	    goto L1400;
	}
	misc_1.l772 = (doublereal) kenddo;
	++kcndp;
	kcndo[kcndp - 1] = kenddo;
	++kenddo;
    }

/*     BE SURE IT DOESN'T REFERENCE BACKWARD IN PROGRAM. */
    if (misc_1.ndef > 0) {
	i__1 = misc_1.ndef;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if ((i__2 = _BLNK__1.ldef[i__ - 1], abs(i__2)) == (integer) 
		    misc_1.l772) {
		jgoof = 15;
		goto L40;
	    }
/* L780: */
	}
    }

/*     ADD STATEMENT NUMBER TO DO-LIST. */

    if (misc_1.ndos < 0) {
	diagno_(&c__44);
    }
    if (misc_1.ndos > 0) {
	if (misc_1.ldos[misc_1.ndos - 1] == (integer) misc_1.l772) {
	    goto L810;
	}
	if (misc_1.ndos > 1) {
	    i__1 = misc_1.ndos;
	    for (i__ = 2; i__ <= i__1; ++i__) {
		if (misc_1.ldos[i__ - 2] == (integer) misc_1.l772) {
		    jgoof = 15;
		    goto L40;
		}
/* L790: */
	    }
	}
    }

/*     ADD DO-LOOP TO OPEN LIST */
    if (misc_1.ndos == 20) {
	jgoof = 24;
	misc_1.mpun = 0;
	misc_1.mp2 = 0;
	goto L40;
    }
    ++misc_1.ndos;
    misc_1.ldos[misc_1.ndos - 1] = (integer) misc_1.l772;

    if (misc_1.nref > 0) {
	i__1 = misc_1.nref;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (_BLNK__1.lref[i__ - 1] == (integer) misc_1.l772) {
		diagno_(&c__27);
		goto L810;
	    }
/* L800: */
	}
    }

L810:
    adnum_(&jrt);
    if (jrt == 1) {
	goto L50;
    }
    goto L470;

/*     END DO-LOOP STATEMENT PROCESSING. */


/*                  ***** JTYPE = 15 */
/*     END FILE */

L820:
    if (misc_1.ifir != 14) {
	goto L30;
    }
    kwdwrt_(&itype);
    goto L480;

/*                  ***** JTYPE = 16 */
/*     END STATEMENT. */

/*                   IS THERE A STATEMENT NUMBER TO USE? */
L830:
    if (*l15 != 0 || misc_1.l25 != 0) {
/*                   YES. MAKE A CONTINUE CARD FOR IT TO FALL TO. */
	misc_1.icol = 7;
	kwdwrt_(&c__87);
	misc_1.mildo = 0;
	dlist_(&merr);
	if (merr >= 0) {
	    jtmp[0] = 4;
	    jtmp[1] = 8;
	    jtmp[2] = *l15;
	    jtmp[3] = 14;
	    jtmp[4] = *mtran;
	    jtmp[5] = *nxrf;
	    jtmp[6] = *mex;
	    jtmp[7] = *icolsv;
	    wrbin_(&lunits_1.scfil1, jtmp, miscal_1.jint + 10, miscal_1.iout, 
		    (ftnlen)2, (ftnlen)2);
	    ++misc_1.nrt1;
	}
	*l15 = 0;
    }
    if (ps1sub_1.nifblk > 0) {
	diagno_(&c__33);
    }
    if (misc_1.ndos != 0) {
	diagno_(&c__16);
	page_(&c__1);
	io___395.ciunit = lunits_1.outfil;
	s_wsfe(&io___395);
	i__1 = misc_1.ndos;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    do_fio(&c__1, (char *)&misc_1.ldos[i__ - 1], (ftnlen)sizeof(
		    integer));
	}
	e_wsfe();
    }

/*     IF STATEMENT IS NUMBERED AND REFERENCED */
    if (*l15 != 0 && misc_1.nref > 0) {
	i__1 = misc_1.nref;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (_BLNK__1.lref[i__ - 1] == *l15) {
		diagno_(&c__18);
/*                           GENERATE NEW STOP COMMAND. */
		kwdwrt_(&c__56);
		misc_1.mildo = -1;
		dlist_(&merr);
		if (merr < 0) {
		    goto L850;
		}
		jtmp[0] = 6;
		jtmp[1] = 55;
		jtmp[2] = *l15;
		jtmp[3] = 10;
		jtmp[4] = *mtran;
		jtmp[5] = *nxrf;
		jtmp[6] = *mex;
		jtmp[7] = *icolsv;
		wrbin_(&lunits_1.scfil1, jtmp, miscal_1.jint + 10, 
			miscal_1.iout, (ftnlen)2, (ftnlen)2);
		++misc_1.nrt1;
		goto L850;
	    }
/* L840: */
	}
    }

/*                       PROCESS FORMATS ON TAPE 2 */
L850:
    if (misc_1.nrt2 > 0) {
	al__1.aerr = 0;
	al__1.aunit = lunits_1.scfil2;
	f_rew(&al__1);
/*                                  INSERT BLANK COMMENT CARD. */
	if (misc_1.nblc == 0) {
	    s_copy(miscal_1.iout, alpha_1.kabc + 4, (ftnlen)2, (ftnlen)2);
/*              IF (MNDOO.eq.1) IOUT(1)=KSPK(15) */
	    if (misc_1.mndoo == 1 && misc_1.kcmctl == 0) {
		s_copy(miscal_1.iout, alpha_1.kspk + 28, (ftnlen)2, (ftnlen)2)
			;
	    }
	    if (misc_1.mndoo == 1 && misc_1.kcmctl == 1) {
		s_copy(miscal_1.iout, alpha_1.kcmchr, (ftnlen)2, (ftnlen)2);
	    }
	    for (i__ = 2; i__ <= 7; ++i__) {
		s_copy(miscal_1.iout + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2,
			 (ftnlen)2);
/* L860: */
	    }
	    *klass = 1;
	    itype = 0;
	    *l15 = 0;
	    *imax = 7;
	    wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, 
		    miscal_1.iout, (ftnlen)2, (ftnlen)2);
	    ++misc_1.nrt1;
	}
/*                                TRANSFER FORMAT STATEMENTS */
	i__1 = misc_1.nrt2;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    rdbin_(&lunits_1.scfil2, misc_1.kili, miscal_1.serial, 
		    miscal_1.iout, (ftnlen)2, (ftnlen)2);
	    *icolsv = 6;
	    misc_1.nrec = *jtype;
	    misc_1.mildo = 1;
	    dlist_(&merr);
	    if (merr >= 0) {
		wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, 
			miscal_1.iout, (ftnlen)2, (ftnlen)2);
		++misc_1.nrt1;
	    }
/* L870: */
	}
	al__1.aerr = 0;
	al__1.aunit = lunits_1.scfil2;
	f_rew(&al__1);
    }
/*                                      MAKE END STATEMENT */
    if (misc_1.nfend == 0 && nfort > 0) {
	for (i__ = 1; i__ <= 6; ++i__) {
	    s_copy(miscal_1.iout + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2);
/* L880: */
	}
	kwdwrt_(&c__78);
	*klass = 8;
	itype = 20;
	*l15 = 0;
	*imax = 9;
	wrbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, miscal_1.iout, 
		(ftnlen)2, (ftnlen)2);
	++misc_1.nrt1;
    }
    al__1.aerr = 0;
    al__1.aunit = lunits_1.scfil1;
    f_rew(&al__1);
    return 0;

/*                 ================================== */
/*                 *   PASS1 NORMALLY EXITS HERE.   * */
/*                 ================================== */


/*                  ***** JTYPE = 17 */
/*     EQUIVALENCE */

L890:
    kwdwrt_(&itype);
L900:
    copy_(&c_n1);
    if (misc_1.meof >= 0) {
	goto L500;
    }
    goto L900;

/*                  ***** JTYPE = 18 */
/*     FINIS. */

L910:
    misc_1.mstop = -1;
    return 0;

/*                  ***** JTYPE = 19 */
/*     FORMAT ( */

L920:
    jgoof = 17;
    jtyp19_(&jrtcod, &nbcold);
    switch (jrtcod) {
	case 1:  goto L40;
	case 2:  goto L50;
	case 3:  goto L480;
    }

/*                  ***** JTYPE = 20 */
/*     FORTRAN,ETC */

L930:
    kwdwrt_(&itype);
    *imax = misc_1.jmax;
    goto L510;

/*                  ***** JTYPE = 21 */
/*     FREQUENCY */

L940:
    jgoof = 8;
    goto L40;

/*                  ***** JTYPE = 23 */
/*     GO TO (***,***),N */

L950:
    jgoof = 19;
    kwdwrt_(&itype);
    misc_1.mildo = 1;
    *mtran = misc_1.mlgc;

/*     PROCESS --GO TO LIST--. */

L960:
    rstat_();
    if ((integer) misc_1.l772 == 0) {
	goto L40;
    }
    adnum_(&jrt);
    if (jrt == 1) {
	goto L50;
    }
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) == 0) {
	goto L960;
    }
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) != 0) {
	goto L40;
    }
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) != 0) {
	s_copy(miscal_1.iout + (misc_1.icol + 1 << 1), miscal_1.iout + (
		misc_1.icol - 1 << 1), (ftnlen)2, (ftnlen)2);
	s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), alpha_1.kspk + 2, (
		ftnlen)2, (ftnlen)2);
	misc_1.icol += 2;
    }
    goto L480;

/*                  ***** JTYPE = 24 */
/*     GO TO **** */

L970:
    jgoof = 19;
    misc_1.mildo = -1;
    kwdwrt_(&itype);
    rstat_();

/*     TEST REF STATEMENT FOR GO TO N OR GO TO N, (LIST) */

    if ((integer) misc_1.l772 == 0) {
	goto L990;
    }

/*     STATEMENT IS --GO TO 12345--. */

    if (*l15 == 0 && misc_1.l25 == 0) {
	goto L980;
    }
    if (misc_1.mlgc == 0) {
	goto L980;
    }
/*     LABELLED GOTO STATEMENT. */
    if (misc_1.mcont == 0) {
	dlist_(&merr);
	if (merr < 0) {
	    goto L40;
	}
/*          SET UP REFERENCE TRANSLATION */
	if (misc_1.ndef < 1500) {
	    ++misc_1.ndef;
	    _BLNK__1.ldef[misc_1.ndef - 1] = 0;
	    _BLNK__1.locdef[misc_1.ndef - 1] = (integer) misc_1.l772;
	    *l15 = 0;
/*               IF NO WAY TO GET HERE, DELETE IT */
	    if (misc_1.ntran != 0) {
		goto L50;
	    }
	}
    } else {
	diagno_(&c__18);
    }
L980:
    *mtran = misc_1.mlgc;
    adnum_(&jrt);
    if (jrt == 1) {
	goto L50;
    }
    goto L490;

/*     GO TO N OR GO TO N,LIST */

L990:
    *mtran = misc_1.mlgc;
    if (misc_1.ifir != 2) {

/*          STATEMENT IS --GO TO N--. */

	if (misc_1.ifir == 14) {
	    goto L480;
	}
	goto L40;
    }

/*     GO TO N,(LIST) */

L1000:
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) != 0) {
	goto L1000;
    }
    ++misc_1.icol;
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) == 0) {
L1010:
	rstat_();
	if ((integer) misc_1.l772 != 0) {
	    adnum_(&jrt);
	    if (jrt == 1) {
		goto L50;
	    }
	    copy_(&c__1);
	    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) 
		    == 0) {
		goto L1010;
	    }
	    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) 
		    == 0) {
		goto L490;
	    }
	}
    }
    goto L40;

/*                  ***** JTYPE = 25 */
/*     IF ACCUMULATOR OVERFLOW (QUOTIENT, DIVIDE CHECK, END FILE, SENSE) */
/*                  ***** JTYPE = 26 */
/*     IF QUOTIENT OVERFLOW */
/*                  ***** JTYPE = 27 */
/*     IF(DIVIDE CHECK) */

L1020:
    kwdwrt_(&itype);

/*     PROCESS TWO-WAY TRANSFER. */

L1030:
    rstat_();
    if ((integer) misc_1.l772 == 0) {
	goto L40;
    }
    jgoof = 20;
    misc_1.mildo = -1;
    adnum_(&jrt);
    if (jrt == 1) {
	goto L50;
    }
    copy_(&c__1);
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) != 0) {
	goto L40;
    }
    rstat_();
    if ((integer) misc_1.l772 == 0) {
	goto L40;
    }
    goto L980;


/*                  ***** JTYPE = 28 */
/*     IF(END FILE  I) */

L1040:
    kwdwrt_(&itype);
    i__1 = misc_1.jmax;
    for (i__ = misc_1.jcol; i__ <= i__1; ++i__) {
	if (s_cmp(miscal_1.jint + (i__ - 1 << 1), alpha_1.kspk + 8, (ftnlen)2,
		 (ftnlen)2) == 0) {
L1050:
	    copy_(&c__1);
	    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) 
		    == 0) {
		goto L1030;
	    }
	    goto L1050;
	}
/* L1060: */
    }
    jgoof = 20;
    goto L40;

/*                  ***** JTYPE = 29 */
/*     IF(SENSE LIGHT 5) 1,2 */
/*                  ***** JTYPE = 30 */
/*     IF(SENSE SWITCH 5) 1,2 */

L1070:
    jgoof = 20;
    kwdwrt_(&itype);
    copy_(&c__2);
    ++misc_1.icol;
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) == 0) {
	goto L1030;
    }
    goto L40;

/*                  ***** JTYPE = 43 */
/*     ELSEIF */

L1080:
    if (ps1sub_1.nifblk <= 0) {
	s_copy(miscal_1.iout, alpha_1.kabc + 4, (ftnlen)2, (ftnlen)2);
	diagno_(&c__32);
    } else {
	misc_1.icol -= misc_1.indent;
	*icolsv = misc_1.icol;
    }
    kwdwrt_(&itype);
/*          FALL THRU TO IF */

/*                  ***** JTYPE = 31 */
/*     IF (ARITHMETIC) 1,2,3   OR   IF (LOGICAL) STATEMENT. */

L1090:
    jgoof = 20;
    jtyp31_(&jrtcod);
    switch (jrtcod) {
	case 1:  goto L40;
	case 2:  goto L50;
	case 3:  goto L500;
	case 4:  goto L490;
	case 5:  goto L190;
    }

/*                  ***** JTYPE = 32 */
/*     NAMELIST */

L1100:
    jgoof = 21;
    kwdwrt_(&itype);
    j = -1;
    if (misc_1.ifir == 4) {
	goto L640;
    }
    goto L40;

/*                  ***** JTYPE = 33 */
/*     PRINT, TYPE, WRITE, PUNCH, READ, ACCEPT. */

L1110:
    jgoof = 22;
    jtyp33_(&itype, &jrtcod);
    switch (jrtcod) {
	case 1:  goto L480;
	case 2:  goto L40;
	case 3:  goto L470;
	case 4:  goto L50;
	case 5:  goto L490;
    }

/*                  ***** JTYPE = 34 */
/*     SEGMENT,OVERLAY */

L1120:
    --nfort;
    if (nfort != 0) {
	diagno_(&c__14);
    }
    copy_(&misc_1.nins);
    header_();
    if (misc_1.ifir == 3) {
	goto L610;
    }
    goto L40;
/*                  ***** JTYPE = 35 */
/*     PROGRAM, SUBROUTINE, FUNCTION. */

L1130:
    if (nfort != 1) {
	diagno_(&c__14);
    }
    kwdwrt_(&itype);
    header_();
    nlps = 0;
    if (misc_1.ifir == 3) {
	goto L610;
    }
    goto L480;


/*                  ***** JTYPE = 44 */
/*     WRITE OUTPUT TAPE */
/*                  ***** JTYPE = 36 */
/*     READ INPUT TAPE */
/*                  ***** JTYPE = 45 */
/*     WRITE TAPE */
/*                  ***** JTYPE = 37 */
/*     READ TAPE */

L1140:
    kwdwrt_(&itype);

/*                  CONVERT TO CORRESPONDING READ/WRITE(I,N)LIST */
    jgoof = 22;
/*                  COPY UNTIL COMMA */
L1150:
    copy_(&c__1);
    if (misc_1.meof >= 0) {
	goto L40;
    }
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) != 0) {
	goto L1150;
    }
/*                  BINARY READ/WRITE  DO NOT HAVE STATEMENT NUMBERS. */
    if (*jtype == 36 || *jtype == 44) {
/*                  PROCESS FORMAT STATEMENT NUMBER */
	rstat_();
	if ((integer) misc_1.l772 != 0) {
	    adnum_(&jrt);
	    if (jrt == 1) {
		goto L50;
	    }
	    copy_(&c__1);
	    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) 
		    == 0) {
		goto L1170;
	    }
	    if (s_cmp(miscal_1.lcpy, alpha_1.kerm, (ftnlen)2, (ftnlen)2) == 0)
		     {
/*                      NO COMMA. END WITH ) */
		s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), alpha_1.kspk + 
			8, (ftnlen)2, (ftnlen)2);
		*imax = misc_1.icol;
		goto L490;
	    }
	    goto L40;
	}
/*                      VARIABLE FORMAT--NO REFERENCE */
	*klass = 6;
L1160:
	copy_(&c__1);
/*                      LOOK FOR COMMA */
	if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) == 0)
		 {
	    goto L1170;
	}
	if (misc_1.meof < 0) {
	    goto L1160;
	}
    }
/*                  REPLACE , BY ) AND GO PROCESS LIST */
L1170:
    s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), alpha_1.kspk + 8, (ftnlen)
	    2, (ftnlen)2);
    ++misc_1.icol;
    goto L480;

/*                  ***** JTYPE = 38 */
/*     READ ( AND WRITE ( */

L1180:
    jgoof = 23;
L1190:
    kwdwrt_(&itype);
    nlps = 0;
L1200:
    copy_(&c__1);
    if (misc_1.meof >= 0) {
	goto L40;
    }
/*     LEFT PAREN MEANS START OF AN INTERNAL READ/WRITE SUBSCRIPT */
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 4, (ftnlen)2, (ftnlen)2) == 0) {
	++nlps;
	goto L1200;
    }
/*     RIGHT PAREN - COPY REST OF CARD UNLESS CLOSING SUBSCRIPT */
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 8, (ftnlen)2, (ftnlen)2) == 0) {
	if (nlps <= 0) {
	    goto L470;
	}
	--nlps;
	goto L1200;
    }
/*     COMMA - NUMBER WILL FOLLOW UNLESS INTERNAL WRITE SUBSCRIPT */
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)2) == 0) {
	if (nlps == 0) {
	    goto L1210;
	}
	goto L1200;
    }
/*     ACCEPT ANYTHING BUT = SIGN. */
    if (s_cmp(miscal_1.lcpy, alpha_1.kspk, (ftnlen)2, (ftnlen)2) != 0) {
	goto L1200;
    }

/*     LAST CHARACTER WAS =.  CHECK KEYWORD FOR NUMBER FOLLOWING. */
/*      (SKIP FMT AND END FOR TYPE 47) */
    if (*jtype != 47) {
/*         FMT */
	if (bakscn_(alpha_1.kabc + 38, alpha_1.kabc + 24, (ftnlen)2, (ftnlen)
		2)) {
	    goto L1210;
	}
/*         END */
	if (bakscn_(alpha_1.kabc + 6, alpha_1.kabc + 26, (ftnlen)2, (ftnlen)2)
		) {
	    goto L1210;
	}
/*         ERR */
    }
    if (! bakscn_(alpha_1.kabc + 34, alpha_1.kabc + 34, (ftnlen)2, (ftnlen)2))
	     {
	goto L1200;
    }

/*     GET STATEMENT NUMBER */

L1210:
    rstat_();
    if ((integer) misc_1.l772 > 0) {
	adnum_(&jrt);
	if (jrt > 0) {
	    goto L50;
	}
    }
    goto L1200;

/*                  ***** JTYPE = 39 */
/*     RETURN */

L1220:
    kwdwrt_(&itype);
    *mtran = misc_1.mlgc;
    goto L480;

/*                  ***** JTYPE = 40 */
/*     SENSE LIGHT */

L1230:
    kwdwrt_(&itype);
    goto L470;

/*                  ***** JTYPE = 41 */
/*     STOP */

L1240:
    kwdwrt_(&itype);
    misc_1.mildo = -1;
    *mtran = misc_1.mlgc;
    goto L480;

/*                  ***** JTYPE = 42 */
/*     IF (UNIT,N) L1,L2,L3,L4 */

L1250:
    kwdwrt_(&itype);
    copy_(&c_n1);
    if (misc_1.meof < 0) {
	++misc_1.icol;
	misc_1.mildo = 1;
	dlist_(&merr);
	if (merr >= 0) {
	    for (i__ = 1; i__ <= 4; ++i__) {
		rstat_();
		if ((integer) misc_1.l772 == 0) {
		    goto L40;
		}
		adnum_(&jrt);
		if (jrt == 1) {
		    goto L50;
		}
		copy_(&c__1);
		if (s_cmp(miscal_1.lcpy, alpha_1.kspk + 2, (ftnlen)2, (ftnlen)
			2) != 0) {
		    if (i__ == 4 && s_cmp(miscal_1.lcpy, alpha_1.kerm, (
			    ftnlen)2, (ftnlen)2) == 0) {
			goto L500;
		    }
		    goto L40;
		}
/* L1260: */
	    }
	}
    }
    goto L40;

/*                        ***** JTYPE = 46 */
/*     COMPLEX,  INTEGER,  REAL,  LOGICAL,  CHARACTER */

L1270:
    kwdwrt_(&itype);
    ktdcl = 0;

/*     CHECK IF HAS BYTE COUNT (REAL*8 ETC) */
    if (misc_1.ifir == 8) {
	--misc_1.icol;
/*          STATEMENT IS E.G. REAL*8, I.E. WITH BYTE NUMBER */
/*          FIRST SWALLOW ANY BLANKS BEFORE IT. */
L1280:
	if (misc_1.jcol == misc_1.lfir) {
	    goto L1290;
	}
	if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kbl, (
		ftnlen)2, (ftnlen)2) != 0) {
	    goto L470;
	}
	++misc_1.jcol;
	goto L1280;

/*     * WAS NEXT CHARACTER. COPY IT. */
L1290:
	copy_(&c__1);

L1300:
	if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kbl, (
		ftnlen)2, (ftnlen)2) != 0) {

/*     PROCESS  *(*) */
	    if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.kspk + 
		    4, (ftnlen)2, (ftnlen)2) == 0) {
		copy_(&c__3);
		goto L470;
	    }
	    goto L1320;
	}
	++misc_1.jcol;
	goto L1300;

/*     GO PAST BYTE COUNT */
L1310:
	copy_(&c__1);
L1320:
	for (i__ = 1; i__ <= 10; ++i__) {
	    ip = i_indx("0123456789", miscal_1.jint + (misc_1.jcol - 1 << 1), 
		    (ftnlen)10, (ftnlen)1);
	    if (ip > 0) {
		goto L1310;
	    }
/* L1330: */
	}
	++misc_1.icol;

/*     POSSIBLE VIOLATION OF ANSI STANDARD (REAL*8, ETC) */
/*      (ONLY LEGAL SIZE DECLARATION IS CHARACTER) */
	if (misc_1.mansi == 0 && itype != 9) {
	    ktdcl = 1;
	}
    }

/*     SEE IF IT IS A FUNCTION, IF SO ADD A SPACE AFTER */
    i__ = 29;
    kwscan_(&i__, ps1sub_1.kstc);
    if (i__ == 29) {
	kwdwrt_(&i__);
    } else {

	if (ktdcl == 1) {
	    diagno_(&c__40);
	}

/*     LOOK FOR NON-ANSI INITIALIZED DECLARATIONS. */
	if (misc_1.mansi == 0) {
	    i__1 = misc_1.jmax;
	    for (nf = misc_1.lfir; nf <= i__1; ++nf) {
		if (s_cmp(miscal_1.jint + (nf - 1 << 1), alpha_1.kspk + 6, (
			ftnlen)2, (ftnlen)2) == 0) {
		    diagno_(&c__42);
		    goto L470;
		}
/* L1340: */
	    }
	}
    }
    goto L480;

/*                        ***** JTYPE = 47 */
/*     OPEN, CLOSE, INQUIRE */
L1350:
    jgoof = 31;
    goto L1190;

/*                        ***** JTYPE = 48 */
/*     ENDIF */
L1360:
    --ps1sub_1.nifblk;
    if (ps1sub_1.nifblk < 0) {
	ps1sub_1.nifblk = 0;
	s_copy(miscal_1.iout, alpha_1.kabc + 4, (ftnlen)2, (ftnlen)2);
	diagno_(&c__32);
    } else {
	misc_1.icol -= misc_1.indent;
	*icolsv = misc_1.icol;
    }
    kwdwrt_(&itype);
    goto L500;

/*                        ***** JTYPE = 49 */
/*     ELSE */
L1370:
    if (ps1sub_1.nifblk <= 0) {
	s_copy(miscal_1.iout, alpha_1.kabc + 4, (ftnlen)2, (ftnlen)2);
	diagno_(&c__32);
    } else {
	misc_1.icol -= misc_1.indent;
	*icolsv = misc_1.icol;
    }
    kwdwrt_(&itype);
    goto L500;

/*                        ***** JTYPE = 50 */
/*     ENDDO, REPEAT */
/*       GET CURRENT END-DO NUMBER */
L1380:
    *l15 = kcndo[kcndp - 1];
    --kcndp;
    if (kcndp < 0) {
	diagno_(&c__43);
    }
    if (*l15 > 0) {
/*     CONVERT TO A CONTINUE STATEMENT */
/*                            PROCESS STATEMENT NUMBER */
	if (misc_1.ndos != 0) {
/*                            IT TERMINATES THIS DO-LOOP. INDENT */
/*                            ONE LESS LEVEL */
	    if (*l15 == misc_1.ldos[misc_1.ndos - 1] && misc_1.mlgc != 0) {
		misc_1.icol -= misc_1.indent;
		*icolsv = misc_1.icol;
	    }
	}
/*     CONVERT TO A CONTINUE CARD. */
	kwdwrt_(&c__87);
	s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), alpha_1.kerm, (ftnlen)
		2, (ftnlen)2);
	goto L490;
    } else {
/*     PASS A DO WHILE LOOP TERMINATOR UNALTERED (BUT PROPERLY INDENTED) */
	if (misc_1.mlgc != 0) {
	    misc_1.icol -= misc_1.indent;
	    *icolsv = misc_1.icol;
	}
	--ps1sub_1.nifblk;
/*     END DO */
	kwdwrt_(&itype);
	goto L500;
    }

/*                        ***** JTYPE = 51 */
/*     DO WHILE */
L1390:
    kwdwrt_(&itype);
/*     TREAT UNNUMBERED DO-LOOP THIS WAY IF DESIRED */
L1400:
    copy_(&c__0);
/*     GIVE IT A NEGATIVE PSEUDO-STATEMENT NUMBER IN STACK TO PREVENT */
/*      CONVERSION TO CONTINUE */
    ++kcndp;
    kcndo[kcndp - 1] = -kenddo;
    ++kenddo;
    ++ps1sub_1.nifblk;
    goto L500;


} /* pass1_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int pass2_(void)
{
    /* Format strings */
    static char fmt_240[] = "(7x,75a1,i4,a1)";
    static char fmt_230[] = "(\002 \002,70x,\002$ $ $ $ $\002)";
    static char fmt_210[] = "(\002 KLASS\002,i3,\002 JTYPE\002,i3,\002 L1"
	    "5\002,i7,\002 IMAX\002,i4,\002 TRAN\002,i2,\002\rNXRF: \002,i4"
	    "/\002  MEX=\002,i4,\002 ICOLSV = \002,i3,\002 SERIAL:\002,8a2)";
    static char fmt_220[] = "(\002 DELETING A KLASS=\002,i3,\002 STATEMEN"
	    "T\002)";
    static char fmt_250[] = "(7x,80a1)";
    static char fmt_260[] = "(75a1,i4,a1)";
    static char fmt_270[] = "(80a1)";

    /* System generated locals */
    integer i__1, i__2;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_cmp(char *, char *, ftnlen, ftnlen), s_wsfe(cilist *), do_fio(
	    integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__, j;
#define l15 ((integer *)&misc_1 + 23)
    static integer n72;
#define kim ((char *)&miscal_1 + 166)
    static integer n72r;
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int page_(integer *);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static integer iold, inew;
    extern /* Subroutine */ int rdbin_(integer *, integer *, char *, char *, 
	    ftnlen, ftnlen);
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define iout72 ((char *)&miscal_1 + 6886)
#define minus ((char *)&alpha_1 + 86)
    extern /* Subroutine */ int renum_(void), header_(void), diagno_(integer *
	    ), kimpak_(void);
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___413 = { 0, 0, 0, fmt_240, 0 };
    static cilist io___414 = { 0, 0, 0, fmt_230, 0 };
    static cilist io___415 = { 0, 0, 0, fmt_210, 0 };
    static cilist io___416 = { 0, 0, 0, fmt_220, 0 };
    static cilist io___420 = { 0, 0, 0, fmt_240, 0 };
    static cilist io___421 = { 0, 0, 0, fmt_250, 0 };
    static cilist io___422 = { 0, 0, 0, fmt_250, 0 };
    static cilist io___423 = { 0, 0, 0, fmt_260, 0 };
    static cilist io___424 = { 0, 0, 0, fmt_270, 0 };
    static cilist io___425 = { 0, 0, 0, fmt_270, 0 };
    static cilist io___426 = { 0, 0, 0, fmt_240, 0 };
    static cilist io___427 = { 0, 0, 0, fmt_250, 0 };
    static cilist io___428 = { 0, 0, 0, fmt_250, 0 };
    static cilist io___429 = { 0, 0, 0, fmt_260, 0 };
    static cilist io___430 = { 0, 0, 0, fmt_270, 0 };
    static cilist io___431 = { 0, 0, 0, fmt_270, 0 };



/*     THIS ROUTINE READS THE DATA GENERATED BY PASS1 AND WRITES AND */
/*      PUNCHES THE RENUMBERED DECK. */
/*     UNNUMBERED CONTINUE AND FORMAT STATEMENTS ARE DELETED WITHOUT */
/*      A DIAGNOSTIC. */
/*     UNREACHABLE STATEMENTS ARE DELETED IF *NO CONTINUES */
/*      IS IN EFFECT (MCONT=0) */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*     SET UP DIMENSIONED ARRAY FOR EFFICIENT PRINTING */
/*  FORTRAN LOGICAL UNITS */
/*        TABLE OF EXECUTABLE(1) OR NON-EXECUTABLE(0) BY KLASS */
/*      INTEGER IEXFLG(12) */
/*                                     1 1 */
/*         KLASS   0 1 2 3 4 5 6 7 8 9 0 1 */
/*      DATA IEXFLG/0,0,0,0,1,0,1,1,0,1,1,1/ */

    if (misc_1.mp2 == 0 || misc_1.nrt1 <= 0) {
	return 0;
    }

/*     MOVE LIST OF NEW STATEMENT NUMBERS FROM TEMP STORAGE */

    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	_BLNK__1.locdef[i__ - 1] = _BLNK__1.newnum[i__ - 1];
/* L10: */
    }

/*     SET INITIAL CONSTANTS. */

    misc_1.ipass = 2;
    misc_1.mpage = 0;
    misc_1.nrec = 0;
    misc_1.ntran = 0;
    *imax = (misc_1.maxcnt + 1) * 66 + 6;
    *jtype = 0;

L20:
    if (misc_1.nrt1 == 0) {
	goto L200;
    }
/*      JTYPP=JTYPE */
    iold = *imax;
    rdbin_(&lunits_1.scfil1, misc_1.kili, miscal_1.serial, miscal_1.iout, (
	    ftnlen)2, (ftnlen)2);
/*                  BLANK OUT REMAINDER OF PREVIOUS CARD, IF NECESSARY. */
    if (*imax < iold) {
	inew = *imax + 1;
	i__1 = iold;
	for (i__ = inew; i__ <= i__1; ++i__) {
	    s_copy(miscal_1.iout + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2);
/* L30: */
	}
    }
/*                  LOOK FOR $  (FOR WARNING FLAG) */
    if (*klass > 1) {
	i__1 = *imax;
	for (i__ = 7; i__ <= i__1; ++i__) {
	    if (s_cmp(miscal_1.iout + (i__ - 1 << 1), alpha_1.kspk + 18, (
		    ftnlen)2, (ftnlen)2) == 0) {
		if (misc_1.mprin == 0) {
		    io___413.ciunit = lunits_1.outfil;
		    s_wsfe(&io___413);
		    do_fio(&c__72, iout72, (ftnlen)2);
		    e_wsfe();
		}
		io___414.ciunit = lunits_1.outfil;
		s_wsfe(&io___414);
		e_wsfe();
		goto L50;
	    }
/* L40: */
	}
    }

L50:
    --misc_1.nrt1;
    if (misc_1.nrec == 0) {
	header_();
	if (misc_1.mprin != 0) {
	    page_(&c__0);
	}
    }

    if (misc_1.mdeb != 0) {
	io___415.ciunit = lunits_1.outfil;
	s_wsfe(&io___415);
	do_fio(&c__8, (char *)&misc_1.kili[0], (ftnlen)sizeof(integer));
	do_fio(&c__8, miscal_1.serial, (ftnlen)2);
	e_wsfe();
    }
    i__ = *klass + 1;
/*      KLASS=0   1   2   3   4   5   6   7   8   9   10  11 */
    switch (i__) {
	case 1:  goto L20;
	case 2:  goto L130;
	case 3:  goto L60;
	case 4:  goto L130;
	case 5:  goto L100;
	case 6:  goto L100;
	case 7:  goto L100;
	case 8:  goto L70;
	case 9:  goto L170;
	case 10:  goto L130;
	case 11:  goto L70;
	case 12:  goto L100;
    }
/*                KLASS  DESCRIPTION */
/*                  0.   CONTROL CARD */
/*                  1.   COMMENT */
/*                  2.   HEADER */
/*                  3.   NO STATEMENT NO ALLOWED (NON-EXECTUABLE) */
/*                  4.   CONTINUE */
/*                  5.   FORMAT STATEMENT. */
/*                  6.   STATEMENT NO. ALLOWED, NO REFERENCES */
/*                  7.   REFERENCES PRESENT, STATEMENT NO. ALLOWED. */
/*                  8.   END */
/*                  9.   INTRODUCTORY */
/*                  10.  DO */
/*                  11.  ELSE,ENDIF,ELSEIF, UNRECOGNIZED */
/*                       (TRANSFER CAN GET HERE REGARDLESS OF LABEL) */

/*     KLASS 0.   CONTROL CARD */
/*             RESERVED FOR FUTURE DEVELOPMENT. */

L60:
    if (misc_1.mprin == 0) {
	page_(&c__2);
/*          IF (MPUN.NE.0) THEN */
/*               WRITE (OUTFIL,280) (KIM(I,1),I=1,72) */
/*          ELSE */
/*               WRITE (OUTFIL,290) (KIM(I,1),I=1,72) */
/*          END IF */
    }
    goto L130;

/*     DO REFERENCES. */

L70:
    i__1 = *imax;
    for (i__ = 7; i__ <= i__1; ++i__) {
	s_copy(miscal_1.jint + (i__ - 1 << 1), miscal_1.iout + (i__ - 1 << 1),
		 (ftnlen)2, (ftnlen)2);
	s_copy(miscal_1.iout + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2);
/* L80: */
    }
    misc_1.icol = 6;
    misc_1.jcol = 7;
    misc_1.jmax = *imax;
    i__ = 1;

L90:
    if (s_cmp(miscal_1.jint + (misc_1.jcol - 1 << 1), alpha_1.klr2, (ftnlen)2,
	     (ftnlen)2) == 0) {
/*     RENUMBER A REFERENCE */
	misc_1.l772 = (doublereal) _BLNK__1.ioutn[i__ - 1];
	++misc_1.jcol;
	++i__;
	if ((integer) misc_1.l772 != 0) {
	    renum_();
	    if ((integer) misc_1.l772 == 0) {
		diagno_(&c__53);
	    }
	}
    } else {
/*     COPY A CHARACTER */
	++misc_1.icol;
	s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), miscal_1.jint + (
		misc_1.jcol - 1 << 1), (ftnlen)2, (ftnlen)2);
	++misc_1.jcol;
    }
    if (misc_1.jcol <= misc_1.jmax) {
	goto L90;
    }
    *imax = misc_1.icol;

/*          DO STATEMENT NUMBER */

L100:
    misc_1.l772 = (doublereal) (*l15);
    misc_1.icol = 0;
    if ((integer) misc_1.l772 != 0) {
	renum_();
/*          IF (INT(L772).EQ.0) CALL DIAGNO (53) */
    }
/*        PRINT ALL LABELLED STATEMENTS, ELSE, ELSEIF, ENDIF */
    if ((integer) misc_1.l772 != 0 || *klass == 11) {
/*        REMEMBER THAT THIS STATEMENT HAS A PATH TO IT */
	misc_1.ntran = 0;
	goto L130;
    }
/*                 DELETE ALL UNLABELLED CONTINUES AND FORMATS */
    if (*klass == 4 || *klass == 5) {
	if (misc_1.mdeb != 0) {
	    io___416.ciunit = lunits_1.outfil;
	    s_wsfe(&io___416);
	    do_fio(&c__1, (char *)&(*klass), (ftnlen)sizeof(integer));
	    e_wsfe();
	}
	goto L20;
    }
/*           PUNCH IF THERE IS A PATH TO THIS STATEMENT */
/*     IF (NTRAN.NE.-1) GO TO 130 */
/*                 *CONTINUE MEANS ALL OTHER KLASSES ARE OK */
/*     IF (MCONT.NE.0) GO TO 130 */
/*                 PUNCH NON-EXECUTABLE STATEMENTS */
/*     IF (IEXFLG(KLASS+1).EQ.0) GO TO 130 */
/*     ACCEPT GOTO FOLLOWING A COMPUTED GOTO */
/*     IF (JTYPE.EQ.24 .AND. JTYPP.EQ.23) GO TO 130 */



/*     WRITE  (PUNCH) NEW STATEMENT. */

L130:
    if (*klass == 1 && misc_1.mser == 0) {
	n72r = 80;
    } else {
	n72r = 72;
    }

    kimpak_();

    i__1 = misc_1.ncd;
    for (j = 1; j <= i__1; ++j) {
	misc_1.nrec += misc_1.kd79;

/*     IF NO SERIAL, DO NOT PRINT TRAILING BLANKS. */
	if (misc_1.mser == 0) {
	    n72 = n72r;
	    for (i__ = n72r; i__ >= 1; --i__) {
		if (s_cmp(kim + (i__ + j * 80 - 81 << 1), alpha_1.kbl, (
			ftnlen)2, (ftnlen)2) != 0) {
		    n72 = i__;
		    goto L150;
		}
/* L140: */
	    }
	}

/*     PRINT AND/OR PUNCH AN OUTPUT RECORD. */

/*     STRING KOL73 IS SET IN SUBROUTINE HEADER. */

L150:
	if (misc_1.mprin != 0) {
	    page_(&c__1);
	    if (misc_1.mser < 0) {
		io___420.ciunit = lunits_1.outfil;
		s_wsfe(&io___420);
		for (i__ = 1; i__ <= 72; ++i__) {
		    do_fio(&c__1, kim + (i__ + j * 80 - 81 << 1), (ftnlen)2);
		}
		do_fio(&c__3, miscal_1.kol73, (ftnlen)2);
		do_fio(&c__1, (char *)&misc_1.nrec, (ftnlen)sizeof(integer));
		e_wsfe();
	    } else if (misc_1.mser == 0) {
		io___421.ciunit = lunits_1.outfil;
		s_wsfe(&io___421);
		i__2 = n72;
		for (i__ = 1; i__ <= i__2; ++i__) {
		    do_fio(&c__1, kim + (i__ + j * 80 - 81 << 1), (ftnlen)2);
		}
		e_wsfe();
	    } else {
		io___422.ciunit = lunits_1.outfil;
		s_wsfe(&io___422);
		for (i__ = 1; i__ <= 72; ++i__) {
		    do_fio(&c__1, kim + (i__ + j * 80 - 81 << 1), (ftnlen)2);
		}
		do_fio(&c__8, miscal_1.serial, (ftnlen)2);
		e_wsfe();
	    }
	}
	if (misc_1.mpun != 0) {
	    ++misc_1.npun;
	    if (misc_1.mser < 0) {
		io___423.ciunit = lunits_1.punfil;
		s_wsfe(&io___423);
		for (i__ = 1; i__ <= 72; ++i__) {
		    do_fio(&c__1, kim + (i__ + j * 80 - 81 << 1), (ftnlen)2);
		}
		do_fio(&c__3, miscal_1.kol73, (ftnlen)2);
		do_fio(&c__1, (char *)&misc_1.nrec, (ftnlen)sizeof(integer));
		e_wsfe();
	    } else if (misc_1.mser == 0) {
		io___424.ciunit = lunits_1.punfil;
		s_wsfe(&io___424);
		i__2 = n72;
		for (i__ = 1; i__ <= i__2; ++i__) {
		    do_fio(&c__1, kim + (i__ + j * 80 - 81 << 1), (ftnlen)2);
		}
		e_wsfe();
	    } else {
		io___425.ciunit = lunits_1.punfil;
		s_wsfe(&io___425);
		for (i__ = 1; i__ <= 72; ++i__) {
		    do_fio(&c__1, kim + (i__ + j * 80 - 81 << 1), (ftnlen)2);
		}
		do_fio(&c__8, miscal_1.serial, (ftnlen)2);
		e_wsfe();
	    }
	}

/* L160: */
    }
/*           REMEMBER IF THIS IS AN UNCONDITIONAL TRANSFER */
    if (*mtran == -1) {
	misc_1.ntran = -1;
    }
    goto L20;

/*     END STATEMENT. */

L170:
    misc_1.nrec += misc_1.kd79;

/*     IF NO SERIAL, DO NOT PRINT TRAILING BLANKS. */
    if (misc_1.mser == 0) {
	for (i__ = 72; i__ >= 1; --i__) {
	    if (s_cmp(iout72 + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		    ftnlen)2) != 0) {
		n72 = i__;
		goto L190;
	    }
/* L180: */
	}
    }
L190:
    if (misc_1.mprin != 0) {
	page_(&c__1);
	if (misc_1.mser < 0) {
	    io___426.ciunit = lunits_1.outfil;
	    s_wsfe(&io___426);
	    do_fio(&c__72, iout72, (ftnlen)2);
	    do_fio(&c__3, miscal_1.kol73, (ftnlen)2);
	    do_fio(&c__1, (char *)&misc_1.nrec, (ftnlen)sizeof(integer));
	    do_fio(&c__1, minus, (ftnlen)2);
	    e_wsfe();
	} else if (misc_1.mser == 0) {
	    io___427.ciunit = lunits_1.outfil;
	    s_wsfe(&io___427);
	    i__1 = n72;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		do_fio(&c__1, iout72 + (i__ - 1 << 1), (ftnlen)2);
	    }
	    e_wsfe();
	} else {
	    io___428.ciunit = lunits_1.outfil;
	    s_wsfe(&io___428);
	    do_fio(&c__72, iout72, (ftnlen)2);
	    do_fio(&c__8, miscal_1.serial, (ftnlen)2);
	    e_wsfe();
	}
    }
    if (misc_1.mpun != 0) {
	++misc_1.npun;
	if (misc_1.mser < 0) {
	    io___429.ciunit = lunits_1.punfil;
	    s_wsfe(&io___429);
	    do_fio(&c__72, iout72, (ftnlen)2);
	    do_fio(&c__3, miscal_1.kol73, (ftnlen)2);
	    do_fio(&c__1, (char *)&misc_1.nrec, (ftnlen)sizeof(integer));
	    do_fio(&c__1, minus, (ftnlen)2);
	    e_wsfe();
	} else if (misc_1.mser == 0) {
	    io___430.ciunit = lunits_1.punfil;
	    s_wsfe(&io___430);
	    i__1 = n72;
	    for (i__ = 1; i__ <= i__1; ++i__) {
		do_fio(&c__1, iout72 + (i__ - 1 << 1), (ftnlen)2);
	    }
	    e_wsfe();
	} else {
	    io___431.ciunit = lunits_1.punfil;
	    s_wsfe(&io___431);
	    do_fio(&c__72, iout72, (ftnlen)2);
	    do_fio(&c__8, miscal_1.serial, (ftnlen)2);
	    e_wsfe();
	}
    }
L200:
    return 0;


/* 280  FORMAT (' ',15X,72A1,5X,'--PUNCHED') */
/* 290  FORMAT (' ',15X,72A1,5X,'--NOT PUNCHED') */
} /* pass2_ */

#undef icolsv
#undef minus
#undef iout72
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int rdbin_(integer *nunit, integer *kv, char *ser, char *
	list, ftnlen ser_len, ftnlen list_len)
{
    /* Format strings */
    static char fmt_10[] = "(\002 Unit \002,i2,\002  read: \002,8i8)";

    /* Builtin functions */
    integer s_rsue(cilist *), do_uio(integer *, char *, ftnlen), e_rsue(void),
	     s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void)
	    ;

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int redstr_(integer *, char *, integer *, integer 
	    *, integer *, integer *, ftnlen);

    /* Fortran I/O blocks */
    static cilist io___441 = { 0, 0, 0, 0, 0 };
    static cilist io___442 = { 0, 0, 0, fmt_10, 0 };



/*     READ UNFORMATTED INTERMEDIATE FILES. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */


    /* Parameter adjustments */
    list -= 2;
    ser -= 2;
    --kv;

    /* Function Body */
    io___441.ciunit = *nunit;
    s_rsue(&io___441);
    do_uio(&c__8, (char *)&kv[1], (ftnlen)sizeof(integer));
    do_uio(&c__8, ser + 2, (ftnlen)2);
    e_rsue();
    if (misc_1.mdeb != 0) {
	io___442.ciunit = lunits_1.stderr;
	s_wsfe(&io___442);
	do_fio(&c__1, (char *)&(*nunit), (ftnlen)sizeof(integer));
	do_fio(&c__8, (char *)&kv[1], (ftnlen)sizeof(integer));
	e_wsfe();
    }
    redstr_(nunit, list + 2, &kv[4], _BLNK__1.ioutn, &kv[6], &c__2, (ftnlen)2)
	    ;
/*                            NORMAL EXIT */
    return 0;

} /* rdbin_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int rdir_(void)
{
    /* Format strings */
    static char fmt_60[] = "(\002 \002,32x,\002STATEMENT NUMBER DIRECTORY"
	    "\002/\002 \002,22x,\002NEW    OLD\r  LOC\002,13x,\002OLD   LOC  "
	    "    NEW\002/1x)";
    static char fmt_70[] = "(21x,i5,\002 = \002,i6,\002,(\002,i4,\002).\002,"
	    "8x,i6,\002,(\002,i4,\002) = \002,i5,\002.\002)";
    static char fmt_80[] = "(\002 \002,20x,\002OLD STATEMENT NUMBERS NOT APP"
	    "EARING IN THIS DIRECTORY\002/21x,\002WERE NOT REFERENCED AND HEN"
	    "CE ARE DELETED.\002)";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), e_wsfe(void), do_fio(integer *, char *, ftnlen);

    /* Local variables */
    static integer i__, j, k, m;
#define l15 ((integer *)&misc_1 + 23)
    static integer nr, lo1, no1, no2, lo2, nw1, nw2;
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int page_(integer *);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static integer index[1500];
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___452 = { 0, 0, 0, fmt_60, 0 };
    static cilist io___465 = { 0, 0, 0, fmt_70, 0 };
    static cilist io___466 = { 0, 0, 0, fmt_80, 0 };



/*     THIS SUBROUTINE GENERATES A REFERENCE DIRECTORY OF STATEMENT */
/*     NUMBERS SHOWING THE OLD STATEMENT NUMBER, ITS LOCATION IN THE */
/*     ROUTINE, AND THE NEW STATEMENT NUMBER GENERATED BY TIDY. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*  FORTRAN LOGICAL UNITS */

    if (misc_1.ndef <= 0) {
	return 0;
    }
    i__1 = -(misc_1.ndef + 8);
    page_(&i__1);
    page_(&c__4);
    io___452.ciunit = lunits_1.outfil;
    s_wsfe(&io___452);
    e_wsfe();

    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	index[i__ - 1] = i__;
/* L10: */
    }

/*     ADDRESS-SORT STATEMENT NUMBERS */

    if (misc_1.ndef == 1) {
	goto L40;
    }
    m = misc_1.ndef + 1;
L20:
    nr = 0;
    --m;
    i__1 = m;
    for (i__ = 2; i__ <= i__1; ++i__) {
	j = index[i__ - 2];
	k = index[i__ - 1];
	if (_BLNK__1.ldef[j - 1] == _BLNK__1.ldef[k - 1]) {
	    index[i__ - 2] = k;
	    index[i__ - 1] = j;
	    nr = 1;
	}
/* L30: */
    }
    if (nr != 0) {
	goto L20;
    }

/*     WRITE  DIRECTORY */

L40:
    i__1 = misc_1.ndef;
    for (i__ = 1; i__ <= i__1; ++i__) {
	nw1 = _BLNK__1.newnum[i__ - 1];
	no1 = _BLNK__1.ldef[i__ - 1];
	lo1 = _BLNK__1.locdef[i__ - 1];
	j = index[i__ - 1];
	nw2 = _BLNK__1.newnum[j - 1];
	no2 = _BLNK__1.ldef[j - 1];
	lo2 = _BLNK__1.locdef[j - 1];
	page_(&c__1);
	io___465.ciunit = lunits_1.outfil;
	s_wsfe(&io___465);
	do_fio(&c__1, (char *)&nw1, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&no1, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&lo1, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&no2, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&lo2, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&nw2, (ftnlen)sizeof(integer));
	e_wsfe();
/* L50: */
    }

    page_(&c__3);
    io___466.ciunit = lunits_1.outfil;
    s_wsfe(&io___466);
    e_wsfe();

    return 0;

} /* rdir_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int reader_(void)
{
    /* Format strings */
    static char fmt_60[] = "(80a1)";
    static char fmt_70[] = "(35x,\002( B L A N K   C A R D )\002)";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_rsfe(cilist *), do_fio(integer *, char *, ftnlen), e_rsfe(void),
	     s_cmp(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer s_wsfe(cilist *), e_wsfe(void);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int page_(integer *);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___476 = { 0, 0, 1, fmt_60, 0 };
    static cilist io___478 = { 0, 0, 0, fmt_70, 0 };


/*     THIS ROUTINE READS CARDS ONE BY ONE, UNTIL IT FINDS A */
/*     NON-BLANK ONE, THEN RETURNS.   IF IT FINDS AN END-OF-FILE, OR IF */
/*     IQUIT IS NON-ZERO, IT GENERATES A *STOP CARD. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*  FORTRAN LOGICAL UNITS */
    if (misc_1.iquit == 0) {
L10:
	io___476.ciunit = lunits_1.infile__;
	i__1 = s_rsfe(&io___476);
	if (i__1 != 0) {
	    goto L30;
	}
	i__1 = do_fio(&c__80, miscal_1.kbuff, (ftnlen)2);
	if (i__1 != 0) {
	    goto L30;
	}
	i__1 = e_rsfe();
	if (i__1 != 0) {
	    goto L30;
	}

/*          QUICK CHECK IF THERE IS SOMETHING THERE... */
	if (s_cmp(miscal_1.kbuff + 12, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 
		0) {
	    return 0;
	}

/*          LOOK FOR A TOTALLY BLANK CARD. */
	for (i__ = 1; i__ <= 72; ++i__) {
	    if (s_cmp(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2,
		     (ftnlen)2) != 0) {
		return 0;
	    }
/* L20: */
	}

/*          BLANK CARD. IF INCLUDE FLAG IS SET, MAKE FIRST CHARACTER */
/*           SPECIAL CODE SO CAN BE RECOGNIZED AS A BLANK COMMENT. */
/*           OTHERWISE ISSUE MESSAGE AND GET NEXT CARD. */
	if (misc_1.kbkcok == 1) {
	    s_copy(miscal_1.kbuff, alpha_1.kblcmt, (ftnlen)2, (ftnlen)2);
	    s_copy(miscal_1.kbuff + 2, alpha_1.kerm, (ftnlen)2, (ftnlen)2);
	    return 0;
	} else {
	    page_(&c__1);
	    io___478.ciunit = lunits_1.outfil;
	    s_wsfe(&io___478);
	    e_wsfe();
	    goto L10;
	}
    }
/*                            NO MORE INPUT */
L30:
    misc_1.iquit = 1;

/*     MAKE A *STOP CONTROL CARD. */
    s_copy(miscal_1.kbuff, alpha_1.kspk + 14, (ftnlen)2, (ftnlen)2);
    s_copy(miscal_1.kbuff + 2, alpha_1.kabc + 36, (ftnlen)2, (ftnlen)2);
    s_copy(miscal_1.kbuff + 4, alpha_1.kabc + 38, (ftnlen)2, (ftnlen)2);
    s_copy(miscal_1.kbuff + 6, alpha_1.kabc + 28, (ftnlen)2, (ftnlen)2);
    s_copy(miscal_1.kbuff + 8, alpha_1.kabc + 30, (ftnlen)2, (ftnlen)2);

/*     BLANK OUT REST OF LINE. */
    for (i__ = 6; i__ <= 72; ++i__) {
	s_copy(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2);
/* L40: */
    }
    *l15 = 0;
    misc_1.l25 = 0;
    return 0;

} /* reader_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int redstr_(integer *lu, char *list, integer *nchr, integer *
	irf, integer *nr, integer *iop, ftnlen list_len)
{
    /* Initialized data */

    static integer mxchr = 508;
    static integer mxint = 254;

    static integer nb, nl, mu, nu;
    extern /* Subroutine */ int ionum_(integer *, integer *, integer *, 
	    integer *), iostr_(integer *, char *, integer *, integer *, 
	    ftnlen);


/*     WRITE OUT STRING AS SERIES OF 508-(CHAR*2) RECS */
/*      (APPARENTLY 1024 BYTES IS MAGIC NUMBER FOR PROFORT, AND EACH REC */
/*       HAS 4-BYTE HEADER AND TRAILER) */

    /* Parameter adjustments */
    list -= 2;
    --irf;

    /* Function Body */
    nl = 1;
    mu = mxchr;
L10:
    nu = min(*nchr,mu);
    nb = nu - nl + 1;
    iostr_(lu, list + (nl << 1), &nb, iop, (ftnlen)2);
    if (*nchr > nu) {
	mu += mxchr;
	nl = nu + 1;
	goto L10;
    }

/*     NOW DO THE CROSS-REFERENCE TABLE (253 REFS?~) */
    nl = 1;
    mu = mxint;
L20:
    nu = min(*nr,mu);
    nb = nu - nl + 1;
    ionum_(lu, &irf[nl], &nb, iop);
    if (*nr > nu) {
	mu += mxint;
	nl = nu + 1;
	goto L20;
    }

    return 0;
} /* redstr_ */

/* Subroutine */ int iostr_(integer *lu, char *list, integer *nb, integer *
	iop, ftnlen list_len)
{
    /* System generated locals */
    integer list_dim1, i__1;

    /* Builtin functions */
    integer s_wsue(cilist *), do_uio(integer *, char *, ftnlen), e_wsue(void),
	     s_rsue(cilist *), e_rsue(void);

    /* Fortran I/O blocks */
    static cilist io___485 = { 0, 0, 0, 0, 0 };
    static cilist io___486 = { 0, 0, 0, 0, 0 };



/*     READ OR WRITE A STRING */

    /* Parameter adjustments */
    list_dim1 = *nb;
    list -= 2;

    /* Function Body */
    if (*iop == 1) {
	io___485.ciunit = *lu;
	s_wsue(&io___485);
	i__1 = 1 * list_dim1;
	do_uio(&i__1, list + 2, (ftnlen)2);
	e_wsue();
    } else {
	io___486.ciunit = *lu;
	s_rsue(&io___486);
	i__1 = 1 * list_dim1;
	do_uio(&i__1, list + 2, (ftnlen)2);
	e_rsue();
    }
    return 0;
} /* iostr_ */

/* Subroutine */ int ionum_(integer *lu, integer *irf, integer *nr, integer *
	iop)
{
    /* System generated locals */
    integer irf_dim1, i__1;

    /* Builtin functions */
    integer s_wsue(cilist *), do_uio(integer *, char *, ftnlen), e_wsue(void),
	     s_rsue(cilist *), e_rsue(void);

    /* Fortran I/O blocks */
    static cilist io___487 = { 0, 0, 0, 0, 0 };
    static cilist io___488 = { 0, 0, 0, 0, 0 };



/*     READ OR WRITE AN INTEGER ARRAY. */

    /* Parameter adjustments */
    irf_dim1 = *nr;
    --irf;

    /* Function Body */
    if (*iop == 1) {
	io___487.ciunit = *lu;
	s_wsue(&io___487);
	i__1 = 1 * irf_dim1;
	do_uio(&i__1, (char *)&irf[1], (ftnlen)sizeof(integer));
	e_wsue();
    } else {
	io___488.ciunit = *lu;
	s_rsue(&io___488);
	i__1 = 1 * irf_dim1;
	do_uio(&i__1, (char *)&irf[1], (ftnlen)sizeof(integer));
	e_rsue();
    }
    return 0;
} /* ionum_ */

/* Subroutine */ int renum_(void)
{
    /* System generated locals */
    integer i__1, i__2, i__3;

    /* Builtin functions */
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);
    integer i_dim(integer *, integer *);

    /* Local variables */
    static integer i__, j, k, l;
#define l15 ((integer *)&misc_1 + 23)
    static integer ii, ik, it;
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)


/*     THIS SUBROUTINE INSPECTS THE OLD STATEMENT NUMBER IN L772 AND */
/*     INSERTS THE NEW NUMBER CORRESPONDING TO L772 IN IOUT STARTING AT */
/*     ICOL+1.  ON EXIT, L772 CONTAINS THE NEW STATEMENT NUMBER. */


/*     SEARCH DEFINED STATEMENT TABLE FOR L772. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    if (misc_1.ndef != 0) {
	i__1 = misc_1.ndef;
	for (ii = 1; ii <= i__1; ++ii) {
	    if (_BLNK__1.ldef[ii - 1] == (integer) misc_1.l772) {

/*     ASSEMBLE NEW STATEMENT NUMBER CHARS IN REVERSE ORDER. */

		i__ = _BLNK__1.newnum[ii - 1];
		misc_1.l772 = (doublereal) i__;
		for (l = 1; l <= 5; ++l) {
		    it = i__ / 10;
		    k = i__ - it * 10;
		    j = l;
		    s_copy(miscal_1.ntemp + (j - 1 << 1), alpha_1.kdig + (k <<
			     1), (ftnlen)2, (ftnlen)2);
		    i__ = it;
		    if (i__ == 0) {
			goto L20;
		    }
/* L10: */
		}
		j = 5;

/*     INSERT STATEMENT NUMBER DIGITS. */

L20:
		if (misc_1.icol == 0) {
/*                            COLUMNS 1-5 */
		    for (ik = 1; ik <= 5; ++ik) {
			s_copy(miscal_1.iout + (ik - 1 << 1), alpha_1.kbl, (
				ftnlen)2, (ftnlen)2);
/* L30: */
		    }
		    if (misc_1.mrit >= 0) {
/*                            RIGHT ADJUST TO COLUMN -MRIT */
			misc_1.icol = i_dim(&misc_1.mrit, &j);
		    } else {
/*                            LEFT ADJUST TO COLUMN MRIT */
/* Computing MIN */
			i__2 = -misc_1.mrit, i__3 = 6 - j;
			misc_1.icol = min(i__2,i__3);
			misc_1.icol = i_dim(&misc_1.icol, &c__1);
		    }
		}
L40:
		++misc_1.icol;
		s_copy(miscal_1.iout + (misc_1.icol - 1 << 1), miscal_1.ntemp 
			+ (j - 1 << 1), (ftnlen)2, (ftnlen)2);
		--j;
		if (j != 0) {
		    goto L40;
		}
		return 0;
	    }
/* L50: */
	}
    }

/*     NOT IN STATEMENT NUMBER LIST. DELETE NUMBER. */

    misc_1.l772 = 0.;
    return 0;
} /* renum_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int rlist_(void)
{
    /* Format strings */
    static char fmt_20[] = "(\002 RLIST added #\002,i6,\002 NREF = \002,i5)";

    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    extern /* Subroutine */ int diagno_(integer *);
#define icolsv ((integer *)&misc_1 + 28)

    /* Fortran I/O blocks */
    static cilist io___515 = { 0, 0, 0, fmt_20, 0 };



/*     THIS SUBROUTINE UPDATES THE REFERENCED STATEMENT NUMBER LIST. */
/*     L772 CONTAINS THE REFERENCED STATEMENT NUMBER. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*  FORTRAN LOGICAL UNITS */
    if ((integer) misc_1.l772 == 0) {
	return 0;
    }
/*                  POOR PROGRAMMING PRACTICE. */
    if ((integer) misc_1.l772 == *l15) {
	diagno_(&c__18);
    }
    if (misc_1.nref < 0) {
	return 0;
    }

/*     CHECK IF IT IS ALREADY REFERENCED. */
    if (misc_1.nref > 0) {
	i__1 = misc_1.nref;
	for (i__ = 1; i__ <= i__1; ++i__) {
	    if (_BLNK__1.lref[i__ - 1] == (integer) misc_1.l772) {
		return 0;
	    }
/* L10: */
	}
    }

/*     ADD REFERENCED STATEMENT TO TABLE. */

    ++misc_1.nref;
    if (misc_1.nref <= 1500) {
	_BLNK__1.lref[misc_1.nref - 1] = (integer) misc_1.l772;
    } else {
/*                  TABLE FULL */
	diagno_(&c__7);
	misc_1.nref = -1;
	misc_1.mp2 = 0;
    }

    if (misc_1.mdeb > 0) {
	io___515.ciunit = lunits_1.outfil;
	s_wsfe(&io___515);
	i__1 = (integer) misc_1.l772;
	do_fio(&c__1, (char *)&i__1, (ftnlen)sizeof(integer));
	do_fio(&c__1, (char *)&misc_1.nref, (ftnlen)sizeof(integer));
	e_wsfe();
    }

    return 0;

} /* rlist_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int rstat_(void)
{
    /* System generated locals */
    integer i__1;

    /* Builtin functions */
    integer i_indx(char *, char *, ftnlen, ftnlen);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
    static integer ip;
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)


/*     THIS SUBROUTINE GETS THE STATEMENT NUMBER REFERENCED AT LOCATION */
/*     JCOL AND PUTS IT IN L772.  JCOL IS LEFT SET AT THE LOCATION OF THE */
/*     NEXT SYMBOL ON JINT. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
    misc_1.l772 = 0.;
    if (misc_1.jcol > misc_1.jmax) {
	misc_1.jcol = misc_1.jmax;
    } else {

	i__ = misc_1.jcol;
	i__1 = misc_1.jmax;
	for (misc_1.jcol = i__; misc_1.jcol <= i__1; ++misc_1.jcol) {
/*              SKIP BLANKS */
/* >                IF (JINT(JCOL).NE.KBL) THEN */
	    if (*(unsigned char *)&miscal_1.jint[(misc_1.jcol - 1) * 2] != 
		    ' ') {
/*                   CHECK IF A DIGIT */
		ip = i_indx("0123456789", miscal_1.jint + (misc_1.jcol - 1 << 
			1), (ftnlen)10, (ftnlen)1) - 1;
		if (ip < 0) {
		    return 0;
		}
/*                   ADD DIGIT TO NUMBER */
		misc_1.l772 = misc_1.l772 * 10 + ip;
	    }
/* L20: */
	}
	misc_1.jcol = misc_1.jmax;
	s_copy(miscal_1.lcpy, alpha_1.kerm, (ftnlen)2, (ftnlen)2);
	misc_1.meof = 0;
    }
    return 0;
} /* rstat_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int skard_(void)
{
    /* Format strings */
    static char fmt_140[] = "(\002 FATAL ERROR - STATEMENT BEGINS WITH CONTI"
	    "NUATION LINE.\002/\002  POSSIBLY COMMENT WITHIN CONTINUED STATEM"
	    "ENT.\002/\002  TIDY CANNOT PROCESS THESE ALTHOUGH THEY ARE LEGAL"
	    " IN FORTRAN-77.\002)";
    static char fmt_150[] = "(1x,i4,2x,80a1)";
    static char fmt_160[] = "(7x,80a1)";

    /* System generated locals */
    address a__1[2];
    integer i__1, i__2[2];
    char ch__1[2];

    /* Builtin functions */
    integer s_cmp(char *, char *, ftnlen, ftnlen), s_wsfe(cilist *), e_wsfe(
	    void);
    /* Subroutine */ int s_copy(char *, char *, ftnlen, ftnlen), s_cat(char *,
	     char **, integer *, integer *, ftnlen);
    integer do_fio(integer *, char *, ftnlen);

    /* Local variables */
    static integer i__, j, l, k7;
#define kc ((char *)&alpha_1 + 26)
#define l15 ((integer *)&misc_1 + 23)
#define kb1 ((char *)&miscal_1 + 6)
#define kb6 ((char *)&miscal_1 + 16)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
    extern /* Subroutine */ int page_(integer *);
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
    static logical lng72;
#define kdol ((char *)&alpha_1 + 100)
#define kper ((char *)&alpha_1 + 90)
    static char kb1cr1[2];
    static integer krend;
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
    static logical rshft;
#define kzero ((char *)&alpha_1 + 2)
#define kstar ((char *)&alpha_1 + 88)
    extern /* Subroutine */ int header_(void), diagno_(integer *), reader_(
	    void);
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Character */ VOID kupper_(char *, ftnlen, char *, ftnlen);

    /* Fortran I/O blocks */
    static cilist io___546 = { 0, 0, 0, fmt_140, 0 };
    static cilist io___550 = { 0, 0, 0, fmt_150, 0 };
    static cilist io___553 = { 0, 0, 0, fmt_160, 0 };



/*     SUPER-CARD INPUT ROUTINE. */
/*     THIS ROUTINE READS FORTRAN STATEMENTS WITH UP TO 19 CONTINUATION */
/*     CARDS AND PACKS THE STATEMENT INTO THE SUPER-CARD --JINT--. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */

    rshft = TRUE_;
    krend = misc_1.k72;
    lng72 = FALSE_;

/*     TEST FOR A CONTINUATION CARD - SHOULD NOT BE HERE */
/*      (ANSI F77 ALLOWS EMBEDDED COMMENTS IN CONTINUED STATEMENTS, SO */
/*       THIS PATCH SHOULD BE REMOVED IF A WAY TO DO THEM IS FOUND) */
    if (s_cmp(miscal_1.kbuff, alpha_1.kampr, (ftnlen)2, (ftnlen)2) == 0 || 
	    s_cmp(miscal_1.kbuff, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0 && (
	    s_cmp(miscal_1.kbuff + 10, alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 
	    0 && s_cmp(miscal_1.kbuff + 10, kzero, (ftnlen)2, (ftnlen)2) != 0)
	    ) {
	io___546.ciunit = lunits_1.outfil;
	s_wsfe(&io___546);
	e_wsfe();
	diagno_(&c__45);
    }

/*     SAVE FIRST CHARACTER OF CARD */
    kupper_(ch__1, (ftnlen)2, miscal_1.kbuff, (ftnlen)2);
    s_copy(kb1cr1, ch__1, (ftnlen)2, (ftnlen)2);

    misc_1.jmax = 1;
    i__1 = krend;
    for (i__ = 1; i__ <= i__1; ++i__) {
	if (i__ > 72 && s_cmp(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.kbl, (
		ftnlen)2, (ftnlen)2) != 0) {
	    lng72 = TRUE_;
	}
	if (s_cmp(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.ktab, (ftnlen)2, (
		ftnlen)2) == 0) {
	    if (i__ < 7 && rshft) {
/*                  BLANK REST OF NUMBER FIELD */
		for (l = misc_1.jmax; l <= 6; ++l) {
		    s_copy(miscal_1.jint + (l - 1 << 1), alpha_1.kbl, (ftnlen)
			    2, (ftnlen)2);
/* L10: */
		}
		misc_1.jmax = 7;
		rshft = FALSE_;
/*     BLANK THE SERIAL FIELD */
		for (l = 1; l <= 8; ++l) {
		    s_copy(miscal_1.serial + (l - 1 << 1), alpha_1.kbl, (
			    ftnlen)2, (ftnlen)2);
/* L20: */
		}
/*     SET LINE LENGTH TO 80 */
		krend = 80;
		goto L30;
	    } else {
/*     TABS PAST COLUMN 6 TRANSLATE TO SPACES WITH F77 */
		s_copy(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)
			2, (ftnlen)2);
	    }
	}
/*     IDENTIFY CHARS IN COLS 73-80 */
	if (i__ > 72) {
/* Writing concatenation */
	    i__2[0] = 1, a__1[0] = miscal_1.kbuff + (i__ - 1 << 1);
	    i__2[1] = 1, a__1[1] = "~";
	    s_cat(miscal_1.jint + (misc_1.jmax - 1 << 1), a__1, i__2, &c__2, (
		    ftnlen)2);
	} else {
	    s_copy(miscal_1.jint + (misc_1.jmax - 1 << 1), miscal_1.kbuff + (
		    i__ - 1 << 1), (ftnlen)2, (ftnlen)2);
	}
	++misc_1.jmax;
L30:
	;
    }

/*     TRIM OFF TRAILING BLANKS PAST 72. */
L40:
    if (s_cmp(miscal_1.jint + (misc_1.jmax - 2 << 1), " ~", (ftnlen)2, (
	    ftnlen)2) == 0) {
	--misc_1.jmax;
	goto L40;
    }

/*     GRAB EXISTING SERIAL NUMBER IF NEEDED. */
    if (misc_1.mser != 0 && rshft) {
	for (i__ = 1; i__ <= 8; ++i__) {
	    s_copy(miscal_1.serial + (i__ - 1 << 1), miscal_1.kbuff + (i__ + 
		    71 << 1), (ftnlen)2, (ftnlen)2);
/* L50: */
	}
    }

/*     SKIP PAGE HEADER IF NOT BEGINNING. */
    if (misc_1.kount <= 0) {
	header_();
	if (misc_1.mlist != 0) {
	    page_(&c__0);
	}
    }

    misc_1.meof = -1;
    ++misc_1.kount;
    ++misc_1.nrec;
    if (misc_1.mlist != 0) {
	page_(&c__1);
	io___550.ciunit = lunits_1.outfil;
	s_wsfe(&io___550);
	do_fio(&c__1, (char *)&misc_1.nrec, (ftnlen)sizeof(integer));
	do_fio(&c__80, miscal_1.kbuff, (ftnlen)2);
	e_wsfe();
    }

    *nxrf = 2;
    j = 1;

/*     LOOK FOR CONTINUATION CARDS AND TRANSFER THEM TO IOUT VIA KBUFF. */

    if (misc_1.iquit != 1) {
/*     IF FIRST CARD WAS A COMMENT, DO NOT TRY TO CONTINUE IT... */
	if (s_cmp(kb1cr1, kc, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(kb1cr1, 
		alpha_1.kblcmt, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(kb1cr1, 
		kstar, (ftnlen)2, (ftnlen)2) == 0 || s_cmp(kb1cr1, kdol, (
		ftnlen)2, (ftnlen)2) == 0 || s_cmp(kb1cr1, kper, (ftnlen)2, (
		ftnlen)2) == 0) {
	    lng72 = FALSE_;
	    reader_();
	    goto L110;
	}

/*     NOT COMMENT, CONTINUATIONS ARE LEGAL. */
	for (j = 2; j <= 40; ++j) {
	    reader_();
	    if (misc_1.iquit == 1) {
		goto L110;
	    }
/*     AMPERSAND MEANS CONTINUATION. */
	    if (s_cmp(kb1, alpha_1.kampr, (ftnlen)2, (ftnlen)2) == 0) {
		k7 = 2;
		krend = 80;
		goto L70;
	    } else {
		k7 = 7;
		krend = misc_1.k72;
	    }
/*     CHECK FOR A TAB IN NUMBER FIELD. IF SO, NOT A CONTINUATION */
	    for (i__ = 1; i__ <= 6; ++i__) {
		if (s_cmp(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.ktab, (
			ftnlen)2, (ftnlen)2) == 0) {
		    goto L110;
		}
/* L60: */
	    }
/*     CHECK FOR CONTINUATION OR COMMENTS */
/*      (DO NOT ALTER COLUMN 1 OF THE CARD.) */
	    kupper_(ch__1, (ftnlen)2, kb1, (ftnlen)2);
	    s_copy(kb1cr1, ch__1, (ftnlen)2, (ftnlen)2);
	    if (s_cmp(kb1cr1, kc, (ftnlen)2, (ftnlen)2) == 0) {
		goto L110;
	    }
/* new test */
	    if (s_cmp(kb1cr1, "!", (ftnlen)2, (ftnlen)1) == 0) {
		goto L110;
	    }
	    if (s_cmp(kb1cr1, alpha_1.kblcmt, (ftnlen)2, (ftnlen)2) == 0) {
		goto L110;
	    }
	    if (s_cmp(kb1cr1, kstar, (ftnlen)2, (ftnlen)2) == 0) {
		goto L110;
	    }
	    if (s_cmp(kb1cr1, kdol, (ftnlen)2, (ftnlen)2) == 0) {
		goto L110;
	    }
	    if (s_cmp(kb1cr1, kper, (ftnlen)2, (ftnlen)2) == 0) {
		goto L110;
	    }
	    if (s_cmp(kb6, alpha_1.kbl, (ftnlen)2, (ftnlen)2) == 0) {
		goto L110;
	    }
	    if (s_cmp(kb6, kzero, (ftnlen)2, (ftnlen)2) == 0) {
		goto L110;
	    }

L70:
	    i__1 = krend;
	    for (i__ = k7; i__ <= i__1; ++i__) {
		if (i__ > 72 && s_cmp(miscal_1.kbuff + (i__ - 1 << 1), 
			alpha_1.kbl, (ftnlen)2, (ftnlen)2) != 0) {
		    lng72 = TRUE_;
		}
		if (s_cmp(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.ktab, (
			ftnlen)2, (ftnlen)2) == 0) {
		    s_copy(miscal_1.kbuff + (i__ - 1 << 1), alpha_1.kbl, (
			    ftnlen)2, (ftnlen)2);
		}
		if (i__ > 72) {
/* Writing concatenation */
		    i__2[0] = 1, a__1[0] = miscal_1.kbuff + (i__ - 1 << 1);
		    i__2[1] = 1, a__1[1] = "~";
		    s_cat(miscal_1.jint + (misc_1.jmax - 1 << 1), a__1, i__2, 
			    &c__2, (ftnlen)2);
		} else {
		    s_copy(miscal_1.jint + (misc_1.jmax - 1 << 1), 
			    miscal_1.kbuff + (i__ - 1 << 1), (ftnlen)2, (
			    ftnlen)2);
		}
		++misc_1.jmax;
/* L80: */
	    }

/*               TRIM OFF TRAILING BLANKS IN 73-80 */
L90:
	    if (s_cmp(miscal_1.jint + (misc_1.jmax - 2 << 1), " ~", (ftnlen)2,
		     (ftnlen)2) == 0) {
		--misc_1.jmax;
		goto L90;
	    }

	    if (misc_1.mlist == 0) {
		goto L100;
	    }
	    page_(&c__1);
	    io___553.ciunit = lunits_1.outfil;
	    s_wsfe(&io___553);
	    do_fio(&c__80, miscal_1.kbuff, (ftnlen)2);
	    e_wsfe();
L100:
	    ;
	}

/*     MAYBE TOO MANY CONTINUATION CARDS - WILL TRAP THIS IN KIMPAK */
/*      AFTER EXHAUSTING ALL REMEDIES... */

	j = 40;
	reader_();
    }

/*     LOCATE LAST NON-BLANK COLUMN IN CARD AND EXIT. */

L110:
    misc_1.ncd = j - 1;
    --misc_1.jmax;
    for (i__ = misc_1.jmax; i__ >= 1; --i__) {
	if (s_cmp(miscal_1.jint + (i__ - 1 << 1), alpha_1.kbl, (ftnlen)2, (
		ftnlen)2) != 0 && s_cmp(miscal_1.jint + (i__ - 1 << 1), " ~", 
		(ftnlen)2, (ftnlen)2) != 0) {
	    misc_1.jmax = i__;
	    goto L130;
	}
/* L120: */
    }
    misc_1.jmax = 1;
L130:
    s_copy(miscal_1.jint + (misc_1.jmax << 1), alpha_1.kerm, (ftnlen)2, (
	    ftnlen)2);
    if (lng72) {
	diagno_(&c__51);
    }
    return 0;


} /* skard_ */

#undef icolsv
#undef kstar
#undef kzero
#undef jtype
#undef mtran
#undef klass
#undef kper
#undef kdol
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef kb6
#undef kb1
#undef l15
#undef kc


/* Subroutine */ int usrcon_(char *cfilnm, ftnlen cfilnm_len)
{
    /* Format strings */
    static char fmt_30[] = "(\002       ** T I D Y **  SPECIAL CONTROL CARD "
	    "FILE: \002,a)";
    static char fmt_40[] = "(75a1)";
    static char fmt_50[] = "(\002 \002,75a1)";
    static char fmt_60[] = "(\002 CONTROL CARDS MUST HAVE * IN COLUMN 1.\002)"
	    ;

    /* System generated locals */
    integer i__1;
    cllist cl__1;

    /* Builtin functions */
    integer s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void),
	     s_rsfe(cilist *), e_rsfe(void), s_cmp(char *, char *, ftnlen, 
	    ftnlen), f_clos(cllist *);

    /* Local variables */
    static integer i__;
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int contrl_(void);

    /* Fortran I/O blocks */
    static cilist io___563 = { 0, 0, 0, fmt_30, 0 };
    static cilist io___564 = { 0, 0, 1, fmt_40, 0 };
    static cilist io___566 = { 0, 0, 0, fmt_50, 0 };
    static cilist io___567 = { 0, 0, 0, fmt_60, 0 };



/*     READS A SEPARATE FILE OF TIDY CONTROL CARDS SO USER DOES NOT */
/*     HAVE TO EDIT THEM INTO SOURCE FILE. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */

/*  FORTRAN LOGICAL UNITS */
    io___563.ciunit = lunits_1.outfil;
    s_wsfe(&io___563);
    do_fio(&c__1, cfilnm, (ftnlen)64);
    e_wsfe();

L10:
    io___564.ciunit = lunits_1.usrfil;
    i__1 = s_rsfe(&io___564);
    if (i__1 != 0) {
	goto L20;
    }
    for (i__ = 1; i__ <= 75; ++i__) {
	i__1 = do_fio(&c__1, miscal_1.jint + (i__ - 1 << 1), (ftnlen)2);
	if (i__1 != 0) {
	    goto L20;
	}
    }
    i__1 = e_rsfe();
    if (i__1 != 0) {
	goto L20;
    }
    io___566.ciunit = lunits_1.outfil;
    s_wsfe(&io___566);
    for (i__ = 1; i__ <= 75; ++i__) {
	do_fio(&c__1, miscal_1.jint + (i__ - 1 << 1), (ftnlen)2);
    }
    e_wsfe();
    if (s_cmp(miscal_1.jint, alpha_1.kspk + 14, (ftnlen)2, (ftnlen)2) != 0) {
	io___567.ciunit = lunits_1.outfil;
	s_wsfe(&io___567);
	e_wsfe();
    } else {
	misc_1.jmax = 75;
	contrl_();
    }
    goto L10;

L20:
    cl__1.cerr = 0;
    cl__1.cunit = lunits_1.usrfil;
    cl__1.csta = "KEEP";
    f_clos(&cl__1);
    return 0;


} /* usrcon_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Subroutine */ int wrbin_(integer *nunit, integer *kv, char *ser, char *
	list, ftnlen ser_len, ftnlen list_len)
{
    /* Format strings */
    static char fmt_10[] = "(\002 Unit \002,i2,\002 write: \002,8i8)";

    /* Builtin functions */
    integer s_wsue(cilist *), do_uio(integer *, char *, ftnlen), e_wsue(void),
	     s_wsfe(cilist *), do_fio(integer *, char *, ftnlen), e_wsfe(void)
	    ;

    /* Local variables */
#define l15 ((integer *)&misc_1 + 23)
#define kim ((char *)&miscal_1 + 166)
#define mex ((integer *)&misc_1 + 27)
#define imax ((integer *)&misc_1 + 24)
#define nxrf ((integer *)&misc_1 + 26)
#define klass ((integer *)&misc_1 + 21)
#define mtran ((integer *)&misc_1 + 25)
#define jtype ((integer *)&misc_1 + 22)
#define icolsv ((integer *)&misc_1 + 28)
    extern /* Subroutine */ int redstr_(integer *, char *, integer *, integer 
	    *, integer *, integer *, ftnlen);

    /* Fortran I/O blocks */
    static cilist io___577 = { 0, 0, 0, 0, 0 };
    static cilist io___578 = { 0, 0, 0, fmt_10, 0 };



/*     WRITE UNFORMATTED INTERMEDIATE FILES. */

/*     MAXIMUM POSSIBLE CONTINUATION CARDS - ACTUAL LIMIT IS SET BY */
/*      *MAXC CARD (DEFAULT=19) */

/*     MAXIMUM NUMBER OF NESTED DO-LOOPS */

/*     MAXIMUM NUMBER OF STATEMENT LABELS */






/*     COMMON /ALPHA/ KBL,KDIG(10),KABC(26),KSPK(14),KBL2,KLR2,KLP2,KRP2 */
/*  FORTRAN LOGICAL UNITS */


    /* Parameter adjustments */
    list -= 2;
    ser -= 2;
    --kv;

    /* Function Body */
    io___577.ciunit = *nunit;
    s_wsue(&io___577);
    do_uio(&c__8, (char *)&kv[1], (ftnlen)sizeof(integer));
    do_uio(&c__8, ser + 2, (ftnlen)2);
    e_wsue();
    if (misc_1.mdeb != 0) {
	io___578.ciunit = lunits_1.stderr;
	s_wsfe(&io___578);
	do_fio(&c__1, (char *)&(*nunit), (ftnlen)sizeof(integer));
	do_fio(&c__8, (char *)&kv[1], (ftnlen)sizeof(integer));
	e_wsfe();
    }
    redstr_(nunit, list + 2, &kv[4], _BLNK__1.ioutn, &kv[6], &c__1, (ftnlen)2)
	    ;
    return 0;

} /* wrbin_ */

#undef icolsv
#undef jtype
#undef mtran
#undef klass
#undef nxrf
#undef imax
#undef mex
#undef kim
#undef l15


/* Main program alias */ int tidy_ () { MAIN__ (); return 0; }
