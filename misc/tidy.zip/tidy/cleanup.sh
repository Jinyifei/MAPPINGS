#!/bin/bash
for i
do
echo $i
tidy72 $i
done
