f2c for Mac OSX
----------------

Use the terminal, the go to the f2c directory:

> cd f2c

1) Make f2c and libraries:

> make

2) Install f2c into /usr/local

> sudo make install

this puts:
     f2c   in /usr/local/bin/
     f2c.h in /usr/local/include/
     libF77.a in /usr/local/lib/
     libI77.a in /usr/local/lib/

3) cleanup (optional)

> make clean

4) in tcsh, once installed in /user/local directories, you rehash so that the
commands and files are found by everyone else:
( this is only needed with users in tcsh, bash users can skip this step)

> rehash

f2c is ready to use!

5) To uninstall

> sudo make uninstall

removes the installed files
